#! /bin/bash

# Build everything by default
export USER_DIR=sample
ALL=1

# control building of the sub-components 
CLEAN=0
LIB=0
SF_LOADER=0
ROM=0
ECHO=0

CPU_JOB_NUM=$(grep processor /proc/cpuinfo | awk '{field=$NF};END{print field+1}')

# Parse argument list
while :
do
    if [ $# -eq 0 ]; then
        break;
    fi

    option=$1
    shift

    option=`echo "$option" | sed 's/\([^=]*\).*/\1/'` > /dev/null

    case $option in
        clean)      ALL=0 CLEAN=1  ;;
        lib)        ALL=0 LIB=1  ;;
        sf_loader)  ALL=0 SF_LOADER=1   ;;
        rom)        ALL=0 ROM=1   ;;
        *)
            ALL=1 ;;
    esac
done

if [ $SF_LOADER -eq 1 ]
then
    if [ $CLEAN -eq 1 ]
    then
        cmd="make GCC=YES -f sf_loader/Makefile clean"
        if [ $ECHO -eq 1 ]; then
            echo "$cmd"
        fi
        $cmd
    elif [ $ROM -eq 1 ]
    then
        cmd="make GCC=YES -f Makefile FW_IMAGE=SF_LOADER sf_reloc -j$CPU_JOB_NUM"
        if [ $ECHO -eq 1 ]; then
            echo "$cmd"
        fi
        $cmd
#        echo 
#        cmd="make GCC=YES -f sf_loader/Makefile -j$CPU_JOB_NUM"
#        if [ $ECHO -eq 1 ]; then
#            echo "$cmd"
#        fi
#        $cmd
#        echo 
        cmd="make GCC=YES -f sf_loader/Makefile rom -j$CPU_JOB_NUM"
        if [ $ECHO -eq 1 ]; then
            echo "$cmd"
        fi
        $cmd
    else
        cmd="make GCC=YES -f sf_loader/Makefile -j$CPU_JOB_NUM"
        if [ $ECHO -eq 1 ]; then
            echo "$cmd"
        fi
        $cmd
    fi
else
    if [ $ALL -eq 1 ]
    then
        cmd="make GCC=YES -f Makefile -j$CPU_JOB_NUM"
        if [ $ECHO -eq 1 ]; then
            echo "$cmd"
        fi
        $cmd
    else
        if [ $LIB -eq 1 ]
        then
            cmd="make GCC=YES -f Makefile lib -j$CPU_JOB_NUM"
            if [ $ECHO -eq 1 ]; then
                echo "$cmd"
            fi
            $cmd
        elif [ $CLEAN -eq 1 ]
        then
            cmd="make GCC=YES -f Makefile clean"
            if [ $ECHO -eq 1 ]; then
                echo "$cmd"
            fi
            $cmd
        fi
    fi
fi
