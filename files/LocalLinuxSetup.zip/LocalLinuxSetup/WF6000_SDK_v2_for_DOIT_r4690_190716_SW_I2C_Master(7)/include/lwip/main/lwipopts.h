/*--------------------------------------------------------------------------
/	Project name	: XRONet Standalone WiFi Module
/	Copyright		: XRONet, All rights reserved.
/	File name		: lwipopts.h
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	tjjeong		12.10.30		Create
---------------------------------------------------------------------------*/
#ifndef __LWIPOPTS_H__
#define __LWIPOPTS_H__

/**
 * NO_SYS==1: Provides VERY minimal functionality. Otherwise,
 * use lwIP facilities.
 */
#define NO_SYS                          0

#define SYS_CHECK_PARAM                 0

#define SYS_LIGHTWEIGHT_PROT            1

#define LWIP_ALLOW_MEM_FREE_FROM_OTHER_CONTEXT 1

#define LWIP_STATS                      1

/* ---------- Memory options ---------- */
/* MEM_ALIGNMENT: should be set to the alignment of the CPU for which
   lwIP is compiled. 4 byte alignment -> define MEM_ALIGNMENT to 4, 2
   byte alignment -> define MEM_ALIGNMENT to 2. */
#define MEM_ALIGNMENT                   4

/**
 * LWIP_RANDOMIZE_INITIAL_LOCAL_PORTS==1: randomize the local port for the first
 * local TCP/UDP pcb (default==0). This can prevent creating predictable port
 * numbers after booting a device.
 */
#define LWIP_RANDOMIZE_INITIAL_LOCAL_PORTS 1

/**
 * TCP_MAXRTX: Maximum number of retransmissions of data segments.
 */
#define TCP_MAXRTX                      6

/**
 * TCP_SYNMAXRTX: Maximum number of retransmissions of SYN segments.
 */
#if defined (CUSTOM_NANOKEM)
#define TCP_SYNMAXRTX                   6
#else
#define TCP_SYNMAXRTX                   3
#endif


#if defined (FEATURE_TCP_FAST_SCHED)
/* The TCP timer interval in milliseconds. */
#define TCP_TMR_INTERVAL                10
#else
/* The TCP timer interval in milliseconds. */
#define TCP_TMR_INTERVAL                100
#endif

/* TCP Maximum segment size. */
#define TCP_MSS                         (1500 - 40)	  /* TCP_MSS = (Ethernet MTU - IP header size - TCP header size) */

/* TCP sender buffer space (bytes). */
#define TCP_SND_BUF                     (NUM_OF_TCP_SND_BUF*TCP_MSS)

/*  TCP_SND_QUEUELEN: TCP sender buffer space (pbufs). This must be at least
  as much as (2 * TCP_SND_BUF/TCP_MSS) for things to work. */
#define TCP_SND_QUEUELEN                (2*TCP_SND_BUF/TCP_MSS)

#define MEMP_NUM_TCP_SEG                32

/* TCP receive window. */
#define TCP_WND                         (4*TCP_MSS)

/* MEM_SIZE: the size of the heap memory. If the application will send
a lot of data that needs to be copied, this should be set high. This must be at least
  as much as (2 * TCP_SND_BUF) for things to work. */
#define MEM_SIZE                        (MEMP_NUM_TCP_SEG*TCP_MSS)// used for Lwip malloc

/**
 * PBUF_POOL_SIZE: the number of buffers in the pbuf pool. 
 */
#define PBUF_POOL_SIZE                  ((MEM_SIZE/1024)/2)

#define MEMP_NUM_TCPIP_MSG_INPKT        PBUF_POOL_SIZE

/**
 * MEMP_NUM_ARP_QUEUE: the number of simulateously queued outgoing
 * packets (pbufs) that are waiting for an ARP request (to resolve
 * their destination address) to finish.
 * (requires the ARP_QUEUEING option)
 */
#define MEMP_NUM_ARP_QUEUE              10

/**
 * ARP_QUEUEING==1: Multiple outgoing packets are queued during hardware address
 * resolution. By default, only the most recent packet is queued per IP address.
 * This is sufficient for most protocols and mainly reduces TCP connection
 * startup time. Set this to 1 if you know your application sends more than one
 * packet in a row to an IP address that is not in the ARP cache.
 */
#define ARP_QUEUEING                    1

/**
 * SO_REUSE==1: Enable SO_REUSEADDR option.
 */
#define SO_REUSE                        1

/**
 * SO_REUSE_RXTOALL==1: Pass a copy of incoming broadcast/multicast packets
 * to all local matches if SO_REUSEADDR is turned on.
 * WARNING: Adds a memcpy for every packet if passing to more than one pcb!
 */
#define SO_REUSE_RXTOALL                1

/**
 * LWIP_DHCP==1: Enable DHCP module.
 */
#define LWIP_DHCP                       1

/**
 * LWIP_DNS==1: Turn on DNS module. UDP must be available for DNS
 * transport.
 */
#define LWIP_DNS                        1

/**
 * LWIP_DNS_SERVER==1: Turn on DNS Server module. UDP must be available for DNS
 * transport.
 */
#if defined (FEATURE_DNS_SERVER_SUPP)
#define LWIP_DNS_SERVER                 1
#else
#define LWIP_DNS_SERVER                 0
#endif

/**
 * LWIP_SMTP==1: Turn on SMTP.
 */
#if defined (FEATURE_SMTP_SUPP) 
#define LWIP_SMTP                       1
#else
#define LWIP_SMTP                       0
#endif

/**
 * LWIP_POP3==1: Turn on POP3.
 */
#if defined (FEATURE_POP3_SUPP)
#define LWIP_POP3                       1
#else
#define LWIP_POP3                       0
#endif

/**
 * LWIP_DHCPD==1: Turn on DHCP SERVER.
 */
#if defined (FEATURE_DHCPD_SUPP)
#define LWIP_DHCPD                      1
#else
#define LWIP_DHCPD                      0
#endif

/**
 * LWIP_HTTPC==1: Turn on HTTP Client.
 */
#if defined (FEATURE_HTTPC_SUPP)
#define LWIP_HTTPC                      1
#else
#define LWIP_HTTPC                      0
#endif

/**
 * LWIP_HTTPC_V2==1: Turn on HTTP Client v2.
 */
#if defined (FEATURE_HTTPC_V2_SUPP)
#define LWIP_HTTPC_V2                   1
#else
#define LWIP_HTTPC_V2                   0
#endif

/**
 * LWIP_HTTP==1: Turn on HTTP.
 */
#if defined (FEATURE_HTTP_SVR_SUPP)
#define LWIP_HTTP_SVR                   1
#else
#define LWIP_HTTP_SVR                   0
#endif

/**
 * LWIP_SSDP==1: Turn on SSDP.
 */
#if defined (FEATURE_UPNP_TINY_SUPP)
#define LWIP_SSDP                       1
#else
#define LWIP_SSDP                       0
#endif

/**
 * LWIP_TELNETD==1: Turn on TELNET SERVER.
 */
#if defined (FEATURE_TELNETD_SUPP)
#define LWIP_TELNETD                    1
#else
#define LWIP_TELNETD                    0
#endif

/**
 * LWIP_RTSPD==1: Turn on RTSPD.
 */
#if defined (FEATURE_RTSPD_SUPP)
#define LWIP_RTSPD                      1
#else
#define LWIP_RTSPD                      0
#endif

/**
 * LWIP_RTP==1: Turn on RTP.
 */
#if defined (FEATURE_RTP_SUPP)
#define LWIP_RTP                        1
#else
#define LWIP_RTP                        0
#endif

/**
 * LWIP_LPD==1: Turn on LPD.
 */
#if defined (FEATURE_LPD_SUPP)
#define LWIP_LPD                        1
#else
#define LWIP_LPD                        0
#endif

/**
 * LWIP_FTPC==1: Turn on FTP CLIENT.
 */
#if defined (FEATURE_FTPC_SUPP)
#define LWIP_FTPC                       1
#else
#define LWIP_FTPC                       0
#endif

/**
 * LWIP_SNTP==1: Turn on SNTP CLIENT.
 */
#if defined (FEATURE_SNTP_SUPP)
#define LWIP_SNTP                       1
#else
#define LWIP_SNTP                       0
#endif

/**
 * LWIP_SNMP==1: Turn on SNMP agent.
 */
#if defined (FEATURE_SNMP_SUPP)
#define LWIP_SNMP                       1
#else
#define LWIP_SNMP                       0
#endif

/**
 * LWIP_PING==1: Turn on PING send.
 */
#if defined (FEATURE_PING_SUPP)
#define LWIP_PING                       1
#else
#define LWIP_PING                       0
#endif

/**
 * LWIP_UDAP==1: Turn on UDAP.
 */
#if defined (FEATURE_UDAP_SUPP)
#define LWIP_UDAP                       1
#else
#define LWIP_UDAP                       0
#endif

/**
 * LWIP_RMTCD==1: Turn on RMTCD.
 */
#if defined (FEATURE_RMC_SUPP)
#define LWIP_RMC                        1
#else
#define LWIP_RMC                        0
#endif

/**
 * LWIP_CUST==1: Turn on CUST.
 */
#if defined (FEATURE_CUST_SUPP)
#define LWIP_CUST                       1
#else
#define LWIP_CUST                       0
#endif

/**
 * LWIP_MPC==1: Turn on MPC.
 */
#if defined (FEATURE_MPC_SUPP)
#define LWIP_MPC                        1
#else
#define LWIP_MPC                        0
#endif

/**
 * LWIP_RFB==1: Turn on RFB.
 */
#if defined (FEATURE_RFB_SVR_SUPP)
#define LWIP_RFB_SVR                    1
#else
#define LWIP_RFB_SVR                    0
#endif

/**
 * LWIP_IPERF==1: Turn on RFB.
 */
#if defined (FEATURE_IPERF_SVR_SUPP)
#define LWIP_IPERF                      1
#else
#define LWIP_IPERF                      0
#endif

#define MEMP_NUM_USR_TCP_PCB            3
#define MEMP_NUM_USR_UDP_PCB            3

#define MEMP_TCP_ALLOW_SINGLE_CLIENT    1

#if defined (CUSTOM_DIGIENCE) || defined (CUSTOM_WINIX) || defined (CUSTOM_WINIA) || defined (CUSTOM_DY_MAGIC)
#define MEMP_NUM_USR_TCP_ALLOW_CLIENT   5
#else
#define MEMP_NUM_USR_TCP_ALLOW_CLIENT   3
#endif

#define MEMP_NUM_TCP_PCB                (MEMP_NUM_USR_TCP_PCB + LWIP_SMTP + LWIP_POP3 + LWIP_HTTPC + LWIP_HTTPC_V2 + LWIP_FTPC + LWIP_CUST + MEMP_NUM_USR_TCP_ALLOW_CLIENT)
#define MEMP_NUM_TCP_PCB_LISTEN         (MEMP_NUM_USR_TCP_PCB + LWIP_HTTP_SVR + LWIP_TELNETD + LWIP_RTSPD + LWIP_LPD + LWIP_RFB_SVR + LWIP_IPERF)
#define MEMP_NUM_UDP_PCB                (MEMP_NUM_USR_UDP_PCB + LWIP_DNS + LWIP_DHCP + LWIP_DHCPD + LWIP_RTP + LWIP_SNTP + LWIP_SNMP \
                                         + LWIP_UDAP + LWIP_DNS_SERVER + LWIP_SSDP)

#define MAX_NUM_TCP_UDP_PCB             MEMP_NUM_TCP_PCB + MEMP_NUM_TCP_PCB_LISTEN + MEMP_NUM_UDP_PCB

/**
 * TCPIP_THREAD_NAME: The name assigned to the main tcpip thread.
 */
#define TCPIP_THREAD_NAME              "TCP_IP"

/**
 * TCPIP_THREAD_STACKSIZE: The stack size used by the main tcpip thread.
 * The stack size value itself is platform-dependent, but is passed to
 * sys_thread_new() when the thread is created.
 */
#if defined (CUSTOM_MIDEA_STDA_CM) || defined (CUSTOM_BONA_STDA_CM_V2)
#define TCPIP_THREAD_STACKSIZE          (1024 * 8)/4
#else
#define TCPIP_THREAD_STACKSIZE          (512 * 10)/4
#endif

/**
 * TCPIP_THREAD_PRIO: The priority assigned to the main tcpip thread.
 * The priority value itself is platform-dependent, but is passed to
 * sys_thread_new() when the thread is created.
 */
#define TCPIP_THREAD_PRIO               TASK_PRI_PS

/**
 * TCPIP_MBOX_SIZE: The mailbox size for the tcpip thread messages
 * The queue size value itself is platform-dependent, but is passed to
 * sys_mbox_new() when tcpip_init is called.
 */
#define TCPIP_MBOX_SIZE                 MEMP_NUM_TCPIP_MSG_INPKT

#define DEFAULT_UDP_RECVMBOX_SIZE       TCPIP_MBOX_SIZE
#define DEFAULT_TCP_RECVMBOX_SIZE       TCPIP_MBOX_SIZE
#define DEFAULT_ACCEPTMBOX_SIZE         TCPIP_MBOX_SIZE

/**
 * LWIP_COMPAT_SOCKETS==1: Enable BSD-style sockets functions names.
 * (only used if you use sockets.c)
 */
#if defined (FEATURE_SSL_SUPP) || defined (FEATURE_UPNP_SUPP) || defined (FEATURE_SEP20_SUPP) || defined (FEATURE_UPNP_TINY_SUPP)
#define LWIP_COMPAT_SOCKETS             1
#define LWIP_IGMP                       1
#elif defined (FEATURE_IOT_PROTO_SUPP)
#define LWIP_COMPAT_SOCKETS             1
#define LWIP_POSIX_SOCKETS_IO_NAMES     1
#else
#if defined (CUSTOM_MIDEA_STDA_CM) || defined (CUSTOM_BONA_STDA_CM_V2)
#define LWIP_COMPAT_SOCKETS             1
#define LWIP_POSIX_SOCKETS_IO_NAMES     1
#else
#define LWIP_COMPAT_SOCKETS             0
#endif
#endif

/**
 * LWIP_STATS_DISPLAY==1: Compile in the statistics output functions.
 */
#define LWIP_STATS_DISPLAY              1

//#define SYS_DEBUG                       LWIP_DBG_ON
//#define PBUF_DEBUG                      LWIP_DBG_ON
//#define API_MSG_DEBUG                   LWIP_DBG_ON
//#define IP_DEBUG                        LWIP_DBG_ON
//#define MEMP_DEBUG                      LWIP_DBG_ON
//#define TCP_DEBUG                       LWIP_DBG_ON
//#define TCP_INPUT_DEBUG                 LWIP_DBG_ON
//#define TCP_OUTPUT_DEBUG                LWIP_DBG_ON
//#define TCP_QLEN_DEBUG                  LWIP_DBG_ON
//#define TCPIP_DEBUG                     LWIP_DBG_ON
//#define TCP_RST_DEBUG                   LWIP_DBG_ON
//#define TCP_CWND_DEBUG                  LWIP_DBG_ON
//#define SOCKETS_DEBUG                   LWIP_DBG_ON
//#define NETIF_DEBUG                     LWIP_DBG_ON
//#define TCP_FR_DEBUG                    LWIP_DBG_ON
//#define TCP_RTO_DEBUG                   LWIP_DBG_ON
//#define ICMP_DEBUG                      LWIP_DBG_ON
//#define ETHARP_DEBUG                    LWIP_DBG_ON
//#define DHCP_DEBUG                      LWIP_DBG_ON
//#define UDP_DEBUG                       LWIP_DBG_ON
//#define SNTP_DEBUG                      LWIP_DBG_ON
//#define SNMP_MSG_DEBUG                  LWIP_DBG_ON
//#define IGMP_DEBUG                      LWIP_DBG_ON
//#define LWFTP_DEBUG                     LWIP_DBG_ON
//#define INET_DEBUG                      LWIP_DBG_ON
//#define DDNS_DEBUG                      LWIP_DBG_ON
//#define DNS_DEBUG                       LWIP_DBG_ON
//#define PPP_DEBUG                       LWIP_DBG_ON
#endif /*__LWIPOPTS_H__*/



