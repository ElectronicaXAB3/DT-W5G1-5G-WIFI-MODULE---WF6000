/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: ict_app_uart_cmd.h
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/


#ifndef __ICT_APP_UART_CMD_H__
#define __ICT_APP_UART_CMD_H__

/*
******************************************************************************
*	GLOBAL VARIABLE
******************************************************************************
*/

/*
******************************************************************************
*	FUNCTIONS
******************************************************************************
*/
INT32 ict_app_uart_cmd_swver(UINT8 *cmd_buffer, UINT32 cmd_len, UINT8 *response_buffer, UINT32 *response_len);
INT32 ict_app_uart_cmd_fwver(UINT8 *cmd_buffer, UINT32 cmd_len, UINT8 *response_buffer, UINT32 *response_len);
INT32 ict_app_uart_cmd_mac(UINT8 *cmd_buffer, UINT32 cmd_len, UINT8 *response_buffer, UINT32 *response_len);
INT32 ict_app_uart_cmd_reset(UINT8 *cmd_buffer, UINT32 cmd_len, UINT8 *response_buffer, UINT32 *response_len);

#endif /* __ICT_APP_UART_CMD_H__ */
