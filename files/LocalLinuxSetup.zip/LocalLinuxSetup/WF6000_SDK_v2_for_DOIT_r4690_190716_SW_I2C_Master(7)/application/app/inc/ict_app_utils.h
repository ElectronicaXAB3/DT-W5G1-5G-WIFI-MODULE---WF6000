/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: ict_app_utils.h
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/


#ifndef __ICT_APP_UTILS_H__
#define __ICT_APP_UTILS_H__

/*
******************************************************************************
*	GLOBAL VARIABLE
******************************************************************************
*/

/*
******************************************************************************
*	FUNCTIONS
******************************************************************************
*/


/*****************************************************************************
** Function name: ict_app_get_token
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
UINT8 *ict_app_get_token (UINT8 *p_in_str, UINT8 *p_out_token, UINT32 token_size);

/*****************************************************************************
** Function name: ict_app_get_token_2
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
UINT8 *ict_app_get_token_2 (UINT8 *p_in_str, UINT8 *p_out_token, UINT32 token_size, UINT8 *sep);

#endif /* __ICT_APP_UTILS_H__ */
