/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: ict_app_globals.h
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/


#ifndef __ICT_APP_GLOBALS_H__
#define __ICT_APP_GLOBALS_H__

/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/

#if defined (HOST_STDA_APP_LIB)
#include "ict_app_common.h"
#else
#include "xn_common.h"
#include "xn_typedef.h"

#include "lwip/err.h"
#include "lwip/ip_addr.h"
#include "usr_app.h"

#include "xn_sys_gpio.h"

#include "xn_umac_def.h"
#include "xn_umac_common.h"
#include "xn_mac_mib.h"

#include "xn_sw_timer.h"
#include "xn_dm_shell.h"

#include "xn_hw_power_save.h"

#include "xn_sme_hsgd_event_handler.h"

#if defined(FEATURE_NV_SYSTEM)
#include "nvman.h"
#endif /* FEATURE_NV_SYSTEM */

#if defined(FEATURE_FILE_SYSTEM_FATFS)
#include "ff.h"
#endif /* FEATURE_FILE_SYSTEM_FATFS */

#if defined(FEATURE_FLASH_SHELL) || defined (FEATURE_OTA_SUPP)
#include "xn_flash.h"
#endif /* FEATURE_FLASH_SHELL || FEATURE_OTA_SUPP */

#if defined(FEATURE_DDNS_SUPP)
#include "ddns.h"
#endif /* FEATURE_DDNS_SUPP */

#if defined(FEATURE_HTTPC_SUPP)
#include "httpc.h"
#endif /* FEATURE_HTTPC_SUPP */

#if defined(FEATURE_HTTPC_V2_SUPP)
#include "httpc_v2.h"
#endif /* FEATURE_HTTPC_V2_SUPP */

#if defined (FEATURE_OTA_SUPP)
#include "ota.h"
#endif /* FEATURE_OTA_SUPP */

#endif /* HOST_STDA_APP_LIB */

#if defined(FEATURE_JSON_PARSER)
#include "cJSON.h"
#endif /* FEATURE_JSON_PARSER */

#include "ict_api_lib.h"

#include "ict_app_uart.h"
#include "ict_app.h"

#include "ict_app_utils.h"
#include "ict_app_uart_cmd.h"

/*
******************************************************************************
*	DEFINITION
******************************************************************************
*/

/*
******************************************************************************
*	MACRO
******************************************************************************
*/

/*
******************************************************************************
*	DATA TYPE
******************************************************************************
*/

/*
******************************************************************************
*	GLOBAL VARIABLE
******************************************************************************
*/

/*
******************************************************************************
*	FUNCTIONS
******************************************************************************
*/

#endif /* __ICT_APP_GLOBALS_H__ */
