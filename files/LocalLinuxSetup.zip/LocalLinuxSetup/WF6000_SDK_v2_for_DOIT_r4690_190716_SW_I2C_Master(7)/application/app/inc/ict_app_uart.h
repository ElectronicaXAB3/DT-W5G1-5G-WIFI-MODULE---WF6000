/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: ict_app_uart.h
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/

#if !defined(__ICT_APP_UART_H__)
#define __ICT_APP_UART_H__

#if defined (HOST_STDA_CM_INTERWORKING)
#if defined (FEATURE_USE_UART0_CM) || \
    defined (FEATURE_USE_UART1_CM) || defined (FEATURE_USE_UART2_CM) || \
    defined (FEATURE_USE_UART1_INTP) || defined (FEATURE_USE_UART2_INTP) || \
    defined (SDK_VER_2)


/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/

/*
******************************************************************************
*	DEFINITION
******************************************************************************
*/

#define APP_PRINTF_BUFF_SIZE    2048


/**************
*  APP_PRINTF 
***************/
/* APP_PRINTF, MSG_PRINTF would print to defined **** APP_DEBUG_PORT **** */
#define APP_PRINTF      ict_app_uart_printf
#define MSG_PRINTF      ict_app_uart_printf_msg
#define HEX_PRINTF      ict_app_uart_printf_hex

#ifdef printf
#undef printf
#endif
#define printf          ict_app_uart_printf

/* If defined FEATURE_APP_UART_TX_CR, New line is used only with CR. Otherwise, the new line is used with LF. */
/* In case of Alpha DM, you should use CR mode for TX. */
#define FEATURE_APP_UART_TX_CR

#define FEATURE_APP_UART_PRINT_TIMESTAMP


#define APP_DEBUG_PORT          UART0

#if defined (HOST_STDA_APP_LIB)
/* APP_SH_PRINTF would print to UART0 */
#define APP_SH_PRINTF    ict_api_debug_dm_hif_printf
#else
#define APP_SH_PRINTF    SH_PRINTF
#endif


/**************
*  HOST_PRINTF 
***************/
/* HOST_PRINTF would print to **** APP_HOST_PORT **** */
#define HOST_PRINTF      ict_app_host_printf

//#define APP_HOST_PORT           UART1
#define APP_HOST_PORT           UART2

#define HOST_TX_START_STR       "*ICT*"
#define HOST_TX_START_STR_LEN   5
#define HOST_TX_END_STR         "\r"
#define HOST_TX_END_STR_LEN     1

#if defined (APP_HOST_PORT)
#define FEATURE_SEND_EVENT_TO_HOST
#endif

/*
******************************************************************************
*	DATA TYPE
******************************************************************************
*/

/*
******************************************************************************
*	GLOBAL VARIABLE
******************************************************************************
*/

/*
******************************************************************************
*   FUNCTIONS
******************************************************************************
*/

/*****************************************************************************
** Function name: ict_app_uart_printf
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
extern void ict_app_uart_printf(char *fmt,...);
extern void ict_app_uart_printf_msg(char *buf);
extern void ict_app_host_printf(char *fmt,...);

#endif /* FEATURE_USE_UART0_CM || FEATURE_USE_UART1_CM || FEATURE_USE_UART2_CM || FEATURE_USE_UART1_INTP || FEATURE_USE_UART2_INTP */
#endif /* HOST_STDA_CM_INTERWORKING */
#endif /* __ICT_APP_UART_H__ */

