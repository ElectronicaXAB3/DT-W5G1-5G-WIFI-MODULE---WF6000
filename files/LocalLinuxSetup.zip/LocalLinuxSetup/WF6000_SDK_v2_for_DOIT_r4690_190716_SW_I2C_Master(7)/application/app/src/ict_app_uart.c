/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: ict_app_uart.c
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/

#if defined(HOST_STDA_CM_INTERWORKING)
#if defined (FEATURE_USE_UART0_CM) || \
    defined (FEATURE_USE_UART1_CM) || defined (FEATURE_USE_UART2_CM) || \
    defined (FEATURE_USE_UART1_INTP) || defined (FEATURE_USE_UART2_INTP) || \
    defined (SDK_VER_2)

/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/
#include "ict_app_globals.h"

/*
******************************************************************************
* 	LOCAL CONSTANTS
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL DATA TYPES
******************************************************************************
*/

/*
******************************************************************************
*	GLOBAL VARIABLES
******************************************************************************
*/

#ifdef TNKERNEL
extern UINT8 OSIntNesting;
#endif

/*
******************************************************************************
*	LOCAL VARIABLES
******************************************************************************
*/

static UINT8 app_uart_debug_print_buff[APP_PRINTF_BUFF_SIZE];

/*
******************************************************************************
*	LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/

/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/

/*****************************************************************************
** Function name: ict_app_uart_printf
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
void ict_app_uart_printf(char *fmt,...)
{
	va_list ap;
    char    *str;    
    int     size, idx;
#if defined (FEATURE_APP_UART_TX_CR)
    int     cnt;
#endif

    if (OSIntNesting)
    {
        return;
    }
    
    str = (char *)app_uart_debug_print_buff;
    idx = 0;
    
#if defined (FEATURE_APP_UART_PRINT_TIMESTAMP)
    ICT_SPRINTF (str, "%08X ", ICT_TIMESTAMP());
    idx += 8;
    str[idx++] = ':';
#endif

    va_start(ap, fmt);

    size = ICT_VSPRINTF (&str[idx], fmt, ap);
    size += idx;

    if(size >= (APP_PRINTF_BUFF_SIZE-1))
    {
        APP_PRINTF("[%s] Error #1\n" , __func__);
        ICT_ASSERT(0);
    }

#if defined (FEATURE_APP_UART_TX_CR)
    for (cnt=0; cnt<size; cnt++)
    {
        if(str[cnt] == '\n')
        {
            str[cnt] = '\r';
        }
    }
#endif

    ict_api_uart_direct_send_w_size (APP_DEBUG_PORT, (UINT8 *)str, size);

  	va_end (ap);
}

void ict_app_uart_printf_msg(char *buf)
{
    UINT32 i, buf_len;
    UINT32 temp_len;
    char temp[102];

    buf_len = ICT_STRLEN(buf);
    if (buf_len > APP_PRINTF_BUFF_SIZE)
        APP_PRINTF("[%s] Oversize!! (%d)\n", __func__, buf_len);

    for (i = 0; i < buf_len; i+=100)
    {
        temp_len = ((i+100) > buf_len ? buf_len-i : 100);
        ICT_MEMCPY(temp, &buf[i], temp_len);
        temp[temp_len++] = '\n';
        temp[temp_len++] = '\0';

        APP_PRINTF("%s", temp);
    }

}

void ict_app_uart_printf_hex(void *buff, UINT32 size)
{
    UINT32 i = 0;
    UINT8  *data = (UINT8*)buff;
    UINT8 out_data[50], *ptr;
    UINT32 len;

    ptr = out_data;
    
    while (i < size)
    {
        ICT_SPRINTF(ptr, "%02X ", data[i]);
        if (!((i+1) & 0x0F))
        {
            APP_PRINTF ("N:%s\n", out_data);
            ICT_MEMSET(out_data, 0x00, 50);
            ptr = out_data;
        }
        else
        {
            ptr += 3;
        }
        i++;
    }

    if (ptr != out_data)
        APP_PRINTF("N:%s\n", out_data);    
}

void ict_app_host_printf(char *fmt,...)
{
#if defined (FEATURE_SEND_EVENT_TO_HOST)    
	va_list ap;
    char    *str;    
    int     size, idx = 0;

    if (OSIntNesting) return;
    
    str = (char *)app_uart_debug_print_buff;

    ICT_MEMCPY(&str[idx], HOST_TX_START_STR, HOST_TX_START_STR_LEN);
    idx += HOST_TX_START_STR_LEN;
 
    va_start(ap, fmt);

    size = ICT_VSPRINTF (&str[idx], fmt, ap);
    size += idx;

    if(size >= (APP_PRINTF_BUFF_SIZE-1))
    {
        APP_PRINTF("[%s] Error #1\n" , __func__);
        ICT_ASSERT(0);
    }

    if (str[size-1] == '\n') size--;
    if (str[size-1] == '\r') size--;

    ICT_MEMCPY(&str[size], HOST_TX_END_STR, HOST_TX_END_STR_LEN);
    size += HOST_TX_END_STR_LEN;        

    ict_api_uart_direct_send_w_size (APP_HOST_PORT, (UINT8 *)str, size);

  	va_end (ap);
#endif    
}

#else
void ict_app_uart_printf(char *fmt,...)
{
    //
}

void ict_app_uart_printf_msg(char *buf)
{
    
}

void ict_app_host_printf(char *fmt,...)
{

}

#endif /* FEATURE_USE_UART0_CM || FEATURE_USE_UART1_CM || FEATURE_USE_UART2_CM || FEATURE_USE_UART1_INTP || FEATURE_USE_UART2_INTP */
#endif /* HOST_STDA_CM_INTERWORKING */

