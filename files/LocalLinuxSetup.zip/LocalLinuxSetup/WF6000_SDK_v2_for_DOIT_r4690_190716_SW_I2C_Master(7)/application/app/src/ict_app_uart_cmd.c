/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: ict_app_uart_cmd.c
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/

#if defined(HOST_STDA_CM_INTERWORKING)

/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/
#include "ict_app_globals.h"

/*
******************************************************************************
* 	LOCAL CONSTANTS
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL DATA TYPES
******************************************************************************
*/

/*
******************************************************************************
*	GLOBAL VARIABLES
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL VARIABLES
******************************************************************************
*/


/*
******************************************************************************
*	LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/

/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/

INT32 ict_app_uart_cmd_swver(UINT8 *cmd_buffer, UINT32 cmd_len, UINT8 *response_buffer, UINT32 *response_len)
{
    if (*cmd_buffer++ == '=' && *cmd_buffer == '?')
    {
        *response_len = ICT_SPRINTF((char*)response_buffer, "%s", p_sw_ver_info);
        
        return ICT_OK;
    }

    return ICT_ERR;
}

INT32 ict_app_uart_cmd_fwver(UINT8 *cmd_buffer, UINT32 cmd_len, UINT8 *response_buffer, UINT32 *response_len)
{
    if (*cmd_buffer++ == '=' && *cmd_buffer == '?')
    {
        *response_len = ICT_SPRINTF((char*)response_buffer, "%s", OUTPUT_RELEASE_STR);
        
        return ICT_OK;
    }

    return ICT_ERR;
}

INT32 ict_app_uart_cmd_mac(UINT8 *cmd_buffer, UINT32 cmd_len, UINT8 *response_buffer, UINT32 *response_len)
{
    if (*cmd_buffer++ == '=' && *cmd_buffer == '?')
    {
        UINT8 mac_addr[MAC_ADDR_LEN];
        UINT8 len;
        
        ict_api_mac_mib_get_wifi_cfg(WIFI_CFG_MAC_ADDR, mac_addr, &len);
        
        *response_len = ICT_SPRINTF((char*)response_buffer, ICT_MACSTR, ICT_MAC2STR(mac_addr));

        return ICT_OK;
    }

    return ICT_ERR;
}

INT32 ict_app_uart_cmd_reset(UINT8 *cmd_buffer, UINT32 cmd_len, UINT8 *response_buffer, UINT32 *response_len)
{
    UINT8   c;

    do
    {
        if (ict_api_sys_get_fw_download_state() != ICT_DOWNLOAD_IDLE)
        {
            *response_len = ICT_SPRINTF((char*)response_buffer, "ERROR");
            break;
        }

        ict_api_sys_boot_reset(ICT_EXTERNAL_FLASH_RESET);
        
        return ICT_OK;        
    } while(0);

    return ICT_ERR;
}

#endif /* HOST_STDA_CM_INTERWORKING */

