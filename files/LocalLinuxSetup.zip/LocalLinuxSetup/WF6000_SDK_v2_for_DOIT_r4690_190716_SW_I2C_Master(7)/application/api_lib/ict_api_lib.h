/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: ict_api_lib.h
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/

#if !defined(__ICT_API_LIB_H__)
#define __ICT_API_LIB_H__

#if defined (HOST_STDA_CM_INTERWORKING) || defined (FEATURE_PICOC_SUPP)

/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/

/*
******************************************************************************
*	DEFINITION
******************************************************************************
*/

#ifndef ICT_FALSE
#define ICT_FALSE           0
#endif

#ifndef ICT_TRUE
#define ICT_TRUE            !(ICT_FALSE)
#endif

#if defined (SDK_V1_DC)
#ifndef false
#define false               0
#endif

#ifndef true
#define true                !(false)
#endif
#endif

#ifndef ICT_NULL
#define ICT_NULL            0
#endif

#ifndef ICT_OK
#define ICT_OK              0
#endif

#ifndef ICT_ERR
#define ICT_ERR             (-1)
#endif

#ifndef ICT_NO_ERR
#define ICT_NO_ERR          0
#endif

#define CARRIAGE_RETURN 0x0D
#define BACK_SPACE      0x08
#define NULL_STRING     0x00

#ifndef MAC_ADDR_LEN
#define MAC_ADDR_LEN        6
#endif

#ifndef MAX_SSID_LEN
#define MAX_SSID_LEN        32
#endif

#ifndef MAX_PSK_LEN
#define MAX_PSK_LEN         64
#endif

#define SOCKET_CMD_CREATE       0
#define SOCKET_CMD_CLOSE        1

#define SOCKET_TYPE_TCP_CLIENT      1
#define SOCKET_TYPE_UDP_CLIENT      2
#define SOCKET_TYPE_TCP_SERVER      4
#define SOCKET_TYPE_UDP_SERVER      8

#define	ICT_PRINTF          XN_PRINTF
#define	ICT_PRINTF_         printf

#define ICT_TIMESTAMP       ict_api_debug_get_timestamp
#define ICT_TRACE0          ict_api_debug_trace0
#define ICT_TRACE1          ict_api_debug_trace1
#define ICT_TRACE2          ict_api_debug_trace2
#define ICT_TRACE3          ict_api_debug_trace3
#define ICT_TRACE4          ict_api_debug_trace4

#define ICT_WORD2STR(a)  (a)[0], (a)[1], (a)[2], (a)[3]
#define ICT_WORDSTR      "%02X:%02X:%02X:%02X"

#define ICT_MAC2STR(a)   (a)[0], (a)[1], (a)[2], (a)[3], (a)[4], (a)[5]
#define ICT_MACSTR       "%02X:%02X:%02X:%02X:%02X:%02X"

#define ICT_PN2STR(a)    XN_MAC2STR(a)
#define ICT_PNSTR        XN_MACSTR

#define ICT_DWORD2HSTR(a) (a)[0], (a)[1], (a)[2], (a)[3], (a)[4], (a)[5], (a)[6], (a)[7]
#define ICT_DWORDHSTR     "%02X:%02X:%02X:%02X:%02X:%02X:%02X:%02X"

#define ICT_DWORD2STR(a) (a)[0], (a)[1], (a)[2], (a)[3], (a)[4], (a)[5], (a)[6], (a)[7]
#define ICT_DWORDSTR     "%03d:%03d:%03d:%03d:%03d:%03d:%03d:%03d"

#define ICT_MEMSET(dst,val,len)     ict_api_memset(dst,val,len)
#define ICT_STRLEN(str)             ict_api_strlen(str)
#define ICT_STRLEN_W_SEP(str, sep)  ict_api_strlen_w_sep(str, sep)
#define ICT_STRCMP(dst,src)         ict_api_strcmp(dst,src)
#define ICT_STRNCMP(s1, s2, len)    ict_api_strncmp(s1, s2, len)
#define ICT_STRCASECMP(dst,src)         ict_api_strcasecmp(dst,src)
#define ICT_STRNCASECMP(s1, s2, len)    ict_api_strncasecmp(s1, s2, len)
#define ICT_STRSTR(s1, s2)          ict_api_strstr(s1, s2)
#define ICT_STRNSTR(s1, s2, len)    ict_api_strnstr(s1, s2, len)
#define ICT_MEMCMP(s1,s2,len)       ict_api_memcmp(s1,s2,len)
#define ICT_STRCPY(dst,src)	        ict_api_strcpy(dst,src)
#define ICT_STRLCPY(dst, src, len)  ict_api_strlcpy(dst, src, len)
#define ICT_MEMCPY(dst,src,len)     ict_api_memmove(dst,src,len)
#define ICT_MEMMOVE(dst,src,len)    ict_api_memmove(dst,src,len)

#define ICT_MALLOC(size)            ict_api_malloc(size)
#define ICT_FREE(ptr)               ict_api_mfree(ptr)

#define ICT_ASSERT(val)             ict_api_assert(val)
#define ICT_SPRINTF                 ict_api_sprintf
#define ICT_VSPRINTF                ict_api_vsprintf

#define ICT_ATOI(str)               ict_api_atoi(str)
#define ICT_STOI(str, value)        ict_api_str_to_int(str, value)
#define ICT_HSTOI(str, value)       ict_api_hexStr_to_int(str, value)

#define ICT_DELAY_US(usec)          ict_api_delay_us(usec)
#define ICT_DELAY_MS(msec)          ict_api_delay_ms(msec)

// Reset
#define ICT_INTERNAL_IRAM_RESET     0
#define ICT_EXTERNAL_FLASH_RESET    1

// Download State
#define ICT_DOWNLOAD_IDLE           0
#define ICT_DOWNLOAD_FROM_WEB       1
#define ICT_DOWNLOAD_FROM_DM        2

// Maximum Number of User Task
#define ICT_MAX_NUM_OF_USER_TASK    2

#if defined (FEATURE_OTA_SUPP)
#define OTA_MAX_BODY_LEN            1460
#endif

#if defined (FEATURE_HTTPC_SUPP)
/** Maximum length reserved for body */
#ifndef HTTPC_MAX_BODY_LEN
#define HTTPC_MAX_BODY_LEN          1460
#endif
#ifndef UPNP_MAX_IPADDR_LEN
#define UPNP_MAX_IPADDR_LEN       15
#endif
#ifndef UPNP_MAX_DESCRIPTION_LEN
#define UPNP_MAX_DESCRIPTION_LEN  31
#endif
#endif /* FEATURE_HTTPC_SUPP */
#if defined (FEATURE_HTTPC_V2_SUPP)
#ifndef HTTPC_MAX_BODY_LEN
#define HTTPC_MAX_BODY_LEN          1460
#endif
#endif

#if defined (FEATURE_GMMP_SUPP) || defined (FEATURE_MQTT_SUPP) || defined (FEATURE_COAP_SUPP) || defined (FEATURE_MQTT_PAHO_EMB_SUPP) || defined (FEATURE_GIGAIOT_MQTT_SUPP)
#define MAX_PAYLOAD_SIZE    1024
#endif

#if defined (FEATURE_SEP20_SUPP)
#ifndef SEP20_URI_MAX_LEN
#define SEP20_URI_MAX_LEN       80
#endif
#endif /* FEATURE_SEP20_SUPP */

#if defined (CONFIG_P2P)
#ifndef P2P_MAX_WPS_VENDOR_EXT
#define P2P_MAX_WPS_VENDOR_EXT 4
#endif
#ifndef WPS_DEV_TYPE_LEN
#define WPS_DEV_TYPE_LEN 8
#endif
#ifndef WPS_DEV_TYPE_BUFSIZE
#define WPS_DEV_TYPE_BUFSIZE 21
#endif
#endif /* CONFIG_P2P */

#if defined (FEATURE_SW_SPI_MASTER)
#define ICT_SPI_3_WIRED 0xFF
#endif

#define ICT_SC_SN_MASK					0xfff0
#define ICT_SN_BIT_POS					4
#define ICT_SC_SN(val)					(((val)&(ICT_SC_SN_MASK)) >> (ICT_SN_BIT_POS))

#if defined(FEATURE_FILE_SYSTEM_FATFS)
#if defined(FEATURE_FATFS_GENERIC_API)
#define	FILE_ATTR_READ                  0x01
#define	FILE_ATTR_OPEN_EXISTING         0x00

#if 1/*!_FS_READONLY*/
#define	FILE_ATTR_WRITE                 0x02
#define	FILE_ATTR_CREATE_NEW            0x04
#define	FILE_ATTR_CREATE_ALWAYS         0x08
#define	FILE_ATTR_OPEN_ALWAYS           0x10
#define FILE_ATTR__WRITTEN              0x20
#define FILE_ATTR__DIRTY                0x40
#endif
#endif
#endif

/*
******************************************************************************
*	MACRO
******************************************************************************
*/

#define IP2STR(a)   (a)[0], (a)[1], (a)[2], (a)[3]
#define IPSTR       "%d.%d.%d.%d"

#define STR_SZ(a)   (sizeof(a)-1)

#define IP4_ADDR_(addr, addr0, addr1, addr2, addr3)  \
    do{\
        addr[0] = addr0;\
        addr[1] = addr1;\
        addr[2] = addr2;\
        addr[3] = addr3;\
    }while(0)

#define IP4_ADDR_COPY(dst, src)  \
    do{\
        dst[0] = src[0];\
        dst[1] = src[1];\
        dst[2] = src[2];\
        dst[3] = src[3];\
    }while(0)

#define MAX_MTU_SIZE    1460
//#define TX_MAX_SIZE     (offset_of(ICT_ST_HIF_DATA_T, data) + MAX_MTU_SIZE)
//#define TX_SIZE(size)   (offset_of(ICT_ST_HIF_DATA_T, data) + size)
#define TX_MAX_SIZE     (sizeof(ICT_ST_HIF_DATA_T) - 1 + MAX_MTU_SIZE)
#define TX_SIZE(size)   (sizeof(ICT_ST_HIF_DATA_T) - 1 + size)

#define	timeradd(tvp, uvp, vvp)                             \
	do {                                                    \
		(vvp)->tv_sec = (tvp)->tv_sec + (uvp)->tv_sec;      \
		(vvp)->tv_usec = (tvp)->tv_usec + (uvp)->tv_usec;   \
		if ((vvp)->tv_usec >= 1000000) {                    \
			(vvp)->tv_sec++;                                \
			(vvp)->tv_usec -= 1000000;                      \
		}                                                   \
	} while (0)
	
#define	timersub(tvp, uvp, vvp)                             \
	do {                                                    \
		(vvp)->tv_sec = (tvp)->tv_sec - (uvp)->tv_sec;      \
		(vvp)->tv_usec = (tvp)->tv_usec - (uvp)->tv_usec;   \
		if ((vvp)->tv_usec < 0) {                           \
			(vvp)->tv_sec--;                                \
			(vvp)->tv_usec += 1000000;                      \
		}                                                   \
	} while (0)
/*
******************************************************************************
*	DATA TYPE
******************************************************************************
*/

typedef enum
{
    TASK_ID_API_MIN = 12,
#if defined(HOST_STDA_CM_INTERWORKING)
    TASK_ID_API_CM = TASK_ID_API_MIN,
    TASK_ID_API_UAPP,
#endif
#if defined(FEATURE_PICOC_SUPP)
    TASK_ID_API_INTP = TASK_ID_API_MIN,
#endif
    TASK_ID_API_MAX
} TASK_ID_API;

typedef enum
{
    TASK_PRI_API_MIN = 9,
#if defined(HOST_STDA_CM_INTERWORKING)
    TASK_PRI_API_CM = TASK_PRI_API_MIN,
    TASK_PRI_API_UAPP,
#endif
#if defined(FEATURE_PICOC_SUPP)
    TASK_PRI_API_INTP = TASK_PRI_API_MIN,
#endif
    TASK_PRI_API_MAX    
} TASK_PRI_API;

typedef enum
{
    ICT_HIF_CMD_GROUP = 0x1000,
    ICT_HIF_CMD_ST_MAC_ADDR_IND = ICT_HIF_CMD_GROUP,
    ICT_HIF_CMD_ST_SCAN_IND,
    ICT_HIF_CMD_ST_SCAN_RST_IND,
    ICT_HIF_CMD_ST_JOIN_IND,
    ICT_HIF_CMD_ST_DISCONNECTED_IND,
    ICT_HIF_CMD_ST_AP_START_IND,
    ICT_HIF_CMD_ST_AP_STOP_IND,
    ICT_HIF_CMD_ST_STA_ASSOCIATED_IND,
    ICT_HIF_CMD_ST_STA_DISASSOCIATED_IND,
    ICT_HIF_CMD_ST_DM_IND,  /* Not Supported */
    ICT_HIF_CMD_ST_SOCKET_IND, /* 0x100A */
    ICT_HIF_CMD_ST_TCP_DISCONNECT_IND,  // Only for TCP Server...
    ICT_HIF_CMD_ST_WPS_IND,  /* Not Supported (API_WPS_IND_PIN_NUM) */
    ICT_HIF_CMD_ST_WPS_RESULT_IND,
    ICT_HIF_CMD_ST_P2P_DEVICE_FOUND_IND,
    ICT_HIF_CMD_ST_P2P_DEVICE_LOST_IND,
    ICT_HIF_CMD_ST_P2P_GO_NEG_IND, /* 0x1010 */
    ICT_HIF_CMD_ST_P2P_RESULT_IND,  
    ICT_HIF_CMD_ST_NETWORK_INFO_IND,
    ICT_HIF_CMD_ST_DEVICE_READY_IND,
    
    ICT_HIF_CMD_ST_DNSQUERY_IND,
    ICT_HIF_CMD_ST_HTTP_CONTROL_IND,
    ICT_HIF_CMD_ST_HTTP_BODY_IND,
    ICT_HIF_CMD_ST_HTTP_RESPONSECODE_IND,
    ICT_HIF_CMD_ST_UPNP_EXTIP_IND,
    ICT_HIF_CMD_ST_UPNP_EXTIP_ERROR_IND,
    ICT_HIF_CMD_ST_UPNP_ADDPORTMAPPING_IND,
    ICT_HIF_CMD_ST_UPNP_ADDPORTMAPPING_ERROR_IND,
    ICT_HIF_CMD_ST_UPNP_DELPORTMAPPING_IND,
    ICT_HIF_CMD_ST_UPNP_DELPORTMAPPING_ERROR_IND,
    ICT_HIF_CMD_ST_DDNS_GETIPADDR_IND,
    ICT_HIF_CMD_ST_DDNS_GETIPADDR_ERROR_IND,
    ICT_HIF_CMD_ST_DDNS_UPDATE_IND, /* 0x1020 */
    ICT_HIF_CMD_ST_DDNS_UPDATE_ERROR_IND,
    ICT_HIF_CMD_ST_OTA_VERSION_IND,
    ICT_HIF_CMD_ST_OTA_VERSION_FIN_IND,
    ICT_HIF_CMD_ST_OTA_UPDATE_IND,
    ICT_HIF_CMD_ST_OTA_UPDATE_FIN_IND,
    ICT_HIF_CMD_ST_MOTA_CHECKSUM_BODY_IND,
    ICT_HIF_CMD_ST_MOTA_CHECKSUM_FIN_IND,
    ICT_HIF_CMD_ST_MOTA_UPDATE_IND,
    ICT_HIF_CMD_ST_MOTA_UPDATE_FIN_IND,
    ICT_HIF_CMD_ST_HWPS_IND,
    ICT_HIF_CMD_ST_PING_REPLY_IND,
    ICT_HIF_CMD_ST_PING_RESULT_IND,
    ICT_HIF_CMD_ST_UDAP_RESULT_IND,
    ICT_HIF_CMD_ST_SNTP_RESPONSE_IND,
    ICT_HIF_CMD_ST_SNTP_GET_ERROR_IND,
    ICT_HIF_CMD_ST_ALLJOYN_IND,
    ICT_HIF_CMD_ST_XMODEM_IND,
    ICT_HIF_CMD_ST_GMMP_IND,
    ICT_HIF_CMD_ST_GMMP_RECV_DATA_IND,
    ICT_HIF_CMD_ST_RMC_IND,
    ICT_HIF_CMD_ST_MQTT_PUB_IND,
    ICT_HIF_CMD_ST_MQTT_SUB_IND,
    ICT_HIF_CMD_ST_MQTT_PUB_RECV_IND,
    ICT_HIF_CMD_ST_MQTT_SUB_RECV_IND,
    ICT_HIF_CMD_ST_MQTT_IND,
    ICT_HIF_CMD_ST_MQTT_RECV_IND,
    ICT_HIF_CMD_ST_COAP_MSG_IND,
    ICT_HIF_CMD_ST_COAP_MSG_RECV,
    ICT_HIF_CMD_ST_ONEM2M_RECV_IND,
    ICT_HIF_CMD_ST_ONEM2M_IND,
    ICT_HIF_CMD_ST_GIGAIOT_RECV_IND,
    ICT_HIF_CMD_ST_GIGAIOT_IND,
    ICT_HIF_CMD_ST_SEP20_EVENT_IND,
    ICT_HIF_CMD_ST_TCP_SSL_IND,
    ICT_HIF_CMD_ST_TCP_SSL_RECV_IND,
    ICT_HIF_CMD_ST_TCP_SSL_CLOSE_IND,
    ICT_HIF_CMD_ST_TCP_SSL_SVR_IND,
    ICT_HIF_CMD_ST_TCP_SSL_SVR_RECV_IND,
    ICT_HIF_CMD_ST_TCP_SSL_SVR_CLOSE_IND,
    ICT_HIF_CMD_ST_TCP_SSL_SVR_ACCEPTED_IND,
    ICT_HIF_CMD_ST_GCM_RECV_IND,
    ICT_HIF_CMD_ST_VENDOR_USER_IE_IND,
    ICT_HIF_CMD_ST_VENDOR_USER_DATA,    
    ICT_HIF_CMD_ST_BUTTON_PRESSED_IND,    
    ICT_HIF_CMD_ST_BUTTON_RELEASE_IND,    
    ICT_HIF_CMD_ST_HTTP_HEADER_IND,
    ICT_HIF_CMD_ST_DHCP_FAIL_IND,
    ICT_HIF_CMD_MAX,

    ICT_HIF_DATA_MIN = 0x1100,
    ICT_HIF_DATA_RX = ICT_HIF_DATA_MIN,
    ICT_HIF_DATA_MAX,

    ICT_HIT_AT_MIN = 0x1120,
    ICT_HIT_REQ_AT_SHELL = ICT_HIT_AT_MIN,
    ICT_HIT_AT_MAX,

    ICT_HIF_ETC_TASK_DELETE_REQUEST,
    ICT_HIF_ETC_MAX,
} ICT_API_PRIMITIVE_CODE;

typedef PACKED struct _COMMON_MAC_HEADER_TAG
{
	UINT16	frame_control;
	UINT16	duration_id;
	UINT8	address1[6];
	UINT8	address2[6];
	UINT8	address3[6];
	UINT16	sequence_control;
} XTENSA_PACKED ICT_COMMON_MAC_HEADER;

typedef struct _RX_LINK_STATUS_TAG
{
    UINT32      rssi;
    UINT32      sig_pow;
    UINT32      noise_pow;
    UINT32      snr;
    UINT32      rx_count;
    INT32       cfo_err;
    INT32       cfo_err_hz;
    UINT32      sig_info;
} ICT_RX_LINK_STATUS;

#if defined(FEATURE_NV_SYSTEM)
typedef enum
{
#if defined(FEATURE_USE_NV_CM_DATA)
    ICT_CM_NV_ITEM_DATA_LEN,           // 2 bytes
    ICT_CM_NV_ITEM_DATA,               // 1024 bytes
#elif defined (FEATURE_USE_NV_CM_DATA_0_1)
    ICT_CM_NV_ITEM_DATA_LEN,           // 2 bytes
    ICT_CM_NV_ITEM_DATA,               // 512 bytes
#endif
    ICT_NV_ITEM_CM_MAX
} ICT_CM_NV_ITEM_ID;
#endif

typedef enum
{
    ICT_WM_G_ONLY,
    ICT_WM_BG,
    ICT_WM_BGN,
    ICT_WM_B_ONLY,
    ICT_WM_N_ONLY,
    ICT_WM_MAX
} ICT_WM;    // Wireless Mode...

#if defined (FEATURE_COAP_SUPP)
enum
{
    COAP_MODE_HOST,
    COAP_MODE_PORT,
    COAP_MODE_URI,
    COAP_MODE_TOKEN,
    COAP_MODE_TYPE,
    COAP_MODE_CONTENT_TYPES,        
    COAP_MODE_DTLS,
    COAP_MODE_SEC_NAME,
    COAP_MODE_SEC_PASSWORD,
    COAP_MODE_ID,
}; 

enum
{
    COAP_METHOD_GET,
    COAP_METHOD_PUT,
    COAP_METHOD_POST,
    COAP_METHOD_DELETE
};
#endif /* FEATURE_COAP_SUPP */

#if defined (CONFIG_P2P)
typedef struct {
	UINT32 size; /* total size of the allocated buffer */
	UINT32 used; /* length of data in the buffer */
	UINT8  *buf; /* pointer to the head of the buffer */
	UINT32 flags;
	/* optionally followed by the allocated buffer */
}ICT_ST_WPA_BUF_T;

/**
 * struct p2p_peer_info - P2P peer information
 */
typedef struct
{
	/**
	 * p2p_device_addr - P2P Device Address of the peer
	 */
	UINT8 p2p_device_addr[MAC_ADDR_LEN];

	/**
	 * pri_dev_type - Primary Device Type
	 */
	UINT8 pri_dev_type[8];

	/**
	 * device_name - Device Name (0..32 octets encoded in UTF-8)
	 */
	char device_name[33];

	/**
	 * manufacturer - Manufacturer (0..64 octets encoded in UTF-8)
	 */
	char manufacturer[65];

	/**
	 * model_name - Model Name (0..32 octets encoded in UTF-8)
	 */
	char model_name[33];

	/**
	 * model_number - Model Number (0..32 octets encoded in UTF-8)
	 */
	char model_number[33];

	/**
	 * serial_number - Serial Number (0..32 octets encoded in UTF-8)
	 */
	char serial_number[33];

	/**
	 * level - Signal level
	 */
	INT32 level;

	/**
	 * config_methods - WPS Configuration Methods
	 */
	UINT16 config_methods;

	/**
	 * dev_capab - Device Capabilities
	 */
	UINT8 dev_capab;

	/**
	 * group_capab - Group Capabilities
	 */
	UINT8 group_capab;

	/**
	 * wps_sec_dev_type_list - WPS secondary device type list
	 *
	 * This list includes from 0 to 16 Secondary Device Types as indicated
	 * by wps_sec_dev_type_list_len (8 * number of types).
	 */
	UINT8 wps_sec_dev_type_list[32];

	/**
	 * wps_sec_dev_type_list_len - Length of secondary device type list
	 */
	UINT32 wps_sec_dev_type_list_len;

	ICT_ST_WPA_BUF_T *wps_vendor_ext[P2P_MAX_WPS_VENDOR_EXT];

	/**
	 * wfd_subelems - Wi-Fi Display subelements from WFD IE(s)
	 */
	ICT_ST_WPA_BUF_T *wfd_subelems;
}ICT_ST_P2P_PEER_INFO_T;

typedef PACKED struct
{
    UINT8  addr[MAC_ADDR_LEN];
    UINT8  dev_name[33];
    UINT16 config_method;
} XTENSA_PACKED ICT_ST_P2P_DEV_FOUND_T;

typedef struct
{
    UINT8   p2p_peer[MAC_ADDR_LEN];
    UINT16  dev_passwd_id;
} ICT_ST_PEER_GO_REQ_T;

typedef struct
{
    UINT8   p2p_peer[MAC_ADDR_LEN];        
    UINT8   p2p_pin[10];
} ICT_ST_PEER_PIN_T;

#endif /* CONFIG_P2P */

#if defined (FEATURE_GMMP_SUPP) || defined (FEATURE_MQTT_SUPP) || defined (FEATURE_COAP_SUPP) || defined (FEATURE_MQTT_PAHO_EMB_SUPP) || defined (FEATURE_GIGAIOT_MQTT_SUPP)
typedef struct
{
    UINT16  type;   
    UINT16  len;
    UINT8   nms_buf[MAX_PAYLOAD_SIZE];
} ICT_ST_NMS_DATA_T;
#endif

#if defined (FEATURE_SK_PAIRING_SUPP)
typedef struct
{
    UINT8   ssid_len;
    UINT8   ssid[64];
    UINT8   passphrase[32];
} ICT_ST_RMC_INFO_T;
#elif defined (FEATURE_LG_PAIRING_SUPP) || defined (FEATURE_LG_V2_PAIRING_SUPP)
typedef struct
{
    UINT32 code;
} ICT_ST_RMC_INFO_T;

typedef enum
{
    LGU_PAIRING_TCP_ACCEPTED     = 0x0,
    LGU_PAIRING_HOMEAP_INFO_MSG_ERR,
    LGU_PAIRING_RESET_MSG_ERR,
    LGU_PAIRING_DEVICE_INFO_MSG_ERR,
    LGU_PAIRING_SUCCESS_DONE,
} ICT_ST_RMC_CODE_E;
#endif

#if defined (FEATURE_SEP20_SUPP)
typedef struct
{
    UINT8   name[20];
    UINT8   type;
    UINT32  start;
    UINT32  end;
} ICT_ST_SEP20_EVENT_T;
#endif

#if defined (FEATURE_TCP_SSL_SUPP)
typedef struct
{
    UINT16 socket_desc;
    UINT16 type;  
    UINT8  addr[4];
    UINT16 port;
    UINT16 result;
    UINT16 data_len;
    UINT8  data[1];
} ICT_ST_TCP_SSL_IND_T;
#endif

typedef struct 
{
    INT32 (*func_task_primitive_send)(UINT8 network_id, UINT32 from, UINT32 to, UINT32 code, UINT32 length, UINT8 *p_buf);
    INT32 (*func_task_event_send)(UINT32 to, UINT32 event);
} ICT_ST_FUNC_PTR_T;

typedef PACKED struct
{
    UINT8 mac_addr[MAC_ADDR_LEN];
} XTENSA_PACKED ICT_ST_MAC_ADDR_IND_T;

typedef struct
{
    UINT16  dhcp_mode;
    UINT8   ipaddr[4];
    UINT8   subnet[4];
    UINT8   gateway[4];
    UINT8   dns[4];
} ICT_ST_IP_CONFIG_T;

typedef struct
{
    UINT8   ssid[MAX_SSID_LEN];
    UINT32  ssid_len;
    UINT16  *channel;
} ICT_ST_SCAN_REQ_T;

typedef PACKED struct
{
    UINT32 no;      /* Initialed by ZERO, and started from ONE */
    UINT8  ssid[MAX_SSID_LEN];
    UINT8  ssid_len;
    UINT8  bssid[MAC_ADDR_LEN];
    UINT16 ch;
    UINT32 bss_type;
    UINT32 bss_sub_type;
    INT32  rssi;
    INT32  noise;
    UINT8  auth_enc_type;
    UINT8  pairwise_cipher;
    UINT8  group_cipher;
#if defined (FEATURE_SCAN_V2)
    UINT8  pairwise_cipher_2;
    UINT8  b_wps;
    UINT8  wps_type;
#endif
} XTENSA_PACKED ICT_ST_SCAN_IND_T;

typedef struct
{
    UINT8   ssid[MAX_SSID_LEN];
    UINT32  ssid_len;
    UINT8   bssid[MAC_ADDR_LEN];
    UINT16  ch;
    UINT8   auth_type;
    UINT8   auth_enc_type;
    UINT8   pairwise_cipher;
    UINT8   group_cipher;
    UINT8   key_idx;
    UINT8   key[MAX_PSK_LEN];
    UINT32  key_len;
    UINT16  vendor_specific_ie_len;
    UINT8   *p_vendor_specific_ie;
} ICT_ST_JOIN_REQ_T;

typedef PACKED struct
{
    UINT32 result;
} XTENSA_PACKED ICT_ST_JOIN_IND_T;

typedef PACKED struct
{
    UINT32 reason;
} XTENSA_PACKED ICT_ST_DISCONN_IND_T;

typedef struct
{
    UINT8   mac_address[MAC_ADDR_LEN];
    INT32   rssi;
} ICT_ST_STA_INFO_T;

typedef PACKED struct
{
    UINT8 ipaddr[4];
    UINT8 subnet[4];
    UINT8 gateway[4];
    UINT8 dns[4];
} XTENSA_PACKED ICT_ST_NETWORK_INFO_IND_T;

typedef struct
{
    UINT16  socket_type;
    UINT16  local_port;
    UINT16  remote_port;
    UINT8   remote_ipaddr[4];
} ICT_ST_SOCKET_T;

typedef struct
{
    UINT32 reason;
} ICT_ST_DHCP_FAIL_IND_T;

/*
typedef struct
{
    UINT16  socket_type;
    UINT16  local_port;
    UINT16  remote_port;
    UINT8   remote_ipaddr[4];
} ICT_ST_SOCKET_CREATE_T;
*/
typedef struct
{
    INT32   socket_desc;    
} ICT_ST_SOCKET_CLOSE_T;

typedef PACKED struct
{
    UINT16 socket_cmd;
    UINT16 socket_type;
    INT32  socket_desc;
    INT16  result;
} XTENSA_PACKED ICT_ST_SOCKET_IND_T;

typedef struct
{
    UINT8  sa_len;
    UINT8  sa_family;
    UINT16 sa_port;
    UINT8  sa_ipaddr[4];
    UINT8  sa_zero[8];
} ICT_ST_SOCKET_ADDR_T;

typedef struct
{
    INT32  socket_desc;
    ICT_ST_SOCKET_ADDR_T sa;
    INT32  result;
} ICT_ST_TCP_DISCONNECT_IND_T;

typedef enum
{
    API_JOIN_SUCCESS,
    API_JOIN_FAILURE,
    API_JOIN_OTHERS
} APP_CM_JOIN_RESULT;

typedef enum 
{
    API_WPS_IND_SUCCESS = 0,
    API_WPS_IND_FAILURE,    /* timeout */
    API_WPS_IND_PIN_NUM,
} ICT_ST_WPS_IND_E;

typedef struct
{
    UINT8   pin[8];
} ICT_ST_WPS_PIN_T;

typedef PACKED struct
{
    UINT16 result;
    UINT16 len;
    UINT8  data[1];
} XTENSA_PACKED ICT_ST_WPS_IND_T;

typedef PACKED struct
{
    UINT32 result;
    UINT16 ssid_len;
    UINT8  ssid[32];
    UINT16 psk_len;
    UINT8  psk[64];
} XTENSA_PACKED ICT_ST_WPS_RESULT_IND_T;

typedef struct
{
    UINT16  reason;
} ICT_ST_DISCONNECT_T;

typedef PACKED struct
{
    UINT16 reason;
} XTENSA_PACKED ICT_ST_DISCONNECT_IND_T;

/* Data */
typedef enum
{
    HIF_PACKET_DATA     = 1,
    HIF_PACKET_CMD      = 2,
    HIF_PACKET_CMD_IND  = 3
} HIF_PACKET_TYPE;

typedef enum
{
    HIF_SW_TYPE_SMTP    = 0x0,  
    HIF_SW_TYPE_POP3    = 0x1,      
} HIF_SW_TYPE;

typedef enum
{
    HIF_SW_OPT_SOCKET_DATA      = 0x0,
    HIF_SW_OPT_VENDOR_SPECIFIC  = 0x1
} HIF_SW_OPT_TYPE;

#if defined (FEATURE_OTA_SUPP)
typedef struct
{
    UINT16 body_len;
    UINT8  body[OTA_MAX_BODY_LEN];
} ICT_ST_OTA_IND;
#endif

#if defined (FEATURE_OTA_SUPP)
typedef enum
{
    OTA_UPDATE_ST_INIT          = 0x00,
    OTA_UPDATE_ST_ON_GOING,
    OTA_UPDATE_ST_FIN_SUCCESS,
    OTA_UPDATE_ST_FIN_FAIL,
#if 1 // jwpark1, 2019-05-14, Applied update of HTTPC and OTA.
    OTA_UPDATE_ST_FIN_WITHOUT_RESULT,
#endif
    OTA_UPDATE_ST_MAX
} OTA_UPDATE_ST_TYPE;
#endif

#if defined (FEATURE_HTTPC_SUPP)
typedef enum
{
    APP_HTTPC_RESULT_OK = 0,             
    APP_HTTPC_RESULT_ERR_UNKNOWN,
    APP_HTTPC_RESULT_ERR_CONNECT,
    APP_HTTPC_RESULT_ERR_HOSTNAME,
    APP_HTTPC_RESULT_ERR_CLOSED,
    APP_HTTPC_RESULT_ERR_TIMEOUT,
    APP_HTTPC_RESULT_ERR_SVR_RESP,
    APP_HTTPC_RESULT_ERR_INITIALIZE,
    APP_HTTPC_RESULT_ERR_ARGUMENT,
    APP_HTTPC_RESULT_ERR_MEMORY,
    APP_HTTPC_RESULT_SESSION_SUCCESS,
    APP_HTTPC_RESULT_SESSION_CLOSED,
    
    APP_HTTPC_RESULT_MAX
} APP_HTTPC_RESULT;

typedef struct
{
    UINT16 body_len;
    UINT8  body[HTTPC_MAX_BODY_LEN];
} ICT_ST_HTTPC_IND;

#if defined (FEATURE_DDNS_SUPP)
typedef struct
{
    UINT8  ddns_update_result;
    UINT8  ddns_extip[16];
} ICT_ST_DDNS_IND;
#endif /* FEATURE_DDNS_SUPP */
#endif /* FEATURE_HTTPC_SUPP */

#if defined (FEATURE_HTTPC_V2_SUPP)
typedef enum
{
    APP_HTTPC_METHOD_GET = 0,
    APP_HTTPC_METHOD_POST,
    APP_HTTPC_METHOD_PUT,
    
    APP_HTTPC_METHOD_MAX
} APP_HTTPC_METHOD_E;
typedef enum
{
    APP_HTTPC_IND_RESULT = 0,
    APP_HTTPC_IND_RESPONSECODE,
    APP_HTTPC_IND_HEADER,
    
    APP_HTTPC_IND_MAX
} APP_HTTPC_IND_E;
typedef enum
{
    APP_HTTPC_RESULT_OK = 0,             
    APP_HTTPC_RESULT_ERR_UNKNOWN,
    APP_HTTPC_RESULT_ERR_CONNECT,
    APP_HTTPC_RESULT_ERR_HOSTNAME,
    APP_HTTPC_RESULT_ERR_CLOSED,
    APP_HTTPC_RESULT_ERR_TIMEOUT,
    APP_HTTPC_RESULT_ERR_SVR_RESP,
    APP_HTTPC_RESULT_ERR_INITIALIZE,
    APP_HTTPC_RESULT_ERR_ARGUMENT,
    APP_HTTPC_RESULT_ERR_MEMORY,
    APP_HTTPC_RESULT_SESSION_SUCCESS,
    APP_HTTPC_RESULT_SESSION_CLOSED,
    APP_HTTPC_RESULT_OK_SVR_RESP,
    
    APP_HTTPC_RESULT_MAX
} APP_HTTPC_RESULT_E;
typedef struct
{
    UINT16 body_len;
    UINT8  body[HTTPC_MAX_BODY_LEN];
} ICT_ST_HTTPC_IND;
#endif /* FEATURE_HTTPC_V2_SUPP */

#if defined (FEATURE_PING_SUPP)
typedef struct
{
    UINT8  ipaddr[4];
    UINT16 ping_data_len;
    UINT32 ping_time;
    UINT32 repeat_num;
    UINT32 ping_result;
} ICT_ST_PING_DATA_INFO_T;
#endif

typedef PACKED struct
{
    UINT16 socket_type;    
    INT32  socket_desc;    
    UINT16 remote_port;
    UINT8  remote_ipaddr[4];
    UINT32 data_len;
} XTENSA_PACKED ICT_ST_SOCK_INFO_T;

typedef PACKED struct
{
    UINT16 socket_type;    
    INT32  socket_desc;    
    UINT16 remote_port;
    UINT8  remote_ipaddr[4];
    UINT32 data_len;
    UINT8  data[1];
} XTENSA_PACKED ICT_ST_HIF_DATA_T;

typedef struct{
    UINT32 _11b_rx_sensitivity;
    UINT32 _11n_rx_sensitivity;
    UINT32 static_data_rates;
    UINT32 max_data_rates;
} ICT_ST_TRAFFIC_INFO_T;

#if defined (FEATURE_SNTP_SUPP)
typedef struct
{
    UINT8* sntp_result;
    time_t gtc_result;
} ICT_ST_SNTP_INFO_T;
#endif

#if !defined (CHIP_WF6000)
typedef struct _ICT_OTP_MEMORY
{
    UINT8   ver;           // 1
    UINT8   size;          // 1
    UINT8   mac_addr[6];   // 6   Ver. 1
    UINT16  crc;           // 2
} ICT_OTP_MEMORY;
#endif

typedef enum
{
    WIFISUPP_RESULT_SUCC,           //success
    WIFISUPP_RESULT_FAIL,           //fail
    WIFISUPP_RESULT_NOT_FOUND,      //the AP is not found
    WIFISUPP_RESULT_TIMEOUT,        //operation time out
    WIFISUPP_RESULT_RESTRICTED,     //connection is restricted
    WIFISUPP_RESULT_WPS_FAILED,     //wps failed 
    WIFISUPP_RESULT_MAX
} WIFISUPP_RESULT_E;

#if defined(FEATURE_FILE_SYSTEM_FATFS)
/* File function return code */
typedef enum {
    FS_RESULT_OK = 0,               /* (0) Succeeded */
    FS_RESULT_DISK_ERR,             /* (1) A hard error occurred in the low level disk I/O layer */
    FS_RESULT_INT_ERR,              /* (2) Assertion failed */
    FS_RESULT_NOT_READY,            /* (3) The physical drive cannot work */
    FS_RESULT_NO_FILE,              /* (4) Could not find the file */
    FS_RESULT_NO_PATH,              /* (5) Could not find the path */
    FS_RESULT_INVALID_NAME,         /* (6) The path name format is invalid */
    FS_RESULT_DENIED,               /* (7) Access denied due to prohibited access or directory full */
    FS_RESULT_EXIST,                /* (8) Access denied due to prohibited access */
    FS_RESULT_INVALID_OBJECT,       /* (9) The file/directory object is invalid */
    FS_RESULT_WRITE_PROTECTED,      /* (10) The physical drive is write protected */
    FS_RESULT_INVALID_DRIVE,        /* (11) The logical drive number is invalid */
    FS_RESULT_NOT_ENABLED,          /* (12) The volume has no work area */
    FS_RESULT_NO_FILESYSTEM,        /* (13) There is no valid FAT volume */
    FS_RESULT_MKFS_ABORTED,         /* (14) The f_mkfs() aborted due to any parameter error */
    FS_RESULT_TIMEOUT,              /* (15) Could not get a grant to access the volume within defined period */
    FS_RESULT_LOCKED,               /* (16) The operation is rejected according to the file sharing policy */
    FS_RESULT_NOT_ENOUGH_CORE,      /* (17) LFN working buffer could not be allocated */
    FS_RESULT_TOO_MANY_OPEN_FILES,  /* (18) Number of open files > _FS_SHARE */
    FS_RESULT_INVALID_PARAMETER     /* (19) Given parameter is invalid */
} FS_RESULT_T;

#if defined(FEATURE_FATFS_GENERIC_API)
/* File system object structure */
typedef struct {
    UINT8   fs_type;        /* FAT sub-type (0:Not mounted) */
    UINT8   drv;            /* Physical drive number */
    UINT8   csize;          /* Sectors per cluster (1,2,4...128) */
    UINT8   n_fats;         /* Number of FAT copies (1 or 2) */
    UINT8   wflag;          /* win[] flag (b0:dirty) */
    UINT8   fsi_flag;       /* FSINFO flags (b7:disabled, b0:dirty) */
    UINT16  id;             /* File system mount ID */
    UINT16  n_rootdir;      /* Number of root directory entries (FAT12/16) */
#if 0/*_MAX_SS != _MIN_SS*/
    UINT16  ssize;          /* Bytes per sector (512, 1024, 2048 or 4096) */
#endif
#if 0/*_FS_REENTRANT*/
    _SYNC_t sobj;           /* Identifier of sync object */
#endif
#if 1/*!_FS_READONLY*/
    UINT32  last_clust;     /* Last allocated cluster */
    UINT32  free_clust;     /* Number of free clusters */
#endif
#if 2/*_FS_RPATH*/
    UINT32  cdir;           /* Current directory start cluster (0:root) */
#endif
    UINT32  n_fatent;       /* Number of FAT entries (= number of clusters + 2) */
    UINT32  fsize;          /* Sectors per FAT */
    UINT32  volbase;        /* Volume start sector */
    UINT32  fatbase;        /* FAT start sector */
    UINT32  dirbase;        /* Root directory start sector (FAT32:Cluster#) */
    UINT32  database;       /* Data start sector */
    UINT32  winsect;        /* Current sector appearing in the win[] */
    UINT8   win[4096/*_MAX_SS*/];   /* Disk access window for Directory, FAT (and file data at tiny cfg) */
} FS_FATFS_T;

/* File object structure */
typedef struct {
    FS_FATFS_T  *fs;        /* Pointer to the related file system object (**do not change order**) */
    UINT16      id;         /* Owner file system mount ID (**do not change order**) */
    UINT8       flag;       /* File status flags */
    UINT8       err;        /* Abort flag (error code) */
    UINT32      fptr;       /* File read/write pointer (Zeroed on file open) */
    UINT32      fsize;      /* File size */
    UINT32      sclust;     /* File data start cluster (0:no data cluster, always 0 when fsize is 0) */
    UINT32      clust;      /* Current cluster of fpter */
    UINT32      dsect;      /* Current data sector of fpter */
#if 1/*!_FS_READONLY*/
    UINT32      dir_sect;   /* Sector containing the directory entry */
    UINT8       *dir_ptr;   /* Pointer to the directory entry in the window */
#endif
#if 0/*_USE_FASTSEEK*/
    UINT32      *cltbl;     /* Pointer to the cluster link map table (Nulled on file open) */
#endif
#if 0/*_FS_LOCK*/
    UINT32      lockid;     /* File lock ID (index of file semaphore table Files[]) */
#endif
#if 1/*!_FS_TINY*/
    UINT8       buf[4096/*_MAX_SS*/];   /* File data read/write buffer */
#endif
} FS_FILE_T;
#endif /* FEATURE_FATFS_GENERIC_API */
#endif /* FEATURE_FILE_SYSTEM_FATFS */

/*
******************************************************************************
*	GLOBAL VARIABLE
******************************************************************************
*/

#if defined (HOST_STDA_CM_INTERWORKING)
extern const SHELL_CNTX shell_cm_cmd_list[];
#endif

#if defined (FEATURE_PICOC_SUPP)
extern const SHELL_CNTX shell_intp_cmd_list[];
#endif

extern UINT32 sw_ver_cm;
extern UINT8  *p_sw_ver_info;

/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/

/* PICOC */
#if defined (FEATURE_PICOC_SUPP)
INT32 ict_api_picoc_main (char * SourceStr, int len);
#endif /* FEATURE_PICOC_SUPP */

/* SYSTEM */
extern void ict_api_sys_boot_reset(UINT32 reset_opt);
extern INT32 ict_api_sys_get_fw_download_state(void);

/* GPIO */
extern void ict_api_sys_gpio0_set_pad(UINT8 gpio, BOOL enable);
extern UINT16 ict_api_sys_gpio0_get_pad(void);

extern void ict_api_sys_gpio0_set_direction(UINT8 gpio, UINT16 dir);
extern UINT16 ict_api_sys_gpio0_get_direction(void);

extern void ict_api_sys_gpio0_set_output(UINT8 gpio, UINT16 output);
extern BOOL ict_api_sys_gpio0_get_output(UINT8 gpio);

extern BOOL ict_api_sys_gpio0_get_input(UINT8 gpio);

#if defined (CHIP_WF6000)
extern void ict_api_sys_gpio_set_pad(UINT8 gpio, BOOL enable);
extern UINT32 ict_api_sys_gpio_get_pad(void);

/* Pull-up setting */
/* Pull-down setting */
/* Drive Strength setting (00[2.4mA], 01[4.8mA], 10[7.2mA], 11[9.6mA])*/
extern INT8 ict_api_sys_gpio_config(UINT8 gpio_no, UINT8 pullup_on, UINT8 pulldown_on, UINT8 strength);

extern void ict_api_sys_gpio_set_direction(UINT8 gpio, UINT16 dir);
extern UINT32 ict_api_sys_gpio_get_direction(void);

extern void ict_api_sys_gpio_set_output(UINT8 gpio, UINT16 output);
extern BOOL ict_api_sys_gpio_get_output(UINT8 gpio);

extern BOOL ict_api_sys_gpio_get_input(UINT8 gpio);
extern void ict_api_sys_gpio_set_sensitivity(UINT8 gpio, UINT16 sensitivity);
extern UINT32 ict_api_sys_gpio_get_sensitivity(void);

extern void ict_api_sys_gpio_set_ipolarity(UINT8 gpio, UINT16 int_pol);
extern UINT32 ict_api_sys_gpio_get_ipolarity(void);

//extern void ict_api_sys_gpio_enable(UINT8 gpio);
/* this interrupt_callback function MUST NOT SF_RELOCATION!! */
void ict_api_sys_gpio_enable(UINT8 gpio, void (*interrupt_callback)(void));
extern void ict_api_sys_gpio_disable(UINT8 gpio);
#endif

#if 1
extern void ict_api_sys_gpio0_set_sensitivity(UINT8 gpio, UINT16 sensitivity);
extern UINT16 ict_api_sys_gpio0_get_sensitivity(void);

extern void ict_api_sys_gpio0_set_ipolarity(UINT8 gpio, UINT16 int_pol);
extern UINT16 ict_api_sys_gpio0_get_ipolarity(void);

//extern void ict_api_sys_gpio0_enable(UINT8 gpio);
/* this interrupt_callback function MUST NOT SF_RELOCATION!! */
extern void ict_api_sys_gpio0_enable(UINT8 gpio, void (*interrupt_callback)(void));
extern void ict_api_sys_gpio0_disable(UINT8 gpio);
#endif

/* UART */
#if defined (FEATURE_USE_UART0_CM) || defined (FEATURE_USE_UART1_CM) || defined (FEATURE_USE_UART1_INTP) || \
    defined (FEATURE_USE_UART2_CM) || defined (FEATURE_USE_UART2_INTP) || defined (SDK_VER_2)
extern void ict_api_uart_init(UINT32 port);
extern void ict_api_uart_open(UINT32 port);
extern void ict_api_uart_close(UINT32 port);
extern void ict_api_uart_reg_rx_callback(UINT32 port, void (*rxCallBack)(void));
extern void ict_api_uart_change_baudrate(UINT32 port, UINT32 baudRate, UINT16 lcr_val);
extern UINT32 ict_api_uart_get_baudrate(UINT32 port);
extern INT32 ict_api_uart_is_rx_empty(UINT32 port);
extern INT32 ict_api_uart_is_tx_busy(UINT32 port);
extern INT32 ict_api_uart_gets(UINT32 port, char *buff, UINT32 maxLen);
extern UINT8 ict_api_uart_getc(UINT32 port);
extern void ict_api_uart_direct_send_w_size(UINT32 port, UINT8 *str, UINT32 size);
#if defined (CHIP_WF5000)
extern void ict_api_uart_set_rs485_tx_enable_pin(UINT32 port, UINT8 gpio); // If Port Tx is available, gpio = high, otherwise, gpio = low ... 
extern void ict_api_uart_set_rs485_delay_time (UINT32 port, UINT32 pre_us, UINT32 post_us);
#elif defined (CHIP_WF6000)
extern UINT8 ict_api_uart_set_rs485_enable(UINT32 port, UINT8 preDelayBit, UINT8 postDelayBit, UINT8 txEnPolarity);
#endif

#if defined(SUPPORT_HW_SLEEP)
extern INT32 ict_api_send_uart_traffic_handler(UINT32 uart_traffic);
#endif
#endif  /* FEATURE_USE_UART0_CM || FEATURE_USE_UART1_CM || FEATURE_USE_UART1_INTP || FEATURE_USE_UART2_CM || FEATURE_USE_UART2_INTP */

/* Serial Flash */
#if defined(FEATURE_FLASH_SHELL)
extern BOOL ict_api_flash_cmd_read_address (UINT8 * p_buffer, UINT32 rdAddr, UINT32 numBytesToRead);
extern BOOL ict_api_flash_cmd_erase (UINT32 offset, UINT32 len);
extern BOOL ict_api_flash_cmd_erase_64K (UINT32 offset);
extern BOOL ict_api_flash_cmd_write_multi (UINT32 offset, UINT8 *buf, UINT32 len);
extern BOOL ict_api_flash_cmd_read_crc(UINT32 bank_id, UINT16 *crc16_iram, UINT16 *crc16_dram, UINT16 *crc16_sf);
#endif /* FEATURE_FLASH_SHELL */

#if defined (AB5_WDT) || defined (FEATURE_WDT)
extern void ict_api_wdt_init(UINT32 timeout_ms, BOOL interrupt_en);
extern void ict_api_wdt_start(void);
extern void ict_api_wdt_refresh(void);
extern void ict_api_wdt_stop(void);
extern BOOL ict_api_wdt_reset_check(void);
#endif

/* File System */
#if defined(FEATURE_FILE_SYSTEM_FATFS)
//extern UINT32 ict_api_fs_scan_files();
extern UINT32 ict_api_fs_scan_files(char *path, UINT32 max_count, UINT8 *out_buf, UINT32 *out_count);
extern UINT32 ict_api_fs_disk_free_space(UINT32 * total_KB);
extern UINT32 ict_api_fs_write_file(char *pFileName, UINT32 fsize, UINT8* f_buff, UINT32 *num_written);
extern UINT32 ict_api_fs_read_file_size(char *pFileName);
extern UINT32 ict_api_fs_read_file(char *pFileName, void* f_buff, UINT32 *num_size);
extern UINT32 ict_api_fs_mkdir(char *pFileName);
extern UINT32 ict_api_fs_remove(char *pFileName);
#if defined(FEATURE_FATFS_GENERIC_API)
extern FS_RESULT_T ict_api_fatfs_open_file(FS_FILE_T *fp, const char *path, UINT8 mode);
extern FS_RESULT_T ict_api_fatfs_close_file(FS_FILE_T *fp);
extern FS_RESULT_T ict_api_fatfs_read_file(FS_FILE_T *fp, void *buff, UINT32 btr, UINT32 *br);
extern FS_RESULT_T ict_api_fatfs_write_file(FS_FILE_T *fp, const void *buff, UINT32 btw, UINT32 *bw);
extern UINT32 ict_api_fatfs_get_file_size(FS_FILE_T *fp);
#endif /* FEATURE_FATFS_GENERIC_API */
#endif /* FEATURE_FILE_SYSTEM_FATFS */

/* NVMEM */
#if defined(FEATURE_NV_SYSTEM)
extern void ict_api_nv_rebuild(UINT32 b_init);
extern BOOL ict_api_nv_write (ICT_CM_NV_ITEM_ID nv_id, void *data, UINT32 size);
extern BOOL ict_api_nv_read (ICT_CM_NV_ITEM_ID nv_id, void *data, UINT32 size);
extern BOOL ict_api_nv_set_apnet (UINT8 *ip, UINT8 *subnet, UINT8 *gateway, UINT8 *lease_ip_min, UINT8 *lease_ip_max);
extern BOOL ict_api_nv_get_apnet(UINT8 *ip, UINT8 *subnet, UINT8 *gateway, UINT8 *lease_ip_min, UINT8 *lease_ip_max);
extern BOOL ict_api_nv_set_httpd_server_port(UINT16 port);
extern BOOL ict_api_nv_get_httpd_server_port(UINT16 *port);
extern BOOL ict_api_nv_set_country_code(UINT8 *country_code);
extern BOOL ict_api_nv_get_country_code(UINT8 *country_code);
extern BOOL ict_api_nv_set_roam_rssi(UINT8 *roam_rssi);
extern BOOL ict_api_nv_get_roam_rssi(UINT8 *roam_rssi);
extern BOOL ict_api_nv_set_auconmode(UINT8 *conn_mode);
extern BOOL ict_api_nv_get_auconmode(UINT8 *conn_mode);
#if defined (CHIP_WF6000)
extern BOOL ict_api_nv_get_mac_addr(UINT8 *mac_addr);
extern BOOL ict_api_nv_set_mac_addr(UINT8 *mac_addr);
#else
extern BOOL ict_api_otp_get_mac_addr(ICT_OTP_MEMORY *otp_value);
extern BOOL ict_api_otp_set_mac_addr(UINT8 *mac_addr);
#endif
#if defined(FEATURE_SNTP_SUPP)
extern BOOL ict_api_nv_set_sntp_svr_addr1(UINT8 *svr_addr, UINT32 len);
extern BOOL ict_api_nv_set_sntp_svr_addr2(UINT8 *svr_addr, UINT32 len);
extern BOOL ict_api_nv_set_sntp_svr_addr3(UINT8 *svr_addr, UINT32 len);
extern BOOL ict_api_nv_set_sntp_time_offset(INT16 time_offset);
#endif /* FEATURE_SNTP_SUPP */
#if defined (FEATURE_USE_NV_CM_DATA_0_1)
extern BOOL ict_api_nv_get_cm_data(UINT8 *cm_data, UINT8 size);
extern BOOL ict_api_nv_set_cm_data(UINT8 *cm_data, UINT8 size);
#endif
extern BOOL ict_api_nv_get_filter_bssid(UINT8 *bssid, UINT8 size);
extern BOOL ict_api_nv_set_filter_bssid(UINT8 *bssid, UINT8 size);
#endif /* FEATURE_NV_SYSTEM */

/* UTILES */
extern void ict_api_assert(UINT32 val);
extern int ict_api_sprintf(char *buf, const char *fmt, ...);
extern int ict_api_vsprintf(char *buf, const char *fmt, va_list args);
extern void ict_api_memcpy(void *desc, void *src, int length);
extern void ict_api_memmove(void *desc, void *src, int length);
extern int ict_api_atoi(char *str);
extern void *ict_api_memset(void *str, int c, size_t n);
extern int ict_api_memcmp(const void *str1, const void *str2, size_t n);
extern char *ict_api_strcpy(char *s1, const char *s2);
extern int ict_api_strlen(const char *s);
extern int ict_api_strlen_w_sep(const char *s, const char sep);
extern INT8 ict_api_strcmp(const char *s1, const char *s2);
extern INT8 ict_api_strncmp(const char *s1, const char *s2, size_t n);
extern INT8 ict_api_strcasecmp(const char *s1, const char *s2);
extern INT8 ict_api_strncasecmp(const char *s1, const char *s2, size_t n);
extern char *ict_api_strstr(const char *in, const char *str);
extern char *ict_api_strnstr(const char *s, const char *find, size_t slen);
extern UINT32 ict_api_strlcpy(char *dst, const char *src, size_t maxlen);
extern void *ict_api_malloc(UINT32 size);
extern void ict_api_mfree(void *ptr);
extern UINT32 ict_api_get_mac_memory_usage();
extern UINT32 ict_api_get_lmac_des_count();
extern BOOL ict_api_str_to_int (char *str, UINT32 *value);
extern BOOL ict_api_hexStr_to_int (char *str, UINT32 *value);
extern BOOL ict_api_hexStr_to_int_n (char *str, UINT8 *value, UINT32 cnt);
extern void ict_api_delay_us (UINT32 usec);
extern void ict_api_delay_ms (UINT32 msec);

typedef struct timeval  Timeval;
extern void ict_api_gettimeofday(Timeval *t, void* timezone);

/* Linked List */
extern void ict_api_initialize_linked_list(T_LIST *list);
extern BOOL ict_api_linked_list_empty(T_LIST *list);
extern void ict_api_insert_head_list(T_LIST *list, PLIST_ENTRY entry);
extern void ict_api_insert_tail_list(T_LIST * list, PLIST_ENTRY entry);
extern PLIST_ENTRY ict_api_remove_head_list(T_LIST *list);
extern PLIST_ENTRY ict_api_remove_tail_list(T_LIST *list);
extern PLIST_ENTRY ict_api_get_head_list(T_LIST *list);
extern PLIST_ENTRY ict_api_get_tail_list(T_LIST *list);
extern void ict_api_insert_front_list(T_LIST *list, PLIST_ENTRY pEntry, PLIST_ENTRY pNewEntry);
extern void ict_api_remove_list_entry(T_LIST *list, PLIST_ENTRY pEntry);
extern void ict_api_move_tail_all_list(T_LIST *destList, T_LIST *srcList);
extern UINT32 ict_api_get_count_from_list(T_LIST *list);

/* DM Shell */
extern char *ict_api_dm_shell_get_token (char *pInStr, char *pOutToken);

/* Debug */
extern UINT32 ict_api_debug_get_timestamp (void);
extern void ict_api_debug_set_poll_mode (BOOL b_poll);
extern UINT32 ict_api_debug_get_poll_mode (void);
extern void ict_api_debug_set_md_level (UINT32 level);
//extern UINT32 ict_api_debug_get_md_level (void);
extern void ict_api_debug_set_fd_enable(UINT32 mask);
//extern UINT32 ict_api_debug_get_fd_enable(void);
//extern void ict_api_debug_set_dm_shell_disable (BOOL disable);
//extern BOOL ict_api_debug_get_dm_shell_disable (void);
extern INT32 ict_api_debug_dm_enable(BOOL enable, void (*rxCallBack)(void), UINT32 baudRate);
extern void ict_api_debug_dm_hif_printf (char *fmt,...);
extern void ict_api_debug_trace0 (const char *str);
extern void ict_api_debug_trace1 (const char *str, UINT32 val1);
extern void ict_api_debug_trace2 (const char *str, UINT32 val1, UINT32 val2);
extern void ict_api_debug_trace3 (const char *str, UINT32 val1, UINT32 val2, UINT32 val3);
extern void ict_api_debug_trace4 (const char *str, UINT32 val1, UINT32 val2, UINT32 val3, UINT32 val4);

extern void ict_api_printf_memory_map();
extern void ict_api_tn_stack_check_usage();

/* OS */
extern TN_TCB *ict_api_tn_get_curr_run_task();
extern int ict_api_tn_task_create(TN_TCB *task, const char *name, void (*main_func)(void *arg),
                                 void *arg, OS_STK *stack_bottom, UINT32 stack_size, INT32 pri);
extern int ict_api_tn_task_delete(TN_TCB *task);
extern void ict_api_tn_task_sleep(INT32 msecs);
extern int ict_api_tn_task_wake(TN_TCB *task);
extern void ict_api_tn_task_suspend(TN_TCB *task);
extern void ict_api_tn_task_resume(TN_TCB *task);
extern int ict_api_tn_task_event_create(TN_EVENT *event, OS_FLAGS flags);
extern int ict_api_tn_task_event_set(TN_EVENT *event, OS_FLAGS flags);
extern OS_FLAGS ict_api_tn_task_event_wait(TN_EVENT *event, OS_FLAGS flags, INT16 timeout);
extern void ict_api_tn_context_force_switch(void);

extern int ict_api_tn_create_semaphore( TN_SEM *sem, UINT32 initial_count, UINT32 max_count);
extern int ict_api_tn_delete_semaphore( TN_SEM *sem);
extern int ict_api_tn_obtain_semaphore( TN_SEM *sem, UINT32 suspend);
extern int ict_api_tn_release_semaphore( TN_SEM *sem);

extern int ict_api_tn_create_queue(TN_DQUE *que, void ** data_fifo, int num);
extern int ict_api_tn_delete_queue(TN_DQUE *dque);
extern int ict_api_tn_send_queue(TN_DQUE *dque, void *data_ptr, unsigned int timeout);
extern int ict_api_tn_receive_queue(TN_DQUE *dque, void ** data_ptr, unsigned int timeout);
extern int ict_api_tn_get_msgs_waiting(TN_DQUE *dque);

extern int ict_api_tn_mutex_create(TN_MUTEX *mutex);
extern int ict_api_tn_mutex_delete(TN_MUTEX *mutex);
extern int ict_api_tn_mutex_lock(TN_MUTEX *mutex, UINT32 timeout);
extern int ict_api_tn_mutex_unlock(TN_MUTEX *mutex);

extern void ict_api_tn_enter_critical_section(void);
extern void ict_api_tn_exit_critical_section(void);
extern void ict_api_tn_disable_all_interrupts(void);
extern void ict_api_tn_enable_all_interrupts(void);

extern void ict_api_tn_scheduler_lock();
extern void ict_api_tn_scheduler_unlock();
extern void ict_api_tn_version(char *str);


extern OS_FLAG_GRP *ict_api_os_flag_create(OS_FLAGS flags, UINT8 *err);
extern void ict_api_os_flag_post(OS_FLAG_GRP *pgrp, OS_FLAGS flags, UINT8 opt, UINT8 *err);
extern OS_FLAGS ict_api_os_flag_pend (OS_FLAG_GRP *pgrp, OS_FLAGS flags, UINT8 wait_type, UINT16 timeout, UINT8 *err);

extern void ict_api_os_primitive_queue_create (T_LIST *primitive_queue);
extern BOOL ict_api_os_primitive_queue_empty (T_LIST *primitive_queue);

extern void ict_api_os_task_create_ext(void (*task)(void *p_arg), void *p_arg, OS_STK *ptos, 
                            UINT8 prio, UINT16 id, OS_STK *pbos, UINT32 stk_size, void *pext, UINT16 opt);
extern void ict_api_os_task_name_set (UINT8 prio, UINT8 *pname, UINT8 *err);

extern void ict_api_os_sched_lock (void);
extern void ict_api_os_sched_unlock (void);

extern void ict_api_os_time_delay (UINT16 ticks);

extern UINT32 ict_api_get_os_ticks_per_msec();
extern UINT32 ict_api_get_os_msec_per_tick();
extern UINT32 ict_api_get_os_tick();

/* Tasks & Primitives */
extern void ict_api_task_enqueue_primitive(T_LIST *primitive_queue, T_MAC_EVENT *p_mac_event);
extern T_MAC_EVENT *ict_api_task_dequeue_primitive(T_LIST *primitive_queue);

extern T_MAC_EVENT *ict_api_task_allocate_primitive(void);
extern void ict_api_task_free_primitive(T_MAC_EVENT *p_mac_event);

extern void ict_api_task_send_func_ptr_set(ICT_ST_FUNC_PTR_T *p_st_func_ptr);
extern INT32 ict_api_task_primitive_send(UINT32 from, UINT32 to, UINT32 code, UINT32 length, UINT8 *p_buf);
extern INT32 ict_api_task_event_send(UINT32 to, UINT32 event);
extern INT32 ict_api_task_primitive_receive(T_MAC_EVENT * p_event);
extern void ict_api_task_ready(void);

/* SW Timers */
extern void ict_api_sw_timer_init  (SW_TIMER_CNTX *pTimerCntx, SW_TIMER *pTimerList, UINT32 noOfTimer, UINT32 baseInterval, OS_FLAG_GRP *pRcvTaskFlag);
extern UINT32 ict_api_sw_timer_start (SW_TIMER_CNTX *pTimerCntx, UINT32 timerId, UINT32 bPeriod, UINT32 interval, SW_TIMER_CALLBACK timerCb);
extern UINT32 ict_api_sw_timer_stop (SW_TIMER_CNTX *pTimerCntx, UINT32 timerId);
extern void ict_api_sw_timer_task_proc (SW_TIMER_CNTX *pTimerCntx);
extern UINT32 ict_api_sw_timer_get_status(SW_TIMER_CNTX *pTimerCntx, UINT32 timerId);
extern UINT32 ict_api_sw_timer_get_expire_cnt(SW_TIMER_CNTX *pTimerCntx, UINT32 timerId);

/* External Timers */
extern void ict_api_ext_hw_timer_start(UINT32 timer_ms);
extern void ict_api_ext_hw_timer_stop(void);
extern void ict_api_ext_sw_timer_init  (SW_TIMER_CNTX *pTimerCntx, SW_TIMER *pTimerList, UINT32 noOfTimer, OS_FLAG_GRP *pRcvTaskFlag, UINT32 priority);
extern UINT32 ict_api_ext_sw_timer_start (SW_TIMER_CNTX *pTimerCntx, UINT32 timerId, UINT32 bPeriod, UINT32 interval, SW_TIMER_CALLBACK timerCb);
extern UINT32 ict_api_ext_sw_timer_stop (SW_TIMER_CNTX *pTimerCntx, UINT32 timerId);
extern void ict_api_ext_sw_timer_task_proc (SW_TIMER_CNTX *pTimerCntx);
extern UINT32 ict_api_ext_sw_timer_get_status(SW_TIMER_CNTX *pTimerCntx, UINT32 timerId);
extern UINT32 ict_api_ext_sw_timer_get_expire_cnt(SW_TIMER_CNTX *pTimerCntx, UINT32 timerId);

/* MIB */
extern UINT32 ict_api_mac_mib_get_wifi_cfg(T_WIFI_CFG cmd, void *p_param, UINT8 *p_len);
extern void ict_api_mac_mib_set_wifi_cfg(T_WIFI_CFG cmd, void *p_param, UINT8 len);
extern void ict_api_mac_mib_get_wifi_cfg_ext(UINT8 type, T_WIFI_CFG cmd, void *p_param, UINT32 *p_len);
extern void ict_api_mac_mib_set_wifi_cfg_ext(UINT8 type, T_WIFI_CFG cmd, void *p_param, UINT32 *p_len);
extern UINT32 ict_api_mac_get_snr(void);

/* STA */
extern BOOL ict_api_sta_set_antenna_type(UINT16 antenna_type);
extern BOOL ict_api_sta_get_antenna_type(UINT16 *antenna_type);
extern INT32 ict_api_sta_get_traffic_info(ICT_ST_TRAFFIC_INFO_T *traffic_info);
extern INT32 ict_api_sta_get_rx_rssi(UINT8 *p_mac_addr);
extern INT32 ict_api_sta_set_tx_pwr_decrement (UINT32 dec_tx_pwr_dB);
extern INT32 ict_api_sta_get_tx_pwr_decrement (void);
extern INT32 ict_api_sta_set_ps_mode (UINT8 power_save_mode);
extern UINT8 ict_api_sta_get_ps_mode (void);
extern INT32 ict_api_sta_set_wireless_mode (ICT_WM wireless_mode);
extern INT32 ict_api_sta_get_wireless_mode (void);
extern void ict_api_sta_set_extra_rssi_margin(INT8 ext_margin);
extern INT8 ict_api_sta_get_extra_rssi_margin(void);

#if defined (CONFIG_P2P)
extern UINT8 *ict_api_sta_get_p2p_config (void);
extern UINT8 *ict_api_sta_get_p2p_pin (void);
#endif /* CONFIG_P2P */

#if defined (FEATURE_DDNS_SUPP)
extern void ict_api_sta_ddns_rsp_set(ICT_ST_DDNS_IND *ddns_ind);
#endif /* FEATURE_DDNS_SUPP */
#if defined (FEATURE_MQTT_SUPP) || defined (FEATURE_MQTT_PAHO_EMB_SUPP)
extern T_NMS_MQTT_MIB *ict_api_sta_mqtt_get(void);
extern INT32 ict_api_sta_mqtt_set(UINT32 type, UINT8 *buf, UINT32 buf_len);
#endif /* FEATURE_MQTT_SUPP || FEATURE_MQTT_PAHO_EMB_SUPP */
#if defined (FEATURE_ONEM2M_SUPP)
extern T_ONEM2M_MIB *ict_api_sta_onem2m_get(void);
extern INT32 ict_api_sta_onem2m_set(UINT32 type, UINT8 *buf, UINT32 buf_len);
#endif /* FEATURE_ONEM2M_SUPP */
#if defined (FEATURE_GIGAIOT_MQTT_SUPP)
extern T_NMS_GIGAIOT_MIB *ict_api_sta_gigaiot_get(void);
extern INT32 ict_api_sta_gigaiot_set(UINT32 type, UINT8 *buf, UINT32 buf_len);
#endif /* FEATURE_GIGAIOT_MQTT_SUPP */
#if defined (FEATURE_COAP_SUPP)
T_NMS_COAP_MIB *ict_api_sta_coap_get(void);
INT32 ict_api_sta_coap_set(UINT32 type, UINT8 *buf, UINT32 buf_len);
INT32 ict_api_sta_coap_cli_info_handler(UINT8 *buf, UINT32 buf_len);
INT32 ict_api_sta_coap_cli_send_handler(UINT8 *buf, UINT32 buf_len);
#endif /* FEATURE_COAP_SUPP */

#if defined (FEATURE_GMMP_SUPP)
extern T_NMS_GMMP_MIB *ict_api_sta_gmmp_get(void);
extern INT32 ict_api_sta_gmmp_set(UINT32 type, UINT8 *buf, UINT32 buf_len);
#endif /* FEATURE_GMMP_SUPP */
#if defined (FEATURE_SEP20_SUPP)
extern T_NMS_SEP20_MIB *ict_api_sta_sep20_get(void);
extern INT32 ict_api_sta_sep20_set(UINT32 type, UINT8 *buf, UINT32 buf_len);
#endif /* FEATURE_SEP20_SUPP */
#if defined (FEATURE_ALLJOYN_SUPP)
T_NMS_ALLJOYN_MIB *ict_api_sta_alljoyn_get(void);
INT32 ict_api_sta_alljoyn_set(UINT32 type, UINT8 *buf, UINT32 buf_len);
#endif /* FEATURE_ALLJOYN_SUPP */

#if defined(FEATURE_FTPC_SUPP)
extern INT32 ict_api_ftpc_set(UINT32 type, UINT8 *str);
extern INT32 ict_api_ftpc_get(UINT32 type, UINT8 *str);
#endif /* FEATURE_FTPC_SUPP */
#if defined(FEATURE_SNTP_SUPP)
extern INT32 ict_api_sntp_handler(void);
extern T_NMS_SNTP_MIB* ict_api_sntp_get(void);
#endif /* FEATURE_SNTP_SUPP */


/* Handlers */
/* DM Shell */
extern INT32 ict_api_dm_shell_send_cmd_handler(UINT8 *buf, UINT32 buf_len);

/* WiFi Connection */
extern INT32 ict_api_join_state(UINT8 *buf);
extern INT32 ict_api_scan_handler(ICT_ST_SCAN_REQ_T *params);
extern INT32 ict_api_join_handler(ICT_ST_JOIN_REQ_T *params);
extern INT32 ict_api_disconnect_handler(UINT8 *buf);

extern INT32 ict_api_apconn_handler(BOOL b_adhoc, UINT8 *buf, UINT32 buf_len);
extern void ict_api_apstop_handler();

/* WPS */
#if defined (CONFIG_WPS)
extern INT32 ict_api_wps_pbc_handler(UINT8 *buf, UINT32 buf_len);
extern INT32 ict_api_wps_pin_handler(ICT_ST_WPS_PIN_T *params);
extern INT32 ict_api_wps_cancel_handler(void);
#endif /* CONFIG_WPS */

/* P2P */
#if defined (CONFIG_P2P)
extern INT32 ict_api_p2p_find_handler(void);
extern INT32 ict_api_p2p_stop_find_handler(void);
extern INT32 ict_api_p2p_connect_handler(UINT8 *buf, UINT32 buf_len);
extern INT32 ict_api_p2p_cancel_handler(void);
extern INT32 ict_api_p2p_reject_handler(UINT8 *buf, UINT32 buf_len);
extern INT32 ict_api_p2p_listen_handler(UINT8 *buf, UINT32 buf_len);
extern INT32 ict_api_p2p_prov_desc_handler(UINT8 *buf, UINT32 buf_len);
extern INT32 ict_api_p2p_group_add_handler(UINT8 *buf, UINT32 buf_len);
extern INT32 ict_api_p2p_group_remove_handler(void);
#endif /* CONFIG_P2P */

/* TCPIP */
extern UINT8 ict_api_tcpip_net_if_ipaddr_isany(void);
extern INT32 ict_api_tcpip_set_ip_config_handler(ICT_ST_IP_CONFIG_T *params);
extern INT32 ict_api_tcpip_get_ip_config_handler(ICT_ST_IP_CONFIG_T *params);

extern INT32 ict_api_tcpip_socket_create_handler(ICT_ST_SOCKET_T *params);
extern INT32 ict_api_tcpip_socket_close_handler(ICT_ST_SOCKET_CLOSE_T *params);
extern INT32 ict_api_tcpip_tcp_disconnect_handler(ICT_ST_SOCKET_CLOSE_T *params, ICT_ST_SOCKET_ADDR_T *ra); /* s : Socket Descriptor */

/* TCPIP Data */
extern INT32 ict_api_send_data_handler(ICT_ST_HIF_DATA_T *sock_info, UINT32 size);
extern ICT_ST_HIF_DATA_T *ict_api_rcvd_data_handler(UINT8 *buf, UINT32 *data_len);
extern UINT8 *ict_api_rcvd_data_sw_type_handler(UINT8 *buf, UINT32 *data_len, UINT32 *sw_type, UINT32 *more_flag);
extern UINT32 ict_api_rcvd_data_sw_opt_handler(UINT8 *buf, UINT32 buf_len);

/* Raw Data */
extern UINT32 ict_api_send_raw_data(UINT8 *dest_addr, UINT8 *src_addr, UINT16 msg_type, UINT16 msg_len, UINT8 *msg);

#if defined (FEATURE_LPD_SUPP)
/* LPD */
extern INT32 ict_api_lpd_init_handler(UINT8 *queue_name);
extern void ict_api_lpd_close_handler(void);
#endif /* FEATURE_LPD_SUPP */

#if defined (FEATURE_GMMP_SUPP)
extern INT32 ict_api_gmmp_register_handler(UINT8 *buf, UINT32 buf_len);
extern INT32 ict_api_gmmp_unregister_handler(UINT8 *buf, UINT32 buf_len);
extern INT32 ict_api_gmmp_send_info_handler(UINT8 *buf, UINT32 buf_len);
extern INT32 ict_api_gmmp_send_ctrl_handler(UINT8 *buf, UINT32 buf_len);
extern INT32 ict_api_gmmp_send_data_handler(UINT8 *buf, UINT32 buf_len);
extern INT32 ict_api_gmmp_close_handler(void);
#endif /* FEATURE_GMMP_SUPP */

#if defined (FEATURE_MQTT_SUPP) || defined (FEATURE_MQTT_PAHO_EMB_SUPP)
/* MQTT */
extern INT32 ict_api_mqtt_pub_handler(UINT8 *buf, UINT32 buf_len);
extern INT32 ict_api_mqtt_sub_handler(UINT8 *buf, UINT32 buf_len);
#endif /* FEATURE_MQTT_SUPP || FEATURE_MQTT_PAHO_EMB_SUPP */

#if defined (FEATURE_MQTT_PAHO_EMB_SUPP)
extern INT32 ict_api_mqtt_connect_handler(UINT8 *buf, UINT32 buf_len);
extern INT32 ict_api_mqtt_disconnect_handler(UINT8 *buf, UINT32 buf_len);
extern INT32 ict_api_mqtt_unsubscribe_handler(UINT8 *buf, UINT32 buf_len);
#endif /* FEATURE_MQTT_PAHO_EMB_SUPP */

#if defined (FEATURE_ONEM2M_SUPP)
extern INT32 ict_api_onem2m_connect_handler(UINT8 *buf, UINT32 buf_len);
extern INT32 ict_api_onem2m_send_handler(UINT8 *buf, UINT32 buf_len);
extern INT32 ict_api_onem2m_disconnect_handler(UINT8 *buf, UINT32 buf_len);
extern INT32 ict_api_onem2m_bootstrap_request(void);
extern INT32 ict_api_onem2m_resource_update(UINT8 type, UINT32 buf_len, UINT8* p_buf);
#endif

#if defined (FEATURE_GIGAIOT_MQTT_SUPP)
extern INT32 ict_api_mqtt_gigaiot_connect_handler(UINT8 *buf, UINT32 buf_len);
extern INT32 ict_api_mqtt_gigaiot_send_handler(UINT8 *buf, UINT32 buf_len);
#endif /* FEATURE_GIGAIOT_MQTT_SUPP */

#if defined (FEATURE_SEP20_SUPP)
extern INT32 ict_api_sep20_start_handler(void);
extern INT32 ict_api_sep20_stop_handler(void);
extern INT32 ict_api_sep20_optout_handler(UINT16 type, UINT8 *uri);
extern INT32 ict_api_sep20_init_handler(void);
#endif /* FEATURE_SEP20_SUPP */

#if defined (FEATURE_ALLJOYN_SUPP)
extern INT32 ict_api_alljoyn_start_handler(UINT8 *buf, UINT32 buf_len);
#endif /* FEATURE_ALLJOYN_SUPP */

#if defined (FEATURE_DNS_SERVER_SUPP)
extern INT32 ict_api_set_dns_query_host_name(UINT8 *p_str);
#endif

#if defined (FEATURE_TCP_SSL_SUPP)
extern INT32 ict_api_tcp_ssl_start_handler(UINT32 socket, char* ip, UINT32 port);
extern INT32 ict_api_tcp_ssl_close_handler(UINT8 *buf, UINT32 buf_len);
extern INT32 ict_api_tcp_ssl_send_handler(UINT32 socket, UINT8 *buf, UINT32 buf_len);
extern INT32 ict_api_tcp_ssl_svr_start_handler(UINT32 port);
extern INT32 ict_api_tcp_ssl_svr_close_handler(UINT32 socket);
extern INT32 ict_api_tcp_ssl_svr_info_handler(UINT32 socket);
extern INT32 ict_api_tcp_ssl_svr_send_handler(UINT8 *buf, UINT32 buf_len);
extern INT32 ict_api_tcp_ssl_svr_send_to_cli(UINT32 socket, UINT8 *buf, UINT32 buf_len);
#endif /* FEATURE_TCP_SSL_SUPP */

#if defined(FEATURE_DHCPD_SUPP)
/* DHCPD */
extern INT32 ict_api_dhcpd_start_handler(void);
extern INT32 ict_api_dhcpd_stop_handler(void);
#endif /* FEATURE_DHCPD_SUPP */

#if defined (FEATURE_HTTP_SVR_SUPP)
/* HTTPD */
extern INT32 ict_api_httpd_start_handler(void);
extern INT32 ict_api_httpd_stop_handler(void);
#endif /* FEATURE_HTTP_SVR_SUPP */

/* DNS */
extern INT32 ict_api_dns_start_handler(void);
extern INT32 ict_api_dns_stop_handler(void);

#if defined (FEATURE_GCM_SUPP)
extern INT32 ict_api_gcm_start_handler(void);
extern INT32 ict_api_gcm_send_handler(UINT8 *buf, UINT32 buf_len);
extern INT32 ict_api_gcm_close_handler(void);
extern INT32 ict_api_gcm_id_handler(UINT8 *buf, UINT32 buf_len);
extern INT32 ict_api_gcm_key_handler(UINT8 *buf, UINT32 buf_len);
#endif /* FEATURE_GCM_SUPP */


/* DNS IP Request */
extern INT32 ict_api_dns_query_handler(UINT8 *data, UINT32 size);

#if defined (FEATURE_PING_SUPP)
/* PING */
extern INT32 ict_api_ping_req_handler(UINT8 *ipaddr, UINT16 ping_data_len);
extern INT32 ict_api_ping_test_handler(UINT8 *ipaddr, UINT16 ping_data_len, UINT32 repeat_cnt);
#endif /* FEATURE_PING_SUPP */

#if defined (FEATURE_HTTPC_V2_SUPP)
extern INT32 ict_api_httpc_init(UINT16 method, char *url, UINT8 *payload, UINT32 payload_len);
extern INT32 ict_api_httpc_set_custom_header(UINT8 *header, UINT32 header_len);
extern INT32 ict_api_httpc_download_request(UINT8 *uri, UINT8 *saveName, void (*cb_closed)(INT32 result, UINT8 *savedName));
#endif

/* HTTPC */
#if defined (FEATURE_HTTPC_SUPP)
extern INT32 ict_api_httpc_init(UINT8 *url, UINT32 url_len, BOOL is_post);
extern INT32 ict_api_httpc_post_octetstream_init(UINT8 *str, UINT32 str_len, UINT8 *payload, UINT32 payload_len);
extern INT32 ict_api_httpc_close(void);
extern INT32 ict_api_https_close(void);
extern INT32 ict_api_httpc_download_request(UINT8 *uri, UINT8 *saveName, void (*cb_closed)(INT32 result, UINT8 *savedName));
#if defined (FEATURE_UPNP_TINY_SUPP)
extern INT32 ict_api_upnp_get_external_ip(void);
extern INT32 ict_api_upnp_add_portmapping(UINT8 *ipaddr, UINT16 port_internal, UINT16 port_external, UINT16 protocol, UINT8 *description);
extern INT32 ict_api_upnp_del_portmapping (UINT16 port_external, UINT16 protocol);
#endif /* FEATURE_UPNP_TINY_SUPP */

#if defined (FEATURE_OTA_SUPP)
extern INT32 ict_api_ota_set_init(char *file_name);
extern INT32 ict_api_ota_ver_check(UINT8 *url, UINT32 url_len);
extern void ict_api_ota_omit_ver_check(UINT8 *firmware_file_name);
extern void ict_api_ota_process_vercheck(UINT8 *body, UINT16 body_len);
extern UINT8* ict_api_ota_process_ver_check_finished(void);
extern void ict_api_ota_process_update (UINT8 * body, UINT16 body_len);
extern INT32 ict_api_ota_process_update_finished (void);
extern INT32 ict_api_ota_request (UINT8 *url, UINT32 url_len);
#endif /* FEATURE_OTA_SUPP */

#if defined (FEATURE_MOTA_SUPP)
extern INT32 ict_api_mota_request (UINT32 file_size, char *url);
extern void ict_api_mota_update (UINT8 *buf, UINT32 buf_len);
extern void ict_api_mota_update_finished (void);

extern void ict_api_mota_get_size (UINT32 *total_bytes, UINT32 *block_count);
extern INT32 ict_api_mota_get_data (UINT32 block_number, UINT8 *data, UINT16 *crc);

#if defined(FEATURE_FATFS_GENERIC_API)
INT32 ict_api_fs_mcu_ota_fw_download_request(char *url, UINT32 file_size, char *fs_file_name);
void ict_api_fs_mcu_ota_fw_download_process(UINT8 *buf, UINT32 buf_len);
void ict_api_fs_mcu_ota_fw_download_finish(void);
#endif /* FEATURE_FATFS_GENERIC_API */
#endif /* FEATURE_MOTA_SUPP */

#if defined (FEATURE_DDNS_SUPP)
extern INT32 ict_api_ddns_get_external_ip (void);
extern INT32 ict_api_ddns_update_info (UINT8 ddns_server, UINT8 *host_name, UINT8 *user_id, UINT8 *user_pw, UINT32 timer);
#endif /* FEATURE_DDNS_SUPP */

#endif /* FEATURE_HTTPC_SUPP */

#if defined(FEATURE_WDS_FUNCTIONALITY)
extern INT32 ict_api_wds_info(UINT8 *p_wds_enable, UINT8 *p_wds0_addr, UINT8 *p_wds1_addr);
extern INT32 ict_api_wds_info_update(UINT8 wds_enable);
#endif /* FEATURE_WDS_FUNCTIONALITY */

/* AES */
extern INT32 ict_api_aes_init(UINT8 *key);  // length of key = 16 bytes...
extern INT32 ict_api_aes_deinit(void);
extern INT32 ict_api_aes_encryption(char *data, const UINT16 len, char *iv);  // the unit of 16 bytes...
extern INT32 ict_api_aes_decryption(char *data, const UINT16 len, char *iv);  // the unit of 16 bytes...

#if defined (FEATURE_SW_I2C_MASTER)
/* I2C */
extern void ict_api_i2c_init (UINT32 scl, UINT32 sda, UINT32 delay);
extern void ict_api_i2c_start (void);
extern void ict_api_i2c_stop (void);
extern void ict_api_i2c_restart (void);
extern void ict_api_i2c_send_byte (UINT8 data);
extern UINT8 ict_api_i2c_get_byte (void);
extern void ict_api_i2c_get_bytes (UINT8 no, UINT8 *data);
#endif /* FEATURE_SW_I2C_MASTER */

#if defined (FEATURE_SW_SPI_MASTER)
void ict_api_spi_init (UINT32 ss, UINT32 sck, UINT32 mosi, UINT32 miso, UINT32 deley, UINT32 clk_pol, BOOL clk_pha);
UINT8 ict_api_spi_send_byte (UINT8 data);
void ict_api_spi_send_bytes (UINT8 no, UINT8 *data_in, UINT8 *data_out);
UINT8 ict_api_spi_get_byte (void);
void ict_api_spi_get_bytes (UINT8 no, UINT8 *data_out);
#endif /* FEATURE_SW_SPI_MASTER */

#if defined (FEATURE_SW_UART)
void ict_sw_uart_init_uart( UINT32 tx_port, UINT32 rx_port, UINT32 baud_rate );
char ict_sw_uart_getchar( void );
void ict_sw_uart_putchar( char ch );
char ict_sw_uart_kbhit( void );
#endif /* FEATURE_SW_UART */
extern INT32 ict_api_smtconn(UINT8 aes_en);
extern INT32 ict_api_smtaes_set(UINT8* aes_key);
extern INT32 ict_api_smtaes_get(UINT8* aes_key);
extern INT32 ict_api_smtstop(void);
extern UINT8 ict_api_button_status(void);

extern INT32 ict_api_config_smode(UINT32 c, UINT8 *ssid, UINT8 *passphrase);

#if defined (FEATURE_DEEP_SLEEP_CMD)
extern INT32 ict_api_deepsleep_handler(UINT8 *buf, UINT32 buf_len);
#endif /* FEATURE_DEEP_SLEEP_CMD */

/* WIFI operation mode */
/* 0: INIT mode */
/* 1: Infrastructure */
/* 2: SoftAP */
/* 3: AdHoc */
/* 4: P2P */
UINT8 ict_api_get_wifi_operation_mode();

INT32 ict_api_set_channel(UINT32 channel);
UINT8 ict_api_set_sniffer_mode(UINT32 enable, void (*rx_callback));
#if defined (SDK_V1_DC)
int ict_api_find_bssid_channel(UINT8 *bssid, UINT8 *ssid, INT32 *ssid_len);
#endif

#if defined(AB6_SSE)
extern INT32 ict_api_sse_mutex_lock();
extern INT32 ict_api_sse_mutex_unlock();
extern INT32 ict_api_sse_init(const char *algorithm, const char* mode);
extern INT32 ict_api_sse_set_encryption_key(UINT8 *key, UINT16 in_len);
extern INT32 ict_api_sse_set_decryption_key(UINT8 *key, UINT16 in_len);

extern INT32 ict_api_sse_create_iv(UINT8 *out_iv);
extern INT32 ict_api_sse_encryption(UINT8 *in_data, UINT8 *out_buffer, UINT16 in_len, UINT8 *iv);
extern INT32 ict_api_sse_decryption(UINT8 *in_data, UINT8 *out_buffer, UINT16 in_len, UINT8 *iv);

extern INT32 ict_api_sse_get_hash(const char *algorithm, UINT8 *in_data, UINT8 *hash, UINT16 in_len);
#endif

#if defined(AB5_PWM)
extern void ict_api_pwm_init(void);
extern INT32 ict_api_pwm_set_timer_count(UINT32 pwm_ch, UINT32 interval_unit, UINT32 low_duration, UINT32 high_duration);
extern INT32 ict_api_pwm_set_pad(UINT32 pwm_ch, UINT32 pwm_en);
extern INT32 ict_api_pwm_set_interrupt(UINT32 pwm_ch, UINT32 pwm_en, void (*pwm_isr_cb)(void));
extern INT32 ict_api_pwm_set_repeat(UINT32 pwm_ch, UINT32 pwm_en);
extern INT32 ict_api_pwm_enable(UINT32 pwm_ch);
extern INT32 ict_api_pwm_disable(UINT32 pwm_ch);
#endif

extern void ict_api_lwip_stat();

extern UINT32 ict_api_rand();

extern void ict_api_secplus_update_key();

extern INT32 ict_api_nv_cfo_write(UINT16 set_cfo_val);
extern UINT16 ict_api_nv_cfo_read(void);
extern INT32 ict_api_nv_cfo_erase(void);
extern UINT16 ict_api_get_cfo_value(void);

extern INT32 ict_api_send_packet(UINT32 ch, UINT8 *packet, UINT32 len);

#if defined(FEATURE_OPERATION_MODE)
extern void ict_api_set_test_mode(UINT8 b_on);
#endif

#if defined(AB6_GPADC_REGISTER)
extern INT16 ict_api_gadc_read(UINT8 ch);
#endif /* AB6_GPADC_REGISTER */

#endif /* HOST_STDA_CM_INTERWORKING || FEATURE_PICOC_SUPP */
#endif /* __ICT_API_LIB_H__ */

