/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: ict_cm_event_handler.h
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/

#if !defined(__ICT_CM_EVENT_HANDLER_H__)
#define __ICT_CM_EVENT_HANDLER_H__

#if defined(HOST_STDA_CM_INTERWORKING)

typedef void (*wlan_operation_event_handler_t)(T_MAC_EVENT *p_mac_event);
typedef void (*wlan_scan_event_handler_t)(T_MAC_EVENT *p_mac_event);

/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/
void ict_cm_wlan_event_callback_register(wlan_operation_event_handler_t callback);

/*****************************************************************************
** Function name: ict_cm_initialization
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
extern void ict_cm_initialization(UINT32 boot_up);

/*****************************************************************************
** Function name: ict_cm_event_handler
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
extern UINT32 ict_cm_event_handler(T_MAC_EVENT * p_mac_event);

/*****************************************************************************
** Function name: ict_cm_timer_event_handler
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
extern void ict_cm_timer_event_handler (void *pTmrCntx, UINT32 timerId);

/*****************************************************************************
** Function name: ict_cm_ext_timer_event_handler
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
extern void ict_cm_ext_timer_event_handler (void *pTmrCntx, UINT32 timerId);

#endif /* HOST_STDA_CM_INTERWORKING */
#endif /* __ICT_CM_EVENT_HANDLER_H__ */

