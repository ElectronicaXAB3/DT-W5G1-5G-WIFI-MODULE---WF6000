/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: ict_cm_main.h
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/

#if !defined(__ICT_CM_MAIN_H__)
#define __ICT_CM_MAIN_H__

#if defined(HOST_STDA_CM_INTERWORKING)

/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/

/*
******************************************************************************
*	DEFINITION
******************************************************************************
*/
#if defined(CUSTOM_BONA_STDA_CM_V2)
#define SIZE_OF_CM_TASK_STACK       (768 * 4)/4
#else
#define SIZE_OF_CM_TASK_STACK       (512 * 4)/4
#endif

#define EVENT_MASK_CM_UART0_RX      (1 << 3)
#define EVENT_MASK_CM_UART1_RX      (1 << 4)
#define EVENT_MASK_CM_UART2_RX      (1 << 5)
#define EVENT_MASK_CM_GPIO_INT      (1 << 6)
#define EVENT_MASK_CM_RF_TEST_MODE  (1 << 7)
#define EVENT_MASK_CM_WDT_INT       (1 << 8)

/*
******************************************************************************
*	MACRO
******************************************************************************
*/

/*
******************************************************************************
*	DATA TYPE
******************************************************************************
*/

/*
******************************************************************************
*	GLOBAL VARIABLE
******************************************************************************
*/
extern OS_STK           cm_task_stack[SIZE_OF_CM_TASK_STACK];

extern OS_FLAG_GRP *    cm_event_group;
extern T_LIST           cm_primitive_queue;

/*
******************************************************************************
*   FUNCTIONS
******************************************************************************
*/

#endif /* HOST_STDA_CM_INTERWORKING */
#endif /* __ICT_CM_MAIN_H__ */

