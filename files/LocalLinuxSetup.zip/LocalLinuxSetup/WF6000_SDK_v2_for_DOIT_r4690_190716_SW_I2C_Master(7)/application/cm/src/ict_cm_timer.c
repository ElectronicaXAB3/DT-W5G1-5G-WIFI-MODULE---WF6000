/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: ict_cm_timer.c
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/

#if defined(HOST_STDA_CM_INTERWORKING)

/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/
#include "ict_cm_globals.h"

/*
******************************************************************************
* 	LOCAL CONSTANTS
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL DATA TYPES
******************************************************************************
*/

/*
******************************************************************************
*	GLOBAL VARIABLES
******************************************************************************
*/

DWALIGN SW_TIMER_CNTX   cm_timer XDWALIGN;
DWALIGN SW_TIMER        cm_timer_list[CM_TIMER_MAX] XDWALIGN;

DWALIGN SW_TIMER_CNTX   cm_ext_timer XDWALIGN;
DWALIGN SW_TIMER        cm_ext_timer_list[CM_EXT_TIMER_MAX] XDWALIGN;

static UINT32 app_timer_count = 0;

/*
******************************************************************************
*	LOCAL VARIABLES
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/

/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/

/*****************************************************************************
** Function name: ict_cm_timer_initialization
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
UINT32 ict_cm_timer_initialization(void)
{
    return (ICT_TRUE);
}

/*****************************************************************************
** Function name: ict_cm_timer_get_status
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
UINT32 ict_cm_timer_get_status(UINT32 timerId)
{
    return (ict_api_sw_timer_get_status(&cm_timer, timerId));
}

/*****************************************************************************
** Function name: ict_cm_timer_get_expire_cnt
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
UINT32 ict_cm_timer_get_expire_cnt(UINT32 timerId)
{
    return (ict_api_sw_timer_get_expire_cnt(&cm_timer, timerId));
}

/*****************************************************************************
** Function name: ict_cm_ext_timer_initialization
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
UINT32 ict_cm_ext_timer_initialization(void)
{
    return (ICT_TRUE);
}

/*****************************************************************************
** Function name: ict_cm_ext_timer_get_status
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
UINT32 ict_cm_ext_timer_get_status(UINT32 enabled_timer)
{
    return (ict_api_ext_sw_timer_get_status(&cm_ext_timer, enabled_timer));
}

/*****************************************************************************
** Function name: ict_cm_ext_timer_get_expire_cnt
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
UINT32 ict_cm_ext_timer_get_expire_cnt(UINT32 enabled_timer)
{
    return (ict_api_ext_sw_timer_get_expire_cnt(&cm_ext_timer, enabled_timer));
}

/*****************************************************************************
** Function name: ict_cm_app_timer_create
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
UINT8 ict_cm_app_timer_create(APP_TIMER_HANDLER *timer_t, const char *name, UINT32 reload, UINT32 interval, void* callback)
{
    if (timer_t == ICT_NULL) return ICT_ERR;
    if (app_timer_count >= CM_EXT_TIMER_MAX) return ICT_ERR;
    
    ICT_MEMSET(timer_t, 0x00, sizeof(APP_TIMER_HANDLER));
    
    timer_t->timerID = app_timer_count++;
    ICT_STRCPY(timer_t->name, name);
    timer_t->bPeriod = reload;
    timer_t->interval = interval;
    timer_t->callback = callback;

    return ICT_OK;
}

/*****************************************************************************
** Function name: ict_cm_app_timer_delete
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
UINT8 ict_cm_app_timer_delete(APP_TIMER_HANDLER *timer_t)
{
    if (timer_t || !(app_timer_count)) return ICT_ERR;

    app_timer_count--;

    return ICT_OK;
}

/*****************************************************************************
** Function name: ict_cm_app_timer_start
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
UINT8 ict_cm_app_timer_start(APP_TIMER_HANDLER *timer_t)
{
    if (timer_t == ICT_NULL) return ICT_ERR;

    timer_t->bActive = ICT_TRUE;
    ict_api_ext_sw_timer_start(&cm_ext_timer, timer_t->timerID, timer_t->bPeriod, timer_t->interval, timer_t->callback);

    return ICT_OK;
}

/*****************************************************************************
** Function name: ict_cm_app_timer_stop
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
UINT8 ict_cm_app_timer_stop(APP_TIMER_HANDLER *timer_t)
{
    if (timer_t == ICT_NULL) return ICT_ERR;

    timer_t->bActive = ICT_FALSE;
    ict_api_ext_sw_timer_stop(&cm_ext_timer, timer_t->timerID);

    return ICT_OK;
}





#endif /* HOST_STDA_CM_INTERWORKING */

