/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: user_main.c
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/


/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/
#include "ict_cm_globals.h"

/*
******************************************************************************
* 	LOCAL CONSTANTS
******************************************************************************
*/

static const char *enc_mode[] = {"ecb", "cbc", "cfb8", "cfb16", "cfb32", "cfb64", "cfb128", "ofb", "ctr", "ccm", "cmac" , "gcm" };

/*
******************************************************************************
*	LOCAL DATA TYPES
******************************************************************************
*/

/*
******************************************************************************
*	GLOBAL VARIABLES
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL VARIABLES
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/


/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/

INT32 sse_md5_signature (const UINT8 *input, UINT16 len, UINT8 *output)
{
	if( ict_api_sse_get_hash("md5", (UINT8 *)input, (UINT8 *)output, len) != ICT_OK ) 
        return ICT_ERR;
    
	return ICT_NO_ERR;
}

INT32 sse_sha1_signature (const UINT8 *input, UINT16 len, UINT8 *output)
{
	if( ict_api_sse_get_hash("sha1", (UINT8 *)input, (UINT8 *)output, len) != ICT_OK ) 
        return ICT_ERR;
    
	return ICT_NO_ERR;    
}

INT32 sse_sha2_signature (const UINT8 *input, UINT16 len, UINT8 *output, const UINT16 out_size_bits)
{
	const char* algorithm;

	switch(out_size_bits)
	{
    	case 224: 
            algorithm="sha224"; 
            break;
            
    	case 256: 
            algorithm="sha256"; 
            break;
            
    	default: 
            return ICT_ERR;
	}

	if( ict_api_sse_get_hash(algorithm, (UINT8 *)input, (UINT8 *)output, len) != ICT_OK ) 
        return ICT_ERR;
    
	return ICT_NO_ERR;    
}

INT32 sse_sha3_signature (const UINT8 *input, UINT16 len, UINT8 *output, const UINT16 out_size_bits)
{
	const char* algorithm;

	switch(out_size_bits)
	{
    	case 224: 
            algorithm="sha3224"; 
            break;
            
    	case 256: 
            algorithm="sha3256"; 
            break;
            
    	case 384: 
            algorithm="sha3384"; 
            break;
            
    	case 512: 
            algorithm="sha3512"; 
            break;
            
    	default: 
            return ICT_ERR;
	}

	if( ict_api_sse_get_hash(algorithm, (UINT8 *)input, (UINT8 *)output, len) != ICT_OK ) 
        return ICT_ERR;
    
	return ICT_NO_ERR;    
}

INT32  sse_aes128_encrypt (UINT8 *data, UINT16 *len, const UINT8 *key, const UINT8 encrypt_type)
{
	UINT8 *out_data;

	UINT16 length = (*len/16 + 1) * 16;

	if( ict_api_sse_init("aes128", enc_mode[encrypt_type]) != ICT_OK )  
		return ICT_ERR;

	if( ict_api_sse_set_encryption_key((UINT8 *)key, 16) != ICT_OK )
		return ICT_ERR;

	out_data = (UINT8 *)ict_api_malloc((UINT32)length);
	if(out_data == ICT_NULL)
		return ICT_ERR;

	if( ict_api_sse_encryption(data, out_data, *len, ICT_NULL) != ICT_OK ) 
	{
		ict_api_mfree((void *)out_data);
		return ICT_ERR;        
	}

	*len = length;
	ict_api_memcpy((void *)data, out_data, length);
	ict_api_mfree((void *)out_data);

	return ICT_NO_ERR;    
}

INT32  sse_aes128_decrypt (UINT8 *data, UINT16 *len, const UINT8 *key, const UINT8 decrypt_type)
{
	UINT8 *out_data;
	UINT16 length = *len;

	if( ict_api_sse_init("aes128", enc_mode[decrypt_type]) != ICT_OK ) 
		return ICT_ERR;

	if( ict_api_sse_set_encryption_key((UINT8 *)key, 16) != ICT_OK )
		return ICT_ERR;

	out_data = (UINT8 *)ict_api_malloc((UINT32)length);
	if(out_data == ICT_NULL)
		return ICT_ERR;

	if( ict_api_sse_encryption(data, out_data, length, ICT_NULL) != ICT_OK ) 
	{
		ict_api_mfree((void *)out_data);
		return ICT_ERR;
	}

	ict_api_memcpy((void *)data, out_data, length);
	ict_api_mfree((void *)out_data);
	return ICT_NO_ERR;        
}

INT32  sse_aes256_encrypt (UINT8 *data, UINT16 *len, const UINT8 *key, const UINT8 encrypt_type)
{
	UINT8 *out_data;

	UINT16 length = (*len/16 + 1) * 16;

	if( ict_api_sse_init("aes256", enc_mode[encrypt_type]) != ICT_OK )  
		return ICT_ERR;

	if( ict_api_sse_set_encryption_key((UINT8 *)key, 32) != ICT_OK )
		return ICT_ERR;

	out_data = (UINT8 *)ict_api_malloc((UINT32)length);
	if(out_data == ICT_NULL)
		return ICT_ERR;

	if( ict_api_sse_encryption(data, out_data, *len, ICT_NULL) != ICT_OK ) 
	{
		ict_api_mfree((void *)out_data);
		return ICT_ERR;        
	}

	*len = length;
	ict_api_memcpy((void *)data, out_data, length);
	ict_api_mfree((void *)out_data);

	return ICT_NO_ERR;    

}

INT32  sse_aes256_decrypt (UINT8 *data, UINT16 *len, const UINT8 *key, const UINT8 decrypt_type)
{
	UINT8 *out_data;
	UINT16 length = *len;

	if( ict_api_sse_init("aes256", enc_mode[decrypt_type]) != ICT_OK ) 
		return ICT_ERR;

	if( ict_api_sse_set_encryption_key((UINT8 *)key, 32) != ICT_OK )
		return ICT_ERR;

	out_data = (UINT8 *)ict_api_malloc((UINT32)length);
	if(out_data == ICT_NULL)
		return ICT_ERR;

	if( ict_api_sse_encryption(data, out_data, length, ICT_NULL) != ICT_OK ) 
	{
		ict_api_mfree((void *)out_data);
		return ICT_ERR;
	}

	ict_api_memcpy((void *)data, out_data, length);
	ict_api_mfree((void *)out_data);
	return ICT_NO_ERR;        

}

void user_start(UINT32 flag)
{
    UINT8 *p_in, *p_out;
    UINT32 in_len;

    ict_api_tn_task_sleep(10);

    /* The default baudrate of UART0 is 8000000. */
    /* The baudrate of UART0 can be changed to 115200 or 230400, ..., 8000000 */
//    ict_api_uart_change_baudrate (UART0, 8000000, fMACWLEN(UART_WORD_LEN_8BITS));
    
    printf("\n");
    printf("=== Current baudrate of UART%d : %d ===\n", UART0, ict_api_uart_get_baudrate(UART0));  
    printf("**********************************************\n");
    printf("*              USER started.                 *\n");
    printf("**********************************************\n");
    printf("-- security engine\n\n");

    p_in = ict_api_malloc(32);
    p_out = ict_api_malloc(32);
    
    ICT_MEMSET(p_in, 0x00, 32);
    ICT_MEMSET(p_out, 0x00, 32);

    /* sha256 test */
    if (1)
    {
        in_len = ict_api_sprintf(p_in, "%s", "test1234567890");

        ict_api_sse_mutex_lock();
        sse_sha2_signature(p_in, in_len, p_out, 256);
        ict_api_sse_mutex_unlock();

        ict_app_uart_printf_hex(p_out, 32);
    }

    ict_api_mfree(p_in);
    ict_api_mfree(p_out);
    
    return;
}


