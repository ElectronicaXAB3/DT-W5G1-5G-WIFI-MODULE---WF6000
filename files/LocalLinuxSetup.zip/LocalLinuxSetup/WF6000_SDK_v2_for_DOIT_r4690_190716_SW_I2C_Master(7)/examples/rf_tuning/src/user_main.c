/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: user_main.c
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/


/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/
#include "ict_app_globals.h"

/*
******************************************************************************
* 	LOCAL CONSTANTS
******************************************************************************
*/

#define RF_TUNING_TASK_STACK_SIZE    1024
#define RF_TUNING_TASK_PRI           1

#define EVENT_MASK_USER_UART_RX     0x00000001
#define CMD_BUFF_SIZE               128

/*
******************************************************************************
*	LOCAL DATA TYPES
******************************************************************************
*/

typedef struct
{
    UINT32  len;
    UINT8   data[CMD_BUFF_SIZE];
} CMD_RECV_BUFF_T;

/*
******************************************************************************
*	GLOBAL VARIABLES
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL VARIABLES
******************************************************************************
*/
TN_TCB *p_rf_tuning_task = ICT_NULL;
DWALIGN OS_STK rf_tuning_task_stack[RF_TUNING_TASK_STACK_SIZE] XDWALIGN;

static DWALIGN TN_EVENT    uart_event_group XDWALIGN;

/*
******************************************************************************
*	LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/

static UINT32 assoc_flag = ICT_FALSE;
static UINT32 rf_tuning_start = ICT_FALSE;

static ICT_ST_IP_CONFIG_T       rf_tuning_local_ip_params;
static ICT_ST_JOIN_REQ_T        rf_tuning_req_join;

static CMD_RECV_BUFF_T          rf_tuning_cmd_buff;

/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/

void uart_send_data(UINT8 *buffer, UINT32 len)
{
    ict_api_uart_direct_send_w_size(UART2, buffer, len);
}

INT32 rf_tuning_connect_to_ap(ICT_ST_IP_CONFIG_T *p_params, ICT_ST_JOIN_REQ_T *p_join_req)
{
    INT32 result;

    ict_api_tcpip_set_ip_config_handler(p_params);

    result = ict_api_join_handler(p_join_req);    

    printf("[%s] result(%d)\n", __func__, result);    

    printf("$$$ dhcp_mode          = %d\n", p_params->dhcp_mode);
    printf("# ssid                 = %s\n", p_join_req->ssid);
    printf("# bssid                = %s\n", p_join_req->bssid);
    printf("# ch                   = %d\n", p_join_req->ch);
    printf("# auth_type            = %d\n", p_join_req->auth_type);
    printf("# auth_enc_type        = %d\n", p_join_req->auth_enc_type);
    printf("# pairwise_cipher      = %d\n", p_join_req->pairwise_cipher);
    printf("# group_cipher         = %d\n", p_join_req->group_cipher);
    printf("# key_idx              = %d\n", p_join_req->key_idx);
    printf("# key                  = %s\n", p_join_req->key);
    printf("# p_vendor_specific_ie = %s\n", p_join_req->p_vendor_specific_ie);

    return result;    
}

void rf_tuning_cmd_example(void)
{
    INT8 sp_buf[128];
    UINT32 str_len = 0;
    
    str_len = ict_api_sprintf(sp_buf, "\r\n $$$ cfo command examples\r\n");
    uart_send_data(sp_buf, str_len);
    printf(" $$$ cfo command examples\n"); 

    str_len = ict_api_sprintf(sp_buf, " cfo w 155   : Change CFO value and save\r\n");
    uart_send_data(sp_buf, str_len);
    printf(" cfo w 155 \n"); 

    str_len = ict_api_sprintf(sp_buf, " cfo r       : Saved CFO value\r\n");
    uart_send_data(sp_buf, str_len);
    printf(" cfo r \n");

    str_len = ict_api_sprintf(sp_buf, " cfo g       : CFO value currently applied\r\n");
    uart_send_data(sp_buf, str_len);
    printf(" cfo g \n");

    str_len = ict_api_sprintf(sp_buf, " cfo e       : Erase saved cfo value\r\n");
    uart_send_data(sp_buf, str_len);
    printf(" cfo e \n");
}

void rf_tuning_event_handler(T_MAC_EVENT *p_mac_event)
{
    switch(p_mac_event->code)
    {
        case ICT_HIF_CMD_ST_AP_START_IND:
            printf("I: AP START!!\n");
            break;

        case ICT_HIF_CMD_ST_AP_STOP_IND:
            printf("I: AP STOP!!\n");
            break;

        case ICT_HIF_CMD_ST_JOIN_IND:
            if(ict_api_join_state(p_mac_event->buf) == ICT_TRUE)
            {
                printf("I: ASSOCIATED!\n");
                assoc_flag = ICT_TRUE;
            }
            else
            {
                printf("W: DISCONNECT!\n");
            }          
            break;

        case ICT_HIF_CMD_ST_DISCONNECTED_IND:
            printf("E: DISASSOCIATED!!\n");
            assoc_flag = ICT_FALSE;
            break;
        
        case ICT_HIF_CMD_ST_NETWORK_INFO_IND:
            printf("I: NETWORK_INFO_IND!!\n");
            {
                ICT_ST_NETWORK_INFO_IND_T *network_ind;
                network_ind = (ICT_ST_NETWORK_INFO_IND_T *)p_mac_event->buf;

                printf("IP       "IPSTR"\n", IP2STR(network_ind->ipaddr));
                printf("SUBNET   "IPSTR"\n", IP2STR(network_ind->subnet));
                printf("GATEWAY  "IPSTR"\n", IP2STR(network_ind->gateway));
                printf("DNS      "IPSTR"\n", IP2STR(network_ind->dns));
            }
            rf_tuning_start = ICT_TRUE;
            break;
        case ICT_HIF_CMD_ST_PING_REPLY_IND:
            {
                ICT_ST_PING_DATA_INFO_T *pin_reply_info;                
                pin_reply_info = (ICT_ST_PING_DATA_INFO_T *)p_mac_event->buf;
                
                printf("PING_REPLY: "IPSTR" data_len = %d(bytes) : time = %d(ms)\n", IP2STR(pin_reply_info->ipaddr), pin_reply_info->ping_data_len, pin_reply_info->ping_time);
            }
            break;

        case ICT_HIF_CMD_ST_PING_RESULT_IND:
            {
                ICT_ST_PING_DATA_INFO_T *pin_reply_info;                
                pin_reply_info = (ICT_ST_PING_DATA_INFO_T *)p_mac_event->buf;
                
                printf("PING_RESULT: "IPSTR" repeat_num = %d : result = %d\n", IP2STR(pin_reply_info->ipaddr), pin_reply_info->repeat_num, pin_reply_info->ping_result);
            }
            break;
    }
}

void rf_tuning_cfo_ctrl(UINT8 *p_str, UINT32 len)
{
    INT8 argv[32];
    INT8 sp_buf[128];
    INT32 rst = ICT_OK;
    UINT16 cfo_value = 0;
    UINT32 str_len = 0;
    
    if(len)
    {
        uart_send_data(p_str, len);
        
        p_str = ict_api_dm_shell_get_token (p_str, argv);
        
        if (!ICT_STRCMP(argv, "cfo"))
        {
            p_str = ict_api_dm_shell_get_token (p_str, argv);
            
            if (!ICT_STRCMP(argv, "w")) /* Change CFO value and save */
            {
                p_str = ict_api_dm_shell_get_token (p_str, argv);
                cfo_value = atoi(argv);

                ict_api_nv_cfo_write(cfo_value);

                str_len = ict_api_sprintf(sp_buf, "\r\n => nv write cfo value = %d\r\n", cfo_value);
                uart_send_data(sp_buf, str_len);
                printf(" => nv write cfo value = %d\n", cfo_value);                
            }
            else if (!ICT_STRCMP(argv, "r")) /* Saved CFO value. */
            {
                cfo_value = ict_api_nv_cfo_read();

                str_len = ict_api_sprintf(sp_buf, "\r\n => nv read cfo value = %d\r\n", cfo_value);
                uart_send_data(sp_buf, str_len);
                printf(" => nv read cfo value = %d\n", cfo_value);
            }
            else if (!ICT_STRCMP(argv, "g")) /* CFO value currently applied */
            {
                cfo_value = ict_api_get_cfo_value();
                
                str_len = ict_api_sprintf(sp_buf, "\r\n => Currently applied cfo value = %d\r\n", cfo_value);
                uart_send_data(sp_buf, str_len);
                printf(" => Currently applied cfo value = %d\n", cfo_value);
            }
            else if (!ICT_STRCMP(argv, "e")) /* CFO value currently applied */
            {
                ict_api_nv_cfo_erase();

                cfo_value = ict_api_nv_cfo_read();
                
                str_len = ict_api_sprintf(sp_buf, "\r\n => nv erased after cfo value = %d\r\n", cfo_value);
                uart_send_data(sp_buf, str_len);
                printf(" => cfo value after nv erase = %d\n", cfo_value);
            }
            
            else if (!ICT_STRCMP(argv, "h")) /* help */
            {
                str_len = ict_api_sprintf(sp_buf, "\r\n => cfo command help\r\n");
                uart_send_data(sp_buf, str_len);
                
                printf(" => cfo command help\n");
                rf_tuning_cmd_example();
            }
            else
            {
                rst = ICT_ERR;
            }
        }
        else
        {
            rst = ICT_ERR;
        }
    }

    if(rst == ICT_ERR)
    {
        rf_tuning_cmd_example();
    }
}

void rf_tuning_uart_recv_proc(UINT8 *buff, UINT32 len)
{
    UINT8   prmpt[] = "\r\ncmd > ";
    UINT8   ch;
    UINT32  data_cnt = 0;
    
    CMD_RECV_BUFF_T *p_cmd;

    p_cmd = &rf_tuning_cmd_buff;
    
    while(len > data_cnt)
    {
        ch = buff[data_cnt++];

        if((ch == 0x0D) || (ch == 0x0A))
        {
            if(p_cmd->len)
            {
                p_cmd->data[p_cmd->len++] = 0;
                printf("%s\n", p_cmd->data);
                
                rf_tuning_cfo_ctrl(p_cmd->data, p_cmd->len);

                p_cmd->len = 0;
            }            

            uart_send_data(prmpt, sizeof(prmpt));
        }
        else
        {
            p_cmd->data[p_cmd->len++] = ch;
        }
    }
}

static void rf_uart_rx_int_cb(void)
{
    ict_api_tn_task_event_set(&uart_event_group, EVENT_MASK_USER_UART_RX);
}

static void rf_tuning_operation_task(void *arg)
{
    arg = arg;
    static UINT32 num = 0;
    static UINT32 repeat_cnt = 4;
    UINT8  start_prmpt[] = "\r\n = start = \r\ncmd > ";

    char ch;
    OS_FLAGS masked_event;
    OS_FLAGS waiting_event = EVENT_MASK_USER_UART_RX;
    UINT16 set_cfo_value = 0, get_cfo_value = 0;
    UINT32 len;
    
    printf("\n");
    printf("==============================================\n");
    printf("=           rf_tuning task started.          =\n");
    printf("==============================================\n");

    ict_api_uart_init(UART2);
    ict_api_uart_open(UART2);    
    ict_api_uart_reg_rx_callback (UART2, rf_uart_rx_int_cb);
    ict_api_uart_change_baudrate (UART2, 115200, fMACWLEN(UART_WORD_LEN_8BITS));

    ict_api_tn_task_event_create(&uart_event_group, 0x00);

    get_cfo_value = ict_api_get_cfo_value();
    printf("* The range of CFO is from 1 to 244. * \n");
    printf("* Current CFO Value = %d             * \n", get_cfo_value);

    rf_tuning_cmd_example();
    
    uart_send_data(start_prmpt, sizeof(start_prmpt));
    
    while(1)
    {
        masked_event = ict_api_tn_task_event_wait(&uart_event_group, waiting_event, 0);
        if (masked_event & EVENT_MASK_USER_UART_RX)
        {
            UINT8 buff[128];
            INT32 size = 0;
            
            size = ict_api_uart_gets(UART2, buff, sizeof(buff));
            if(size > 0)
            {
                rf_tuning_uart_recv_proc(buff, (UINT32)size);
            }
        }
        
        if((assoc_flag == ICT_TRUE) && (rf_tuning_start == ICT_TRUE))
        {
            if(num == ((repeat_cnt * 10) + 10))
            {
                num = 0;
            }
        }
        
        ict_api_tn_task_sleep(10); // 100msec sleep
        
        num++;
    }
    
}

void user_config(void)
{
    UINT8 ssid[32] = "iptime"; /* SSID */
    UINT8 password[32] = ""; /* or "12345678" */
    UINT16 dhcp_en = ICT_TRUE; /* DHCP */

    UINT32 cnt;

    ICT_MEMSET(&rf_tuning_local_ip_params, 0x00, sizeof(ICT_ST_IP_CONFIG_T));
    
    rf_tuning_local_ip_params.dhcp_mode = dhcp_en;    
    if(dhcp_en == ICT_FALSE)
    {   
        /* Example Static IP */        
        IP4_ADDR_(rf_tuning_local_ip_params.ipaddr, 10, 0, 0, 10);
        IP4_ADDR_(rf_tuning_local_ip_params.subnet, 255, 255, 255, 0);
        IP4_ADDR_(rf_tuning_local_ip_params.gateway, 10, 0, 0, 1);
        IP4_ADDR_(rf_tuning_local_ip_params.dns, 164, 124, 101, 2);            
    }

    ICT_MEMSET(&rf_tuning_req_join, 0x00, sizeof(ICT_ST_JOIN_REQ_T));
    rf_tuning_req_join.ssid_len = ICT_STRLEN(ssid);
    ICT_STRCPY(rf_tuning_req_join.ssid, ssid);
    rf_tuning_req_join.key_len = ICT_STRLEN(password);
    ICT_STRCPY(rf_tuning_req_join.key, password);
}

void user_start(void)
{
    ict_api_tn_task_sleep(10);

    /* The default baudrate of UART0 is 8000000. */
    /* The baudrate of UART0 can be changed to 115200 or 230400, ..., 8000000 */
//    ict_api_uart_change_baudrate (UART0, 8000000, fMACWLEN(UART_WORD_LEN_8BITS));
    
    printf("\n");
    printf("=== Current baudrate of UART%d : %d ===\n", UART0, ict_api_uart_get_baudrate(UART0));  
    printf("**********************************************\n");
    printf("*              USER started.                 *\n");
    printf("**********************************************\n");
    printf("-- rf_tuning\n\n");

    user_config();
    ict_cm_wlan_event_callback_register((void *)rf_tuning_event_handler);    
    rf_tuning_connect_to_ap(&rf_tuning_local_ip_params, &rf_tuning_req_join);   

    /* create task */
    if (p_rf_tuning_task == ICT_NULL)
    {
        INT32 result;

        p_rf_tuning_task = ict_api_malloc(sizeof(TN_TCB));
        if (p_rf_tuning_task == ICT_NULL)
        {
            printf("p_rf_tunnig_task malloc failed.\n");
            return;
        }
        
        ICT_MEMSET(p_rf_tuning_task, 0x00, sizeof(*p_rf_tuning_task));
        ICT_MEMSET(rf_tuning_task_stack, 0x00, sizeof(rf_tuning_task_stack));

        result = ict_api_tn_task_create(p_rf_tuning_task, "ping", rf_tuning_operation_task, NULL, &rf_tuning_task_stack[RF_TUNING_TASK_STACK_SIZE-1], RF_TUNING_TASK_STACK_SIZE, RF_TUNING_TASK_PRI);
        printf("ict_api_tn_task_create result(%d)\n", result);
    }  
    
    return;
}

