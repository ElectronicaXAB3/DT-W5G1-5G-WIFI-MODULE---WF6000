/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: user_main.c
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/


/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/
#include "ict_cm_globals.h"

/*
******************************************************************************
* 	LOCAL CONSTANTS
******************************************************************************
*/

#define USE_CONSOLE_PORT            (1)

#define HTTP_SSL_TASK_STACK_SIZE    1024
#define HTTP_SSL_TASK_PRI           1

#define CONSOLE_PORT                UART2
#define CONSOLE_BUFF_SIZE           256

#define HTTP_SSL_MAX_SOCK_FD        5

/*
******************************************************************************
*	LOCAL DATA TYPES
******************************************************************************
*/

typedef enum
{
    HTTP_GET,
    HTTP_POST
} http_method_type_t;

typedef enum
{
    HTTP_SSL_SM_CLI_INIT = 0,    
    HTTP_SSL_SM_CLI_INPUT_AP_SSID,
    HTTP_SSL_SM_CLI_INPUT_AP_PASSWD,
    HTTP_SSL_SM_CLI_JOIN_AP,
    HTTP_SSL_SM_CLI_INPUT_HOST_URL,
    HTTP_SSL_SM_CLI_METHOD_REQ_GET,
    HTTP_SSL_SM_CLI_GET_RESPONSE,
    HTTP_SSL_SM_CLI_GET_BODY,
    HTTP_SSL_SM_CLI_GET_SESSION_CLOSE,
    HTTP_SSL_SM_CLI_METHOD_REQ_POST,
    HTTP_SSL_SM_CLI_POST_RESPONSE,
    HTTP_SSL_SM_CLI_POST_BODY,
    HTTP_SSL_SM_CLI_POST_SESSION_CLOSE,
    HTTP_SSL_SM_CLI_END
} HTTP_SSL_CLI_SM_STATE;

typedef struct
{
    UINT32  len;
    UINT8   buf[CONSOLE_BUFF_SIZE];
} ICT_ST_CONS_DATA_T;

typedef struct
{
    INT32 associated;
    UINT32 resp_code;    
    UINT32 body_len;
    UINT32 session_close;

    UINT32 reassoc_cnt;
    UINT32 waiting_cnt;
    
    UINT8 host_url[CONSOLE_BUFF_SIZE];
    UINT8 post_msg[CONSOLE_BUFF_SIZE];

    HTTP_SSL_CLI_SM_STATE sm_state;

    ICT_ST_JOIN_REQ_T   join_req;
    ICT_ST_NETWORK_INFO_IND_T network_info;
} ICT_ST_HTTP_SSL_CNTX_T;

/*
******************************************************************************
*	GLOBAL VARIABLES
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL VARIABLES
******************************************************************************
*/

TN_TCB *p_http_ssl_task = ICT_NULL;
DWALIGN OS_STK http_ssl_task_stack[HTTP_SSL_TASK_STACK_SIZE] XDWALIGN;

static UINT8 b_associated = ICT_FALSE;

static ICT_ST_CONS_DATA_T       cons_line_data;
static ICT_ST_HTTP_SSL_CNTX_T   http_ssl_cntx;

/*
******************************************************************************
*	LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/


/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/

void console_port_config(void)
{
    ict_api_uart_init(CONSOLE_PORT);
    ict_api_uart_open(CONSOLE_PORT);    
    ict_api_uart_change_baudrate (CONSOLE_PORT, 115200, fMACWLEN(UART_WORD_LEN_8BITS));
}

INT32 console_is_rx_empty(void)
{
    return ict_api_uart_is_rx_empty(CONSOLE_PORT);
}

UINT32 console_get_data(char *buf, UINT32 maxLen)
{
    return (UINT32)ict_api_uart_gets(CONSOLE_PORT, buf, maxLen);
}

UINT32 console_send_byte(char ch)
{
    return (UINT32)ict_api_uart2_putc(ch);
}

void console_send_data(UINT8 *buf, UINT32 len)
{
    ict_api_uart_direct_send_w_size(CONSOLE_PORT, buf, len);
}

void console_printf (char *fmt,...)
{
	va_list             ap;
    char                str[128];
    int                 size;
    
    va_start(ap, fmt);
	size = xn_vsprintf (&str, fmt, ap);
    size &= (sizeof(str)-1);
    ict_api_uart_direct_send_w_size(CONSOLE_PORT, str, size);    
  	va_end (ap);
}

INT32 console_get_line(ICT_ST_CONS_DATA_T *p_data)
{
    char    cons_buf[CONSOLE_BUFF_SIZE];
    UINT32  cons_len = 0;
    UINT32  data_cnt = 0;
    char    ch;
    
    if(console_is_rx_empty())
    {
        return ICT_FALSE;
    }
    else
    {
        cons_len = console_get_data(cons_buf, sizeof(cons_buf));
    }
    
    while(cons_len > data_cnt)
    {
        ch = cons_buf[data_cnt++];
        
        if(ch == '\b')
        {            
            if(p_data->len)
            {
                p_data->len -= 1;
                p_data->buf[p_data->len] = '\0';
                console_printf("\b \b");                
            }
            continue;
        }
        
        if((ch == 0x0D) || (ch == 0x0A))
        {
            if(p_data->len)                
            {
                p_data->buf[p_data->len++] = '\0';
                return ICT_TRUE;
            }
            else
            {
                p_data->buf[0] = '\0';
                return ICT_TRUE;
            }
        }
        else
        {
            console_send_byte(ch);
            p_data->buf[p_data->len++] = ch;
        }
    }

    return ICT_FALSE;
}

void wlan_config(void)
{
    UINT8 ssid[MAX_SSID_LEN] = "HTTPS_TEST";
    UINT8 password[MAX_PSK_LEN] = "";
    UINT16 dhcp_en = ICT_TRUE; /* DHCP */    
    ICT_ST_HTTP_SSL_CNTX_T  *p_cntx;
    INT32 result;

    p_cntx = &http_ssl_cntx;
    ICT_MEMSET(p_cntx, 0, sizeof(ICT_ST_HTTP_SSL_CNTX_T));

    p_cntx->associated = ICT_FALSE;
    
    ICT_MEMSET(&p_cntx->join_req, 0x00, sizeof(ICT_ST_JOIN_REQ_T));
    p_cntx->join_req.ssid_len = ICT_STRLEN(ssid);
    ICT_STRCPY(p_cntx->join_req.ssid, ssid);
    p_cntx->join_req.key_len = ICT_STRLEN(password);
    ICT_STRCPY(p_cntx->join_req.key, password);
    
    if (p_cntx->join_req.ssid_len) printf("ssid: %s\n", p_cntx->join_req.ssid);
    if (p_cntx->join_req.key_len) printf("pwd: %s\n", p_cntx->join_req.key);

    result = ict_api_join_handler(&p_cntx->join_req);
    printf("[%s] result: %d\n", __func__, result);
}

void https_request(UINT8 method_type)
{
    char host[64];
    INT32 result;

    //ICT_STRCPY(host, "https://www.google.com");
    ICT_STRCPY(host, "https://192.168.43.1");
    
    if (method_type == HTTP_GET)
    {
        result = ict_api_httpc_init(host, ICT_STRLEN(host), method_type);
    }
    else
    {
        char post_message[] = "post test message";        
        result = ict_api_httpc_post_octetstream_init(host, ICT_STRLEN(host), post_message, ICT_STRLEN(post_message));
    }
    
    printf("HTTP (%s) request to (%s) result(%d)\n", (method_type) ? "POST":"GET", host, result);
}

void http_recv_control_ind(UINT16 ind_code)
{
    ICT_ST_HTTP_SSL_CNTX_T  *p_cntx = &http_ssl_cntx;
    
    switch (ind_code)
    {
        case APP_HTTPC_RESULT_OK:
            printf("[IND] HTTP_RESULT_OK\n");
            break;
            
        case APP_HTTPC_RESULT_ERR_UNKNOWN:
            printf("[IND] HTTP_RESULT_ERR_UNKNOWN\n");
            break;
            
        case APP_HTTPC_RESULT_ERR_CONNECT:
            printf("[IND] HTTP_RESULT_ERR_CONNECT\n");
            break;
            
        case APP_HTTPC_RESULT_ERR_HOSTNAME:
            printf("[IND] HTTP_RESULT_ERR_HOSTNAME\n");
            break;
            
        case APP_HTTPC_RESULT_ERR_CLOSED:
            printf("[IND] HTTP_RESULT_ERR_CLOSED\n");
            break;
            
        case APP_HTTPC_RESULT_ERR_TIMEOUT:
            printf("[IND] HTTP_RESULT_ERR_TIMEOUT\n");
            break;
            
        case APP_HTTPC_RESULT_ERR_SVR_RESP:
            printf("[IND] HTTP_RESULT_ERR_SVR_RESP\n");
            break;
            
        case APP_HTTPC_RESULT_ERR_INITIALIZE:
            printf("[IND] HTTP_RESULT_ERR_INITIALIZE\n");
            break;
            
        case APP_HTTPC_RESULT_ERR_ARGUMENT:
            printf("[IND] HTTP_RESULT_ERR_ARGUMENT\n");
            break;
            
        case APP_HTTPC_RESULT_ERR_MEMORY:
            printf("[IND] HTTP_RESULT_ERR_MEMORY\n");
            break;
            
        case APP_HTTPC_RESULT_SESSION_SUCCESS:
            printf("[IND] HTTP_RESULT_SESSION_SUCCESS\n");
            break;
            
        case APP_HTTPC_RESULT_SESSION_CLOSED:
            printf("[IND] HTTP_RESULT_SESSION_CLOSED\n");
            p_cntx->session_close = ICT_TRUE;
            break;

        default:
            printf("[IND] UNKNOWN\n");
            break;                        
    }
}

void http_recv_response_number_ind(UINT32 response_number)
{
    printf("[RESPONSE NUMBER] (%d)\n", response_number);
}

void http_recv_body_ind(UINT32 len, UINT8 *buf)
{
    printf("[BODY] len(%d)\n", len);
    //MSG_PRINTF(buf);
}

void user_event_handler(T_MAC_EVENT *p_mac_event)
{
    ICT_ST_HTTP_SSL_CNTX_T  *p_cntx;

    p_cntx = &http_ssl_cntx;
    
    switch(p_mac_event->code)
    {
        case ICT_HIF_CMD_ST_JOIN_IND:
            if(ict_api_join_state(p_mac_event->buf) == ICT_TRUE)
            {
                printf("I: [ASSOCIATED]\n");
            }
            break;
            
        case ICT_HIF_CMD_ST_DISCONNECTED_IND:
            printf("I: [DISASSOCIATED]\n");
            break;
        
        case ICT_HIF_CMD_ST_NETWORK_INFO_IND:
            {
                ICT_ST_NETWORK_INFO_IND_T *network_ind;
                network_ind = (ICT_ST_NETWORK_INFO_IND_T *)p_mac_event->buf;

                ICT_MEMCPY(&p_cntx->network_info, network_ind, sizeof(ICT_ST_NETWORK_INFO_IND_T));
                
                printf("IP       "IPSTR"\n", IP2STR(network_ind->ipaddr));
                printf("SUBNET   "IPSTR"\n", IP2STR(network_ind->subnet));
                printf("GATEWAY  "IPSTR"\n", IP2STR(network_ind->gateway));
                printf("DNS      "IPSTR"\n", IP2STR(network_ind->dns));
                
                b_associated = ICT_TRUE;
                p_cntx->associated = ICT_TRUE;
            }
            break;
            
        case ICT_HIF_CMD_ST_HTTP_CONTROL_IND:
            {
                UINT16 http_ind_result = *(UINT16 *)p_mac_event->buf;

                http_recv_control_ind(http_ind_result);
            }
            break;
            
        case ICT_HIF_CMD_ST_HTTP_RESPONSECODE_IND:
            {
                UINT32 http_response_code = *(UINT32 *)p_mac_event->buf;

                p_cntx->resp_code = http_response_code;                
                http_recv_response_number_ind(http_response_code);
            }
            break;       
            
        case ICT_HIF_CMD_ST_HTTP_BODY_IND:
            {
                http_recv_body_ind(p_mac_event->len, p_mac_event->buf);
            }
            break;     
            
        default:
            printf("@@@[%s] p_mac_event->code = 0x%x\n\n", __func__, p_mac_event->code);
            break;
    }
}

void http_ssl_client_proc(ICT_ST_HTTP_SSL_CNTX_T *p_cntx)
{
    ICT_ST_JOIN_REQ_T   *p_join_req;
    ICT_ST_CONS_DATA_T  *p_cons_line;
    INT32 result;

    p_join_req = &p_cntx->join_req;
    p_cons_line = &cons_line_data;

    switch(p_cntx->sm_state)
    {
    case HTTP_SSL_SM_CLI_INIT:
        p_cntx->associated = ICT_FALSE;
        p_cntx->session_close = ICT_FALSE;
        p_cntx->resp_code = 0;
        p_cntx->body_len = 0;
        
        ICT_MEMSET(p_join_req, 0, sizeof(ICT_ST_JOIN_REQ_T));
        p_cons_line->len = 0;

        console_printf("\r\n");
        console_printf("================================\r\n");
        console_printf("=       HTTP SSL CLIENT        =\r\n");
        console_printf("================================\r\n");

        p_cntx->waiting_cnt = 0;
        p_cons_line->len = 0;
        console_printf("\r\n$ AP SSID : ");
        p_cntx->sm_state = HTTP_SSL_SM_CLI_INPUT_AP_SSID;
        break;
        
    case HTTP_SSL_SM_CLI_INPUT_AP_SSID:
        if(console_get_line(p_cons_line) == ICT_TRUE)
        {
            if(p_cons_line->len == 0)
            {
                p_cntx->waiting_cnt = 0;
                console_printf("\r\n$ AP SSID : ");
                break;
            }
            
            console_printf("\r\n  => %s\r\n", p_cons_line->buf);
            
            ICT_STRCPY(p_join_req->ssid, p_cons_line->buf);
            p_join_req->ssid_len = ICT_STRLEN(p_join_req->ssid);

            console_printf("\r\n$ AP PASSWORD : ");
            p_cntx->waiting_cnt = 0;
            p_cons_line->len = 0;
            p_cntx->sm_state = HTTP_SSL_SM_CLI_INPUT_AP_PASSWD;
        }
        break;
        
    case HTTP_SSL_SM_CLI_INPUT_AP_PASSWD:
        if(console_get_line(p_cons_line) == ICT_TRUE)
        {
            console_printf("\r\n  => %s\r\n", p_cons_line->buf);
            
            ICT_STRCPY(p_join_req->key, p_cons_line->buf);
            p_join_req->key_len = ICT_STRLEN(p_join_req->key);    

            console_printf("\r\n Join Start...\r\n");        
            ict_api_join_handler(p_join_req);
            p_cntx->sm_state = HTTP_SSL_SM_CLI_JOIN_AP;
        }
        else
        {
            p_cntx->waiting_cnt++;
            if(p_cntx->waiting_cnt > 2000) /* timeout 20sec */
            {
                console_printf("\r\n@ Input time exceeded. Restart!\r\n");
                p_cntx->sm_state = HTTP_SSL_SM_CLI_INIT;
            }
        }
        break;
        
    case HTTP_SSL_SM_CLI_JOIN_AP:
        if(p_cntx->associated == ICT_TRUE)
        {
            console_printf("\r\n");
            console_printf(" IP       "IPSTR"\r\n", IP2STR(p_cntx->network_info.ipaddr));
            console_printf(" SUBNET   "IPSTR"\r\n", IP2STR(p_cntx->network_info.subnet));
            console_printf(" GATEWAY  "IPSTR"\r\n", IP2STR(p_cntx->network_info.gateway));
            console_printf(" DNS      "IPSTR"\r\n", IP2STR(p_cntx->network_info.dns));
                
            console_printf("\r\n Association Success!\r\n");
            console_printf("\r\n HTTP Client Start...\r\n");

            p_cons_line->len = 0;
            console_printf("\r\n$ URL : ");
            p_cntx->sm_state = HTTP_SSL_SM_CLI_INPUT_HOST_URL;
        }
        else
        {
            p_cntx->waiting_cnt++;            
            if((p_cntx->associated == ICT_ERR) || (p_cntx->waiting_cnt > 2000)) /* timeout 20sec */
            {
                p_cntx->reassoc_cnt++;
                console_printf("\r\n@ Association Failed!\r\n");
                p_cntx->waiting_cnt = 0;
                p_cntx->associated = ICT_FALSE;

                if(p_cntx->reassoc_cnt > 5)
                {
                    p_cntx->sm_state = HTTP_SSL_SM_CLI_INIT;
                }
            }            
        }        
        break;

    case HTTP_SSL_SM_CLI_INPUT_HOST_URL:
        if(console_get_line(p_cons_line) == ICT_TRUE)
        {
            console_printf("\r\n  => %s\r\n", p_cons_line->buf);

            ICT_STRCPY(p_cntx->host_url, p_cons_line->buf);
            p_cntx->sm_state = HTTP_SSL_SM_CLI_METHOD_REQ_GET;
        }
        break;

    case HTTP_SSL_SM_CLI_METHOD_REQ_GET:
        ict_api_httpc_init(p_cntx->host_url, ICT_STRLEN(p_cntx->host_url), HTTP_GET);
        p_cntx->sm_state = HTTP_SSL_SM_CLI_GET_RESPONSE;
        break;
        
    case HTTP_SSL_SM_CLI_GET_RESPONSE:
        if(p_cntx->resp_code)
        {
            console_printf("\r\n Method Get Response Code => %d\r\n", p_cntx->resp_code);
            p_cntx->resp_code = 0;
            p_cntx->sm_state = HTTP_SSL_SM_CLI_GET_BODY;
        }
        break;

    case HTTP_SSL_SM_CLI_GET_BODY:
        if(p_cntx->body_len)
        {
            console_printf("\r\n Method Get Body Len => %d\r\n", p_cntx->body_len);
            p_cntx->body_len = 0;
        }
        else if(p_cntx->session_close == ICT_TRUE)
        {
            console_printf("\r\n Method Get Session Close\r\n");
            p_cntx->session_close = ICT_FALSE;
            
            p_cons_line->len = 0;            
            console_printf("\r\n$ POST SEND MESSAGE : ");
            p_cntx->sm_state = HTTP_SSL_SM_CLI_METHOD_REQ_POST;
        }        
        break;

    case HTTP_SSL_SM_CLI_METHOD_REQ_POST:
        if(console_get_line(p_cons_line) == ICT_TRUE)
        {
            console_printf("\r\n  => %s\r\n", p_cons_line->buf);

            ICT_STRCPY(p_cntx->post_msg, p_cons_line->buf);
            result = ict_api_httpc_post_octetstream_init(p_cntx->host_url, ICT_STRLEN(p_cntx->host_url), p_cntx->post_msg, ICT_STRLEN(p_cntx->post_msg));
            console_printf("HTTP_POST : result = %d (%s)\n", result, p_cntx->host_url);
            p_cntx->sm_state = HTTP_SSL_SM_CLI_POST_RESPONSE;
        }
        break;

    case HTTP_SSL_SM_CLI_POST_RESPONSE:
        if(p_cntx->resp_code)
        {
            console_printf("\r\n Method Post Response Code => %d\r\n", p_cntx->resp_code);
            p_cntx->resp_code = 0;
            p_cntx->sm_state = HTTP_SSL_SM_CLI_POST_BODY;
        }
        break;

    case HTTP_SSL_SM_CLI_POST_BODY:
        if(p_cntx->body_len)
        {
            console_printf("\r\n Method Post Body Len => %d\r\n", p_cntx->body_len);
            p_cntx->body_len = 0;
        }
        else if(p_cntx->session_close == ICT_TRUE)
        {
            console_printf("\r\n Method Post Session Close\r\n");
            p_cntx->session_close = ICT_FALSE;
            
            p_cons_line->len = 0;
            console_printf("\r\n$ URL : ");
            p_cntx->sm_state = HTTP_SSL_SM_CLI_INPUT_HOST_URL;
        }        
        break;
        
    case HTTP_SSL_SM_CLI_END:
        //...
        break;
        
    default:
        break;
    }
}

static void http_ssl_client_task(void *arg)
{
    arg = arg;
    static UINT32 cnt = 0;
    ICT_ST_HTTP_SSL_CNTX_T  *p_cntx;

p_cntx = &http_ssl_cntx;    
#if USE_CONSOLE_PORT    
    p_cntx->sm_state = HTTP_SSL_SM_CLI_INIT;
#endif
    printf("\n");
    printf("==============================================\n");
    printf("=       HTTP SSL CLIENT task started.        =\n");
    printf("==============================================\n");

    while(1)
    {
#if USE_CONSOLE_PORT
        http_ssl_client_proc(p_cntx);        
#else
        if(p_cntx->associated == ICT_TURE)
        {
            if(cnt == 100)
            {
                https_request(HTTP_GET);
            }
            else if(cnt == 1000)
            {
                https_request(HTTP_POST);
            }
            cnt++;
        }            
#endif  
        ict_api_tn_task_sleep(1); // 10 msec sleep        
    }        
}

void user_start()
{
    ict_api_tn_task_sleep(10);

    /* The default baudrate of UART0 is 8000000. */
    /* The baudrate of UART0 can be changed to 115200 or 230400, ..., 8000000 */
    printf("=== Start baudrate of UART%d : %d ===\n", UART0, ict_api_uart_get_baudrate(UART0));
    //ict_api_uart_change_baudrate (UART0, 8000000, fMACWLEN(UART_WORD_LEN_8BITS));        
    printf("\n");
    printf("=== Current baudrate of UART%d : %d ===\n", UART0, ict_api_uart_get_baudrate(UART0));  
    printf("**********************************************\n");
    printf("*              USER started.                 *\n");
    printf("**********************************************\n");
    printf("-- http ssl client\n\n");
    
#if USE_CONSOLE_PORT
    console_port_config();
#else
    wlan_config();    
#endif
    ict_cm_wlan_event_callback_register((void *)user_event_handler);

    /* create task */
    if (p_http_ssl_task == ICT_NULL)
    {
        INT32 result;
        
        p_http_ssl_task = ict_api_malloc(sizeof(TN_TCB));
        if (p_http_ssl_task == ICT_NULL)
        {
            printf("p_http_ssl_task malloc failed.\n");
            return;
        }
        
        ICT_MEMSET(p_http_ssl_task, 0x00, sizeof(*p_http_ssl_task));
        ICT_MEMSET(http_ssl_task_stack, 0x00, sizeof(http_ssl_task_stack));

        result = ict_api_tn_task_create(p_http_ssl_task, 
                                        "http_ssl", 
                                        http_ssl_client_task, 
                                        NULL, 
                                        &http_ssl_task_stack[HTTP_SSL_TASK_STACK_SIZE-1], 
                                        HTTP_SSL_TASK_STACK_SIZE, 
                                        HTTP_SSL_TASK_PRI);
        
        printf("ict_api_tn_task_create result(%d)\n", result);
    }    

    return;
}


