/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: user_main.c
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/


/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/
#include "ict_app_globals.h"

/*
******************************************************************************
* 	LOCAL CONSTANTS
******************************************************************************
*/

#define SNIFFER_TASK_STACK_SIZE    1024
#define SNIFFER_TASK_PRI           1

/*
******************************************************************************
*	LOCAL DATA TYPES
******************************************************************************
*/

/*
******************************************************************************
*	GLOBAL VARIABLES
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL VARIABLES
******************************************************************************
*/
TN_TCB *p_sniffer_task = ICT_NULL;
DWALIGN OS_STK sniffer_task_stack[SNIFFER_TASK_STACK_SIZE] XDWALIGN;

/*
******************************************************************************
*	LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/


/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/

void sniffer_rx_cb(void *p_buffer, int len, void *p_link)
{    
    ICT_COMMON_MAC_HEADER *p_mac_header;    
    ICT_RX_LINK_STATUS *p_link_status;
    int frame_len;

    p_mac_header = (ICT_COMMON_MAC_HEADER *)p_buffer;
    p_link_status = (ICT_RX_LINK_STATUS *)p_link;
    frame_len = len;
    
    printf("fc: %04X src("ICT_MACSTR") dst("ICT_MACSTR") SN=%04d frame_len=%04d : RSSI=(-%d) SNR=(%d)\n",
                    p_mac_header->frame_control,
                    ICT_MAC2STR(p_mac_header->address2), ICT_MAC2STR(p_mac_header->address1), 
                    ICT_SC_SN(p_mac_header->sequence_control), frame_len,
                    p_link_status->rssi, p_link_status->snr);

    //TODO: User application ...

    return;
}

static void sniffer_task(void *arg)
{
    arg = arg;
    static int num;

    printf("\n");
    printf("==============================================\n");
    printf("=           sniffer task started.            =\n");    
    printf("==============================================\n");

    while(1)
    {
        UINT8 channel;

        if (num == 1)
        {
            channel = 1;
            ict_api_set_channel(channel);
            ict_api_set_sniffer_mode(ICT_TRUE, sniffer_rx_cb);
        }
        else if (num == 10)
        {
            channel = 11;
            ict_api_set_channel(channel);
        }
        else if (num == 20)
        {
            channel = 46;
            ict_api_set_channel(channel);
        }
        
        num++;
        ict_api_tn_task_sleep(100);     // 100msec sleep
    }    
}

void user_start(void)
{
    ict_api_tn_task_sleep(10);

    /* The default baudrate of UART0 is 8000000. */
    /* The baudrate of UART0 can be changed to 115200 or 230400, ..., 8000000 */
//    ict_api_uart_change_baudrate (UART0, 8000000, fMACWLEN(UART_WORD_LEN_8BITS));
    
    printf("\n");
    printf("=== Current baudrate of UART%d : %d ===\n", UART0, ict_api_uart_get_baudrate(UART0));  
    printf("**********************************************\n");
    printf("*              USER started.                 *\n");
    printf("**********************************************\n");
    printf("-- sniffer\n\n");

    /* create task */
    if (p_sniffer_task == ICT_NULL)
    {
        INT32 result;
        
        p_sniffer_task = ict_api_malloc(sizeof(TN_TCB));
        if (p_sniffer_task == ICT_NULL)
        {
            printf("p_sniffer_task malloc failed.\n");
            return;
        }
        
        ICT_MEMSET(p_sniffer_task, 0x00, sizeof(*p_sniffer_task));
        ICT_MEMSET(sniffer_task_stack, 0x00, sizeof(sniffer_task_stack));

        result = ict_api_tn_task_create(p_sniffer_task, "sniffer", sniffer_task, NULL, &sniffer_task_stack[SNIFFER_TASK_STACK_SIZE-1], SNIFFER_TASK_STACK_SIZE, SNIFFER_TASK_PRI);
        printf("ict_api_tn_task_create result(%d)\n", result);
    }    
    
    return;
}


