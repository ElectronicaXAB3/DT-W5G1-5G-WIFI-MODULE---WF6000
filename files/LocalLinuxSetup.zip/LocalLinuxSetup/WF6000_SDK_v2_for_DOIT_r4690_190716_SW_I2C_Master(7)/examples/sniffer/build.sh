#!/bin/bash

# Parse argument list
CLEAN=0
WF6300=0
while :
do
    if [ $# -eq 0 ]; then
        break;
    fi

    option=$1
    shift

    option=`echo "$option" | sed 's/\([^=]*\).*/\1/'` > /dev/null

    case $option in
        clean)      ALL=0 CLEAN=1  ;;
        wf6300)     WF6300=1  ;;
    esac
done

echo "======================================= CONFIG"
CPU_JOB_NUM=$(grep processor /proc/cpuinfo | awk '{field=$NF};END{print field+1}')
CURR_DIR=$(pwd)
export USER_DIR=sniffer

echo "CURR_DIR: $CURR_DIR"
echo "USER_DIR: $USER_DIR"

echo "======================================= CLEAN"
rm *.bin
cd ../../
make -f sf_loader/Makefile clean
make -f Makefile clean

if [ $CLEAN -eq 0 ]
then
    echo "======================================= COMPILE"
	make -f Makefile -j$CPU_JOB_NUM
	
    if [ $WF6300 -eq 1 ]
	then
	    echo "======================================= MAKE IMAGE [WF6300]"
	    make -f Makefile FW_IMAGE=SF_LOADER sr_reloc -j$CPU_JOB_NUM
	    mv FW_*.BLw $CURR_DIR/.
	else
	    echo "======================================= MAKE IMAGE [WF6000]"
	    make -f Makefile FW_IMAGE=SF_LOADER sf_reloc -j$CPU_JOB_NUM
	    make -f sf_loader/Makefile rom -j$CPU_JOP_NUM	
	    mv FW_*.bin $CURR_DIR/.
	fi
fi

echo "======================================= END"
cd $CURR_DIR
