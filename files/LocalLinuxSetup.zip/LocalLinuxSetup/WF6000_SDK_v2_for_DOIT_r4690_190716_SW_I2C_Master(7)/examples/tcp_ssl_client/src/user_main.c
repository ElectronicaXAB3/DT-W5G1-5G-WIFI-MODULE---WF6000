/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: user_main.c
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/


/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/
#include "ict_cm_globals.h"

/*
******************************************************************************
* 	LOCAL CONSTANTS
******************************************************************************
*/

#define USE_CONSOLE_PORT            (1)

#define TCP_SSL_TASK_STACK_SIZE     1024
#define TCP_SSL_TASK_PRI            1

#define TCP_SSL_MTU_BODY_SIZE       1460

#define CONSOLE_PORT                UART2
#define CONSOLE_BUFF_SIZE           256

#define TCP_SSL_MAX_SOCK_FD         5

/*
******************************************************************************
*	LOCAL DATA TYPES
******************************************************************************
*/

typedef enum
{
    TCP_SSL_TYPE_CONNECT,
    TCP_SSL_TYPE_SEND
} TCP_SSL_IND;

typedef enum
{
    TCP_SSL_SM_CLI_INIT = 0,
    TCP_SSL_SM_CLI_INPUT_AP_SSID,
    TCP_SSL_SM_CLI_INPUT_AP_PASSWD,
    TCP_SSL_SM_CLI_INPUT_HOST_IP,
    TCP_SSL_SM_CLI_INPUT_PORT_NUM,
    TCP_SSL_SM_CLI_JOIN_AP,
    TCP_SSL_SM_CLI_CONNECT_HOST,
    TCP_SSL_SM_CLI_SEND_DATA,
    TCP_SSL_SM_CLI_END
} TCP_SSL_CLI_SM_STATE;

typedef struct
{
    INT32   sock_fd;
    UINT32  len;
    UINT8   buf[TCP_SSL_MTU_BODY_SIZE];
} ICT_ST_SOCK_DATA_T;

typedef struct
{
    UINT32  len;
    UINT8   buf[CONSOLE_BUFF_SIZE];
} ICT_ST_CONS_DATA_T;

typedef struct
{
    INT32 associated;
    INT32 connected;
    INT32 started;    

    UINT32 port_num;
    
    UINT32 reassoc_cnt;
    UINT32 waiting_cnt;
    INT32 sock_fd[TCP_SSL_MAX_SOCK_FD];
    UINT8 host_ip[32];
    
    TCP_SSL_CLI_SM_STATE sm_state;

    ICT_ST_JOIN_REQ_T   join_req;
    ICT_ST_NETWORK_INFO_IND_T network_info;
} ICT_ST_TCP_SSL_CNTX_T;

/*
******************************************************************************
*	GLOBAL VARIABLES
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL VARIABLES
******************************************************************************
*/

TN_TCB *p_tcp_ssl_task = ICT_NULL;

static ICT_ST_SOCK_DATA_T       recv_sock_data;
static ICT_ST_CONS_DATA_T       cons_line_data;

static ICT_ST_TCP_SSL_CNTX_T    tcp_ssl_cntx;

/*
******************************************************************************
*	LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/

DWALIGN OS_STK tcp_ssl_task_stack[TCP_SSL_TASK_STACK_SIZE] XDWALIGN;
DWALIGN TN_EVENT uart_event_group XDWALIGN;

/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/

void console_port_config(void)
{
    ict_api_uart_init(CONSOLE_PORT);
    ict_api_uart_open(CONSOLE_PORT);    
    ict_api_uart_change_baudrate (CONSOLE_PORT, 115200, fMACWLEN(UART_WORD_LEN_8BITS));
}

INT32 console_is_rx_empty(void)
{
    return ict_api_uart_is_rx_empty(CONSOLE_PORT);
}

UINT32 console_get_data(char *buf, UINT32 maxLen)
{
    return (UINT32)ict_api_uart_gets(CONSOLE_PORT, buf, maxLen);
}

UINT32 console_send_byte(char ch)
{
    return (UINT32)ict_api_uart2_putc(ch);
}

void console_send_data(UINT8 *buf, UINT32 len)
{
    ict_api_uart_direct_send_w_size(CONSOLE_PORT, buf, len);
}

void console_printf (char *fmt,...)
{
	va_list             ap;
    char                str[128];
    int                 size;
    
    va_start(ap, fmt);
	size = xn_vsprintf (&str, fmt, ap);
    size &= (sizeof(str)-1);
    ict_api_uart_direct_send_w_size(CONSOLE_PORT, str, size);    
  	va_end (ap);
}

INT32 console_get_line(ICT_ST_CONS_DATA_T *p_data)
{
    char    cons_buf[CONSOLE_BUFF_SIZE];
    UINT32  cons_len = 0;
    UINT32  data_cnt = 0;
    char    ch;
    
    if(console_is_rx_empty())
    {
        return ICT_FALSE;
    }
    else
    {
        cons_len = console_get_data(cons_buf, sizeof(cons_buf));
    }
    
    while(cons_len > data_cnt)
    {
        ch = cons_buf[data_cnt++];
        
        if(ch == '\b')
        {            
            if(p_data->len)
            {
                p_data->len -= 1;
                p_data->buf[p_data->len] = '\0';
                console_printf("\b \b");                
            }
            continue;
        }
        
        if((ch == 0x0D) || (ch == 0x0A))
        {
            if(p_data->len)                
            {
                p_data->buf[p_data->len++] = '\0';
                return ICT_TRUE;
            }
            else
            {
                p_data->buf[0] = '\0';
                return ICT_TRUE;
            }
        }
        else
        {
            console_send_byte(ch);
            p_data->buf[p_data->len++] = ch;
        }
    }

    return ICT_FALSE;
}

void wlan_config(void)
{
    UINT8 ssid[MAX_SSID_LEN] = "test_ap";
    UINT8 password[MAX_PSK_LEN] = "12345678";
    UINT16 dhcp_en = ICT_TRUE; /* DHCP */    
    ICT_ST_TCP_SSL_CNTX_T  *p_cntx;
    INT32 result;

    p_cntx = &tcp_ssl_cntx;
    ICT_MEMSET(p_cntx, 0, sizeof(ICT_ST_TCP_SSL_CNTX_T));

    p_cntx->associated = ICT_FALSE;
    p_cntx->connected = ICT_FALSE;
    p_cntx->started = ICT_FALSE;
    p_cntx->sock_fd[0] = 0;
    p_cntx->sock_fd[1] = -1;
    p_cntx->sock_fd[2] = -1;
    p_cntx->sock_fd[3] = -1;
    p_cntx->sock_fd[4] = -1;
    
    ICT_MEMSET(&p_cntx->join_req, 0x00, sizeof(ICT_ST_JOIN_REQ_T));
    p_cntx->join_req.ssid_len = ICT_STRLEN(ssid);
    ICT_STRCPY(p_cntx->join_req.ssid, ssid);
    p_cntx->join_req.key_len = ICT_STRLEN(password);
    ICT_STRCPY(p_cntx->join_req.key, password);
    
    if (p_cntx->join_req.ssid_len) printf("ssid: %s\n", p_cntx->join_req.ssid);
    if (p_cntx->join_req.key_len) printf("pwd: %s\n", p_cntx->join_req.key);

    result = ict_api_join_handler(&p_cntx->join_req);
    printf("[%s] result: %d\n", __func__, result);
}

void tcp_ssl_client_start()
{
    char host[32];
    INT32 result;
    ICT_ST_TCP_SSL_CNTX_T  *p_cntx;

    p_cntx = &tcp_ssl_cntx;

    p_cntx->sock_fd[0] = 0;
    ICT_STRCPY(host, "192.168.1.18");
    p_cntx->port_num = 51000;
    
    result = ict_api_tcp_ssl_start_handler(p_cntx->sock_fd[0], host, p_cntx->port_num);    
    printf("[%s] result: %d\n", __func__, result);
}

void user_event_handler(T_MAC_EVENT *p_mac_event)
{
    ICT_ST_TCP_SSL_CNTX_T   *p_cntx;
    ICT_ST_SOCK_DATA_T      *p_recv;
    INT32 result;

    p_cntx = &tcp_ssl_cntx;
    p_recv = &recv_sock_data;
    
    switch(p_mac_event->code)
    {
        case ICT_HIF_CMD_ST_JOIN_IND:
            result = ict_api_join_state(p_mac_event->buf);
            if(result == ICT_TRUE)
            {
                printf("I: [ASSOCIATED]\n");
            }
            else
            {
                p_cntx->associated = ICT_ERR;
                printf("E: Association failed\n");
            }
            break;
            
        case ICT_HIF_CMD_ST_DISCONNECTED_IND:
            printf("I: [DISASSOCIATED]\n");
            break;
        
        case ICT_HIF_CMD_ST_NETWORK_INFO_IND:
            {
                ICT_ST_NETWORK_INFO_IND_T *network_ind;
                network_ind = (ICT_ST_NETWORK_INFO_IND_T *)p_mac_event->buf;
                
                ICT_MEMCPY(&p_cntx->network_info, network_ind, sizeof(ICT_ST_NETWORK_INFO_IND_T));
                
                printf("IP       "IPSTR"\n", IP2STR(network_ind->ipaddr));
                printf("SUBNET   "IPSTR"\n", IP2STR(network_ind->subnet));
                printf("GATEWAY  "IPSTR"\n", IP2STR(network_ind->gateway));
                printf("DNS      "IPSTR"\n", IP2STR(network_ind->dns));

                p_cntx->associated = ICT_TRUE;                
            }

            break;

        case ICT_HIF_CMD_ST_TCP_SSL_IND:
            {
                ICT_ST_TCP_SSL_IND_T *ssl_ind;
                ssl_ind = (ICT_ST_TCP_SSL_IND_T *)p_mac_event->buf;

                if (ssl_ind->type == TCP_SSL_TYPE_CONNECT)
                {
                    printf("W: [CONNECT] sock(%d) result(%s)\n", ssl_ind->socket_desc, (ssl_ind->result == 0 ? "OK" : "ERROR"));
                    
                    if (ssl_ind->result == 0) 
                    {
                        p_cntx->connected = ICT_TRUE;
                        p_cntx->sock_fd[ssl_ind->socket_desc] = ssl_ind->socket_desc; /* server sock_fd is 0 */
                    }
                }
                else if (ssl_ind->type == TCP_SSL_TYPE_SEND)
                {
                    printf("W: [SEND] sock(%d) result(%s)\n", ssl_ind->socket_desc, (ssl_ind->result == 0 ? "OK" : "ERROR"));
                }
            }
            break;

        case ICT_HIF_CMD_ST_TCP_SSL_RECV_IND:
            {
                ICT_ST_TCP_SSL_IND_T *ssl_ind;
                ssl_ind = (ICT_ST_TCP_SSL_IND_T *)p_mac_event->buf;

                printf("I: sock_fd(%d) len(%d)\n", ssl_ind->socket_desc, ssl_ind->data_len);
                if (ssl_ind->data_len < 100)
                {
                    ssl_ind->data[ssl_ind->data_len] = '\0';
                    
                    ICT_MEMCPY(p_recv->buf, ssl_ind->data, ssl_ind->data_len);
                    p_recv->sock_fd = ssl_ind->socket_desc;
                    p_recv->len = ssl_ind->data_len;
                    printf("W: [RECV_C] %s (%d)\n", ssl_ind->data, ssl_ind->data_len);
                }
            }
            break;

        case ICT_HIF_CMD_ST_TCP_SSL_CLOSE_IND:
            {
                ICT_ST_TCP_SSL_IND_T *ssl_ind;
                ssl_ind = (ICT_ST_TCP_SSL_IND_T *)p_mac_event->buf;

                printf("W: [CLOSE] sock(%d) result(%d)\n", ssl_ind->socket_desc, ssl_ind->result);

                if (ssl_ind->result == 0) 
                {
                    p_cntx->connected = ICT_FALSE;
                    p_cntx->sock_fd[ssl_ind->socket_desc] = -1;
                }
            }
            break;            

        case ICT_HIF_CMD_ST_TCP_SSL_SVR_IND:
            {
                ICT_ST_TCP_SSL_IND_T *ssl_ind;
                ssl_ind = (ICT_ST_TCP_SSL_IND_T *)p_mac_event->buf;

                if (ssl_ind->type == TCP_SSL_TYPE_CONNECT)
                {
                    printf("W: [SVR_START] sock(%d) result(%s)\n", ssl_ind->socket_desc, (ssl_ind->result == 0 ? "OK" : "ERROR"));

                    if (ssl_ind->result == 0)
                    {
                        p_cntx->started = ICT_TRUE;
                        p_cntx->sock_fd[ssl_ind->socket_desc] = ssl_ind->socket_desc;                        
                    }
                }
                else if (ssl_ind->type == TCP_SSL_TYPE_SEND)
                {
                    printf("W: [SEND] sock(%d) result(%s)\n", ssl_ind->socket_desc, (ssl_ind->result == 0 ? "OK" : "ERROR"));
                }
            }
            break;

        case ICT_HIF_CMD_ST_TCP_SSL_SVR_RECV_IND:
            {
                ICT_ST_TCP_SSL_IND_T *ssl_ind;
                ssl_ind = (ICT_ST_TCP_SSL_IND_T *)p_mac_event->buf;

                printf("I: sock_fd(%d) len(%d)\n", ssl_ind->socket_desc, ssl_ind->data_len);
                if (ssl_ind->data_len < 100)
                {
                    ssl_ind->data[ssl_ind->data_len] = '\0';
                    ICT_MEMCPY(p_recv->buf, ssl_ind->data, ssl_ind->data_len);
                    p_recv->sock_fd = ssl_ind->socket_desc;
                    p_recv->len = ssl_ind->data_len;
                    printf("W: [RECV_S(client:%d)] %s (%d)\n", ssl_ind->socket_desc, ssl_ind->data, ssl_ind->data_len);
                }
            }
            break;

        case ICT_HIF_CMD_ST_TCP_SSL_SVR_CLOSE_IND:
            {
                ICT_ST_TCP_SSL_IND_T *ssl_ind;
                ssl_ind = (ICT_ST_TCP_SSL_IND_T *)p_mac_event->buf;

                printf("W: [CLOSE] sock(%d) result(%d)\n", ssl_ind->socket_desc, ssl_ind->result);

                if (ssl_ind->result == 0) 
                {
                    p_cntx->started = ICT_FALSE;
                    p_cntx->sock_fd[ssl_ind->socket_desc] = -1;
                }
            }
            break;

        case ICT_HIF_CMD_ST_TCP_SSL_SVR_ACCEPTED_IND:
            {
                ICT_ST_TCP_SSL_IND_T *ssl_ind;
                ssl_ind = (ICT_ST_TCP_SSL_IND_T *)p_mac_event->buf;

                p_cntx->sock_fd[ssl_ind->socket_desc] = ssl_ind->socket_desc;
                
                printf("W: [ACCEPT] sock(%d) result(%d)\n", ssl_ind->socket_desc, ssl_ind->result);
                console_printf("\r\n Accepted Client(%d)\r\n", p_cntx->sock_fd[ssl_ind->socket_desc]);
            }
            break;
            
        default:
            break;
    }
}

void tcp_ssl_client_proc(ICT_ST_TCP_SSL_CNTX_T *p_cntx)
{
    ICT_ST_JOIN_REQ_T   *p_join_req;
    ICT_ST_CONS_DATA_T  *p_cons_line;
    ICT_ST_SOCK_DATA_T  *p_recv_data;
    INT32 result;

    p_join_req = &p_cntx->join_req;
    p_cons_line = &cons_line_data;
    p_recv_data = &recv_sock_data;

    switch(p_cntx->sm_state)
    {
    case TCP_SSL_SM_CLI_INIT:
        p_cntx->associated = ICT_FALSE;
        p_cntx->connected = ICT_FALSE;
        p_cntx->started = ICT_FALSE;
        p_cntx->sock_fd[0] = -1;
        p_cntx->sock_fd[1] = -1;
        p_cntx->sock_fd[2] = -1;
        p_cntx->sock_fd[3] = -1;
        p_cntx->sock_fd[4] = -1;
        
        ICT_MEMSET(p_join_req, 0, sizeof(ICT_ST_JOIN_REQ_T));
        p_cons_line->len = 0;
        p_recv_data->len = 0;

        console_printf("\r\n");
        console_printf("================================\r\n");
        console_printf("=        TCP SSL CLIENT        =\r\n");
        console_printf("================================\r\n");

        p_cntx->waiting_cnt = 0;
        p_cons_line->len = 0;
        console_printf("\r\n$ AP SSID : ");
        p_cntx->sm_state = TCP_SSL_SM_CLI_INPUT_AP_SSID;
        break;

    case TCP_SSL_SM_CLI_INPUT_AP_SSID:
        if(console_get_line(p_cons_line) == ICT_TRUE)
        {
            if(p_cons_line->len == 0)
            {
                console_printf("\r\n$ AP SSID : ");
                break;
            }
            
            console_printf("\r\n  => %s\r\n", p_cons_line->buf);
            
            ICT_STRCPY(p_join_req->ssid, p_cons_line->buf);
            p_join_req->ssid_len = ICT_STRLEN(p_join_req->ssid);

            p_cntx->waiting_cnt = 0;
            p_cons_line->len = 0;
            console_printf("\r\n$ AP PASSWORD : ");
            p_cntx->sm_state = TCP_SSL_SM_CLI_INPUT_AP_PASSWD;
        }
        break;
        
    case TCP_SSL_SM_CLI_INPUT_AP_PASSWD:
        if(console_get_line(p_cons_line) == ICT_TRUE)
        {
            console_printf("\r\n  => %s\r\n", p_cons_line->buf);
            
            ICT_STRCPY(p_join_req->key, p_cons_line->buf);
            p_join_req->key_len = ICT_STRLEN(p_join_req->key);    

            p_cntx->waiting_cnt = 0;
            p_cons_line->len = 0;
            console_printf("\r\n$ HOST IP ADDR : ");
            p_cntx->sm_state = TCP_SSL_SM_CLI_INPUT_HOST_IP;
        }
        else
        {
            p_cntx->waiting_cnt++;
            if(p_cntx->waiting_cnt > 2000) /* timeout 20sec */
            {
                console_printf("\r\n@ Input time exceeded. Restart!\r\n");
                p_cntx->sm_state = TCP_SSL_SM_CLI_INIT;
            }
        }
        break;
        
    case TCP_SSL_SM_CLI_INPUT_HOST_IP:
        if(console_get_line(p_cons_line) == ICT_TRUE)
        {
            if(p_cons_line->len == 0)
            {
                p_cntx->waiting_cnt = 0;
                console_printf("\r\n$ HOST IP ADDR : ");
                break;
            }
            
            console_printf("\r\n  => %s\r\n", p_cons_line->buf);
            
            ICT_STRCPY(p_cntx->host_ip, p_cons_line->buf);

            p_cntx->waiting_cnt = 0;
            p_cons_line->len = 0;
            console_printf("\r\n$ PORT NUMBER : ");
            p_cntx->sm_state = TCP_SSL_SM_CLI_INPUT_PORT_NUM;
        }
        else
        {
            p_cntx->waiting_cnt++;
            if(p_cntx->waiting_cnt > 2000) /* timeout 20sec */
            {
                console_printf("\r\n@ Input time exceeded. Restart!\r\n");
                p_cntx->sm_state = TCP_SSL_SM_CLI_INIT;
            }
        }        
        break;

    case TCP_SSL_SM_CLI_INPUT_PORT_NUM:
        if(console_get_line(p_cons_line) == ICT_TRUE)
        {
            if(p_cons_line->len == 0)
            {
                p_cntx->waiting_cnt = 0;
                console_printf("\r\n$ PORT NUMBER : ");
                break;
            }
            
            console_printf("\r\n  => %s\r\n", p_cons_line->buf);
            
            p_cntx->port_num = (UINT32)ict_api_atoi(p_cons_line->buf);

            console_printf("\r\n Join Start...\r\n");
            p_cntx->waiting_cnt = 0;
            p_cntx->reassoc_cnt = 0;
            p_cons_line->len = 0;
            ict_api_join_handler(p_join_req);
            p_cntx->sm_state = TCP_SSL_SM_CLI_JOIN_AP;
        }
        else
        {
            p_cntx->waiting_cnt++;
            if(p_cntx->waiting_cnt > 2000) /* timeout 20sec */
            {
                console_printf("\r\n@ Input time exceeded. Restart!\r\n");
                p_cntx->sm_state = TCP_SSL_SM_CLI_INIT;
            }
        }        
        break;
        
    case TCP_SSL_SM_CLI_JOIN_AP:
        if(p_cntx->associated == ICT_TRUE)
        {
            console_printf("\r\n");
            console_printf(" IP       "IPSTR"\r\n", IP2STR(p_cntx->network_info.ipaddr));
            console_printf(" SUBNET   "IPSTR"\r\n", IP2STR(p_cntx->network_info.subnet));
            console_printf(" GATEWAY  "IPSTR"\r\n", IP2STR(p_cntx->network_info.gateway));
            console_printf(" DNS      "IPSTR"\r\n", IP2STR(p_cntx->network_info.dns));
                
            console_printf("\r\n Association Success!\r\n");
            console_printf("\r\n Client Start...\r\n");      

            p_cntx->waiting_cnt = 0;
            p_cons_line->len = 0;
            p_cntx->sock_fd[0] = 0; /* server sock_fd is 0 */
            result = ict_api_tcp_ssl_start_handler(p_cntx->sock_fd[0], p_cntx->host_ip, p_cntx->port_num);        
            p_cntx->sm_state = TCP_SSL_SM_CLI_CONNECT_HOST;            
        }
        else
        {
            p_cntx->waiting_cnt++;            
            if((p_cntx->associated == ICT_ERR) || (p_cntx->waiting_cnt > 2000)) /* timeout 20sec */
            {
                p_cntx->reassoc_cnt++;
                console_printf("\r\n@ Association Failed!\r\n");
                p_cntx->waiting_cnt = 0;
                p_cntx->associated = ICT_FALSE;

                if(p_cntx->reassoc_cnt > 5)
                {
                    p_cntx->sm_state = TCP_SSL_SM_CLI_INIT;
                }
            }
        }        
        break;

    case TCP_SSL_SM_CLI_CONNECT_HOST:
        if(p_cntx->connected == ICT_TRUE)
        {
            console_printf("\r\n Connected sock(%d) OK\n", p_cntx->sock_fd[0]);
            console_printf("\r\n(C) >> (S) : ");
            p_cons_line->len = 0;
            p_cntx->sm_state = TCP_SSL_SM_CLI_SEND_DATA;
        }
        break;

    case TCP_SSL_SM_CLI_SEND_DATA:
        if(console_get_line(p_cons_line) == ICT_TRUE)
        {
            if(p_cntx->sock_fd[0] != -1)
            {
                result = ict_api_tcp_ssl_send_handler(p_cntx->sock_fd[0], p_cons_line->buf, p_cons_line->len);            
                p_cons_line->len = 0;
                console_printf("\r\n(C) >> (S) : ");
            }            
        }
        else if(p_recv_data->len)
        {
            console_printf("\r\n(C) << (S) : %s", p_recv_data->buf);
            p_recv_data->len = 0;
            
            console_printf("\r\n(C) >> (S) : ");
        }
        break;
        
    default:
        break;
    }
}

static void tcp_ssl_client_task(void *arg)
{
    arg = arg;
    static UINT32 cnt = 0;
    ICT_ST_TCP_SSL_CNTX_T  *p_cntx;

    p_cntx = &tcp_ssl_cntx;
#if USE_CONSOLE_PORT    
    p_cntx->sm_state = TCP_SSL_SM_CLI_INIT;
#endif
    printf("\n");
    printf("==============================================\n");
    printf("=        TCP SSL Client Task Started.        =\n");
    printf("==============================================\n");
    
    while(1)
    {
#if USE_CONSOLE_PORT
        tcp_ssl_client_proc(p_cntx);
#else  /* USE_CONSOLE_PORT */
        if(p_cntx->associated == ICT_TRUE)
        {
            if((cnt == 300) && (p_cntx->connected == ICT_FALSE))
            {
                tcp_ssl_client_start();
                printf(" TCP SSL Client Started ...\n");                
            }
            else if(((cnt % 300) == 0) && (cnt < 6000) && (p_cntx->connected == ICT_TRUE))
            {
                int size = 0;
                char send_str[64];

                size = ICT_SPRINTF(send_str, "Test Data (%d)", cnt);
                ict_api_tcp_ssl_send_handler(p_cntx->sock_fd[0], send_str, size);
                printf(" TCP SSL Send Data : %s\n", send_str);                
            }
            else if((cnt == 6000) && (p_cntx->connected == ICT_TRUE))
            {
                ict_api_tcp_ssl_close_handler((void *)&p_cntx->sock_fd[0], sizeof(p_cntx->sock_fd[0]));
            }
            cnt++;
        }
#endif /* USE_CONSOLE_PORT */
        ict_api_tn_task_sleep(1);
    }        
}

void user_start(void)
{
    ict_api_tn_task_sleep(10);

    /* The default baudrate of UART0 is 8000000. */
    /* The baudrate of UART0 can be changed to 115200 or 230400, ..., 8000000 */
    printf("=== Start baudrate of UART%d : %d ===\n", UART0, ict_api_uart_get_baudrate(UART0));
    //ict_api_uart_change_baudrate (UART0, 8000000, fMACWLEN(UART_WORD_LEN_8BITS));    
    printf("\n");
    printf("=== Current baudrate of UART%d : %d ===\n", UART0, ict_api_uart_get_baudrate(UART0));  
    printf("**********************************************\n");
    printf("*              USER started.                 *\n");
    printf("**********************************************\n");
    printf("-- socket\n\n");

#if USE_CONSOLE_PORT
    console_port_config();
#else
    wlan_config();
#endif
    ict_cm_wlan_event_callback_register((void *)user_event_handler);

    ict_api_tn_task_sleep(10);     // 100msec sleep

    /* create task */
    if (p_tcp_ssl_task == ICT_NULL)
    {
        INT32 result;

        ict_api_tn_task_event_create(&uart_event_group, 0x00);
        
        p_tcp_ssl_task = ict_api_malloc(sizeof(TN_TCB));
        if (p_tcp_ssl_task == ICT_NULL)
        {
            printf("p_tcp_ssl_task malloc failed.\n");
            return;
        }
        
        ICT_MEMSET(p_tcp_ssl_task, 0x00, sizeof(*p_tcp_ssl_task));
        ICT_MEMSET(tcp_ssl_task_stack, 0x00, sizeof(tcp_ssl_task_stack));

        result = ict_api_tn_task_create(p_tcp_ssl_task, 
                                        "tcp_ssl",
                                        tcp_ssl_client_task, 
                                        NULL, 
                                        &tcp_ssl_task_stack[TCP_SSL_TASK_STACK_SIZE-1], 
                                        TCP_SSL_TASK_STACK_SIZE, 
                                        TCP_SSL_TASK_PRI);

        printf("ict_api_tn_task_create result(%d)\n", result);
    }    

    return;
}


