/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: user_main.c
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/


/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/
#include "ict_cm_globals.h"

#if defined (FEATURE_FILE_SYSTEM_FATFS)
#else
#ERROR NO_FILE_SYSTEM_FATFS
#endif

#if defined (FEATURE_HTTPC_SUPP) || defined (FEATURE_HTTPC_V2_SUPP)
#else
#ERROR NO_HTTPC
#endif
    
/*
******************************************************************************
* 	LOCAL CONSTANTS
******************************************************************************
*/

#define USE_CONSOLE_PORT                (1)

#define HTTP_DOWNLOAD_TASK_STACK_SIZE   1024
#define HTTP_DOWNLOAD_TASK_PRI          1

#define CONSOLE_PORT                UART2
#define CONSOLE_BUFF_SIZE           256
    
/*
******************************************************************************
*	LOCAL DATA TYPES
******************************************************************************
*/

typedef enum
{
    HTTP_DN_SM_INIT = 0,    
    HTTP_DN_SM_INPUT_AP_SSID,
    HTTP_DN_SM_INPUT_AP_PASSWD,
    HTTP_DN_SM_JOIN_AP,
    HTTP_DN_SM_INPUT_PATH,    
    HTTP_DN_SM_INPUT_FILE_NAME,
    HTTP_DN_SM_INPUT_FILE_URL,
    HTTP_DN_SM_FILE_DN_RESULT,
    HTTP_DN_SM_END
} HTTP_DN_SM_STATE;

typedef struct
{
    UINT32  len;
    UINT8   buf[CONSOLE_BUFF_SIZE];
} ICT_ST_CONS_DATA_T;

typedef struct
{
    INT32 associated;
    INT32 file_dn_rst;

    UINT32 reassoc_cnt;
    UINT32 waiting_cnt;
    
    UINT8 file_name[32];
    UINT32 file_size;

    UINT8 path[CONSOLE_BUFF_SIZE];    
    UINT8 file_url[CONSOLE_BUFF_SIZE];

    HTTP_DN_SM_STATE sm_state;

    ICT_ST_JOIN_REQ_T   join_req;
    ICT_ST_NETWORK_INFO_IND_T network_info;
} ICT_ST_HTTP_DN_CNTX_T;

/*
******************************************************************************
*	GLOBAL VARIABLES
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL VARIABLES
******************************************************************************
*/

TN_TCB *p_http_download_task = ICT_NULL;
DWALIGN OS_STK http_download_task_stack[HTTP_DOWNLOAD_TASK_STACK_SIZE] XDWALIGN;

static ICT_ST_CONS_DATA_T       cons_line_data;
static ICT_ST_HTTP_DN_CNTX_T    http_dn_cntx;

/*
******************************************************************************
*	LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/


/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/

void console_port_config(void)
{
    ict_api_uart_init(CONSOLE_PORT);
    ict_api_uart_open(CONSOLE_PORT);    
    ict_api_uart_change_baudrate (CONSOLE_PORT, 115200, fMACWLEN(UART_WORD_LEN_8BITS));
}

INT32 console_is_rx_empty(void)
{
    return ict_api_uart_is_rx_empty(CONSOLE_PORT);
}

UINT32 console_get_data(char *buf, UINT32 maxLen)
{
    return (UINT32)ict_api_uart_gets(CONSOLE_PORT, buf, maxLen);
}

UINT32 console_send_byte(char ch)
{
    return (UINT32)ict_api_uart2_putc(ch);
}

void console_send_data(UINT8 *buf, UINT32 len)
{
    ict_api_uart_direct_send_w_size(CONSOLE_PORT, buf, len);
}

void console_printf (char *fmt,...)
{
	va_list             ap;
    char                str[128];
    int                 size;
    
    va_start(ap, fmt);
	size = xn_vsprintf (&str, fmt, ap);
    size &= (sizeof(str)-1);
    ict_api_uart_direct_send_w_size(CONSOLE_PORT, str, size);    
  	va_end (ap);
}

INT32 console_get_line(ICT_ST_CONS_DATA_T *p_data)
{
    char    cons_buf[CONSOLE_BUFF_SIZE];
    UINT32  cons_len = 0;
    UINT32  data_cnt = 0;
    char    ch;
    
    if(console_is_rx_empty())
    {
        return ICT_FALSE;
    }
    else
    {
        cons_len = console_get_data(cons_buf, sizeof(cons_buf));
    }
    
    while(cons_len > data_cnt)
    {
        ch = cons_buf[data_cnt++];
        
        if(ch == '\b')
        {            
            if(p_data->len)
            {
                p_data->len -= 1;
                p_data->buf[p_data->len] = '\0';
                console_printf("\b \b");                
            }
            continue;
        }
        
        if((ch == 0x0D) || (ch == 0x0A))
        {
            if(p_data->len)                
            {
                p_data->buf[p_data->len++] = '\0';
                return ICT_TRUE;
            }
            else
            {
                p_data->buf[0] = '\0';
                return ICT_TRUE;
            }
        }
        else
        {
            console_send_byte(ch);
            p_data->buf[p_data->len++] = ch;
        }
    }

    return ICT_FALSE;
}

void wlan_config(void)
{
    UINT8 ssid[MAX_SSID_LEN] = "test_ap";
    UINT8 password[MAX_PSK_LEN] = "12345678";
    UINT16 dhcp_en = ICT_TRUE; /* DHCP */    
    ICT_ST_HTTP_DN_CNTX_T  *p_cntx;
    INT32 result;

    p_cntx = &http_dn_cntx;
    ICT_MEMSET(p_cntx, 0, sizeof(ICT_ST_HTTP_DN_CNTX_T));

    p_cntx->associated = ICT_FALSE;
    p_cntx->file_dn_rst = ICT_FALSE;
    p_cntx->file_size = 0;
        
    ICT_MEMSET(&p_cntx->join_req, 0x00, sizeof(ICT_ST_JOIN_REQ_T));
    p_cntx->join_req.ssid_len = ICT_STRLEN(ssid);
    ICT_STRCPY(p_cntx->join_req.ssid, ssid);
    p_cntx->join_req.key_len = ICT_STRLEN(password);
    ICT_STRCPY(p_cntx->join_req.key, password);
    
    if (p_cntx->join_req.ssid_len) printf("ssid: %s\n", p_cntx->join_req.ssid);
    if (p_cntx->join_req.key_len) printf("pwd: %s\n", p_cntx->join_req.key);

    result = ict_api_join_handler(&p_cntx->join_req);
    printf("[%s] result: %d\n", __func__, result);
}

void user_event_handler(T_MAC_EVENT *p_mac_event)
{
    ICT_ST_HTTP_DN_CNTX_T  *p_cntx;

    p_cntx = &http_dn_cntx;
    
    switch(p_mac_event->code)
    {
        case ICT_HIF_CMD_ST_JOIN_IND:
            if(ict_api_join_state(p_mac_event->buf) == ICT_TRUE)
            {
                printf("N: [ASSOCIATED]\n");
            }
            break;
            
        case ICT_HIF_CMD_ST_DISCONNECTED_IND:
            printf("N: [DISASSOCIATED]\n");
            break;
        
        case ICT_HIF_CMD_ST_NETWORK_INFO_IND:
            {
                ICT_ST_NETWORK_INFO_IND_T *network_ind;
                network_ind = (ICT_ST_NETWORK_INFO_IND_T *)p_mac_event->buf;

                ICT_MEMCPY(&p_cntx->network_info, network_ind, sizeof(ICT_ST_NETWORK_INFO_IND_T));
                
                printf("IP       "IPSTR"\n", IP2STR(network_ind->ipaddr));
                printf("SUBNET   "IPSTR"\n", IP2STR(network_ind->subnet));
                printf("GATEWAY  "IPSTR"\n", IP2STR(network_ind->gateway));
                printf("DNS      "IPSTR"\n", IP2STR(network_ind->dns));
                
                p_cntx->associated = ICT_TRUE;
            }
            break;
            
        default:
            break;
    }
}

static void http_download_finished_callback(INT32 result, UINT8 *savedName)
{
    ICT_ST_HTTP_DN_CNTX_T  *p_cntx;
    
    p_cntx = &http_dn_cntx;
    
    switch (result)
    {
        case HTTPC_DOWNLOAD_RESULT_OK:
            printf("N: [%s] HTTPC_DOWNLOAD_RESULT_OK (%s)\n", __func__, savedName);
            console_printf("\r\n + HTTPC_DOWNLOAD_RESULT_OK (%s) +\r\n", savedName);
            p_cntx->file_dn_rst = ICT_TRUE;
            break;
            
        case HTTPC_DOWNLOAD_RESULT_ERR_RESPONSECODE:
            printf("N: [%s] HTTPC_DOWNLOAD_RESULT_ERR_RESPONSECODE (%s)\n", __func__, savedName);
            console_printf("\r\n + HTTPC_DOWNLOAD_RESULT_ERR_RESPONSECODE (%s) +\r\n", savedName);
            break;
            
        case HTTPC_DOWNLOAD_RESULT_ERR_FILEWRITE:
            printf("N: [%s] HTTPC_DOWNLOAD_RESULT_ERR_FILEWRITE (%s)\n", __func__, savedName);
            console_printf("\r\n + HTTPC_DOWNLOAD_RESULT_ERR_FILEWRITE (%s) +\r\n", savedName);
            break;
            
        case HTTPC_DOWNLOAD_RESULT_ERR_FILESIZE:
            printf("N: [%s] HTTPC_DOWNLOAD_RESULT_ERR_FILESIZE (%s)\n", __func__, savedName);
            console_printf("\r\n + HTTPC_DOWNLOAD_RESULT_ERR_FILESIZE (%s) +\r\n", savedName);
            break;
            
        case HTTPC_DOWNLOAD_RESULT_ERR_MEMORY:
            printf("N: [%s] HTTPC_DOWNLOAD_RESULT_ERR_MEMORY (%s)\n", __func__, savedName);
            console_printf("\r\n + HTTPC_DOWNLOAD_RESULT_ERR_MEMORY (%s) +\r\n", savedName);
            break;
            
        case HTTPC_DOWNLOAD_RESULT_ERR_CONNECTION:
            printf("N: [%s] HTTPC_DOWNLOAD_RESULT_ERR_CONNECTION (%s)\n", __func__, savedName);
            console_printf("\r\n + HTTPC_DOWNLOAD_RESULT_ERR_CONNECTION (%s) +\r\n", savedName);
            break;
            
        default:
            printf("N: [%s] Unknown Result(%d) (%s)\n", __func__, result, savedName);
            console_printf("\r\n + Unknown Result(%s) Result(%d)  +\r\n", savedName, result);
            break;
    }
}

static void httpc_download_request_result_print(INT32 result)
{
    switch (result)
    {
        case HTTPC_RESULT_OK:
            printf("N: [%s] HTTPC_RESULT_OK\n", __func__);
            console_printf("\r\n = HTTPC_RESULT_OK =\r\n");
            break;
            
        case HTTPC_RESULT_ERR_UNKNOWN:
            printf("N: [%s] HTTPC_RESULT_ERR_UNKNOWN\n", __func__);
            console_printf("\r\n = HTTPC_RESULT_ERR_UNKNOWN =\r\n");
            break;
            
        case HTTPC_RESULT_ERR_CONNECT:
            printf("N: [%s] HTTPC_RESULT_ERR_CONNECT\n", __func__);
            console_printf("\r\n = HTTPC_RESULT_ERR_CONNECT =\r\n");
            break;
            
        case HTTPC_RESULT_ERR_HOSTNAME:
            printf("N: [%s] HTTPC_RESULT_ERR_HOSTNAME\n", __func__);
            console_printf("\r\n = HTTPC_RESULT_ERR_HOSTNAME =\r\n");
            break;
            
        case HTTPC_RESULT_ERR_CLOSED:
            printf("N: [%s] HTTPC_RESULT_ERR_CLOSED\n", __func__);
            console_printf("\r\n = HTTPC_RESULT_ERR_CLOSED =\r\n");
            break;
            
        case HTTPC_RESULT_ERR_TIMEOUT:
            printf("N: [%s] HTTPC_RESULT_ERR_TIMEOUT\n", __func__);
            console_printf("\r\n = HTTPC_RESULT_ERR_TIMEOUT =\r\n");
            break;
            
        case HTTPC_RESULT_ERR_SVR_RESP:
            printf("N: [%s] HTTPC_RESULT_ERR_SVR_RESP\n", __func__);
            console_printf("\r\n = HTTPC_RESULT_ERR_SVR_RESP =\r\n");
            break;
            
        case HTTPC_RESULT_ERR_INITIALIZE:
            printf("N: [%s] HTTPC_RESULT_ERR_INITIALIZE\n", __func__);
            console_printf("\r\n = HTTPC_RESULT_ERR_INITIALIZE =\r\n");
            break;
            
        case HTTPC_RESULT_ERR_ARGUMENT:
            printf("N: [%s] HTTPC_RESULT_ERR_ARGUMENT\n", __func__);
            console_printf("\r\n = HTTPC_RESULT_ERR_ARGUMENT =\r\n");
            break;
            
        case HTTPC_RESULT_ERR_MEMORY:
            printf("N: [%s] HTTPC_RESULT_ERR_MEMORY\n", __func__);
            console_printf("\r\n = HTTPC_RESULT_ERR_MEMORY =\r\n");
            break;
            
        case HTTPC_RESULT_SESSION_SUCCESS:
            printf("N: [%s] HTTPC_RESULT_SESSION_SUCCESS\n", __func__);
            console_printf("\r\n = HTTPC_RESULT_SESSION_SUCCESS =\r\n");
            break;
            
        case HTTPC_RESULT_SESSION_CLOSED:
            printf("N: [%s] HTTPC_RESULT_SESSION_CLOSED\n", __func__);
            console_printf("\r\n = HTTPC_RESULT_SESSION_CLOSED =\r\n");
            break;
            
        case HTTPC_RESULT_OK_SVR_RESP:
            printf("N: [%s] HTTPC_RESULT_OK_SVR_RESP\n", __func__);
            console_printf("\r\n = HTTPC_RESULT_OK_SVR_RESP =\r\n");
            break;
            
        default:
            printf("N: [%s] Unknown Result(%d)\n", __func__, result);
            console_printf("\r\n = Unknown Result(%d) =\r\n", result);
            break;
    }
}

static void display_file_list(char *path)
{    
    UINT32 max_count = 10;
    UINT8 *p_out_list = ICT_NULL;
    UINT32 out_count = 0;
    UINT32 out_len = 0;
    int i;
    FILINFO *tmp;

    p_out_list = ICT_MALLOC(max_count * sizeof(FILINFO));
    if (p_out_list == ICT_NULL)
    {
        printf("E: malloc failed.\n");
        console_printf("\r\n File Display Error! \r\n");
        return;
    }
    
    printf("\n");
    out_len = ict_api_fs_scan_files(path, max_count, p_out_list, &out_count);
    if (out_len && out_count)
    {
        for (i = 0; i < out_count; i++)
        {
            tmp = (FILINFO *)(p_out_list + (i * sizeof(FILINFO)));
            printf("N: <%-4s> %-13s\t\t\t%4d bytes\n", (tmp->fattrib & AM_DIR)?"DIR":"FILE", tmp->fname, tmp->fsize);
            console_printf("\r\n <%-4s> %-13s\t\t\t%4d bytes", (tmp->fattrib & AM_DIR)?"DIR":"FILE", tmp->fname, tmp->fsize);
        }           
        console_printf("\r\n");
    }
}
    
void http_download_proc(ICT_ST_HTTP_DN_CNTX_T *p_cntx)
{
    ICT_ST_JOIN_REQ_T   *p_join_req;
    ICT_ST_CONS_DATA_T  *p_cons_line;
    INT32 result;

    p_join_req = &p_cntx->join_req;
    p_cons_line = &cons_line_data;

    switch(p_cntx->sm_state)
    {
    case HTTP_DN_SM_INIT:
        p_cntx->associated = ICT_FALSE;
        p_cntx->file_dn_rst = ICT_FALSE;
        p_cntx->file_size = 0;
        
        ICT_MEMSET(p_join_req, 0, sizeof(ICT_ST_JOIN_REQ_T));
        p_cons_line->len = 0;

        console_printf("\r\n");
        console_printf("=================================\r\n");
        console_printf("=      HTTP DOWNLOAD START      =\r\n");
        console_printf("=================================\r\n");

        p_cntx->waiting_cnt = 0;
        p_cons_line->len = 0;
        console_printf("\r\n$ AP SSID : ");
        p_cntx->sm_state = HTTP_DN_SM_INPUT_AP_SSID;
        break;
        
    case HTTP_DN_SM_INPUT_AP_SSID:
        if(console_get_line(p_cons_line) == ICT_TRUE)
        {
            if(p_cons_line->len == 0)
            {
                p_cntx->waiting_cnt = 0;
                console_printf("\r\n$ AP SSID : ");
                break;
            }
            
            console_printf("\r\n  => %s\r\n", p_cons_line->buf);
            
            ICT_STRCPY(p_join_req->ssid, p_cons_line->buf);
            p_join_req->ssid_len = ICT_STRLEN(p_join_req->ssid);

            console_printf("\r\n$ AP PASSWORD : ");
            p_cntx->waiting_cnt = 0;
            p_cons_line->len = 0;
            p_cntx->sm_state = HTTP_DN_SM_INPUT_AP_PASSWD;
        }
        break;
        
    case HTTP_DN_SM_INPUT_AP_PASSWD:
        if(console_get_line(p_cons_line) == ICT_TRUE)
        {
            console_printf("\r\n  => %s\r\n", p_cons_line->buf);
            
            ICT_STRCPY(p_join_req->key, p_cons_line->buf);
            p_join_req->key_len = ICT_STRLEN(p_join_req->key);    

            console_printf("\r\n Join Start...\r\n");        
            ict_api_join_handler(p_join_req);
            p_cntx->sm_state = HTTP_DN_SM_JOIN_AP;
        }
        else
        {
            p_cntx->waiting_cnt++;
            if(p_cntx->waiting_cnt > 2000) /* timeout 20sec */
            {
                console_printf("\r\n@ Input time exceeded. Restart!\r\n");
                p_cntx->sm_state = HTTP_DN_SM_INIT;
            }
        }
        break;
        
    case HTTP_DN_SM_JOIN_AP:
        if(p_cntx->associated == ICT_TRUE)
        {
            console_printf("\r\n");
            console_printf(" IP       "IPSTR"\r\n", IP2STR(p_cntx->network_info.ipaddr));
            console_printf(" SUBNET   "IPSTR"\r\n", IP2STR(p_cntx->network_info.subnet));
            console_printf(" GATEWAY  "IPSTR"\r\n", IP2STR(p_cntx->network_info.gateway));
            console_printf(" DNS      "IPSTR"\r\n", IP2STR(p_cntx->network_info.dns));
                
            console_printf("\r\n Association Success!\r\n");
            console_printf("\r\n HTTP Client Start...\r\n");

            p_cons_line->len = 0;
            console_printf("\r\n$ FILE PATH : ");
            p_cntx->sm_state = HTTP_DN_SM_INPUT_PATH;
        }
        else
        {
            p_cntx->waiting_cnt++;            
            if((p_cntx->associated == ICT_ERR) || (p_cntx->waiting_cnt > 2000)) /* timeout 20sec */
            {
                p_cntx->reassoc_cnt++;
                console_printf("\r\n@ Association Failed!\r\n");
                p_cntx->waiting_cnt = 0;
                p_cntx->associated = ICT_FALSE;

                if(p_cntx->reassoc_cnt > 5)
                {
                    p_cntx->sm_state = HTTP_DN_SM_INIT;
                }
            }            
        }        
        break;

    case HTTP_DN_SM_INPUT_PATH:
        if(console_get_line(p_cons_line) == ICT_TRUE)
        {
            console_printf("\r\n  => %s\r\n", p_cons_line->buf);
            
            ICT_STRCPY(p_cntx->path, p_cons_line->buf);

            p_cons_line->len = 0;
            console_printf("\r\n$ FILE NAME : ");
            p_cntx->sm_state = HTTP_DN_SM_INPUT_FILE_NAME;
        }
        break;
        
    case HTTP_DN_SM_INPUT_FILE_NAME:
        if(console_get_line(p_cons_line) == ICT_TRUE)
        {
            console_printf("\r\n  => %s\r\n", p_cons_line->buf);

            ICT_STRCPY(p_cntx->file_name, p_cons_line->buf);
            p_cntx->file_size = ict_api_fs_read_file_size(p_cntx->file_name);
            
            console_printf("\r\n File(%s) Size(%d)\r\n", p_cntx->file_name, p_cntx->file_size);
            
            if (p_cntx->file_size)
            {
                console_printf("\r\n Remove File(%s)\n", p_cntx->file_name);
                ict_api_fs_remove(p_cntx->file_name);
                
                p_cntx->file_size = ict_api_fs_read_file_size(p_cntx->file_name);
                console_printf("\r\n File(%s) Size(%d)\r\n", p_cntx->file_name, p_cntx->file_size);
            }

            display_file_list(p_cntx->path);

            p_cons_line->len = 0;
            console_printf("\r\n$ FILE URL : ");
            p_cntx->sm_state = HTTP_DN_SM_INPUT_FILE_URL;
        }
        break;

    case HTTP_DN_SM_INPUT_FILE_URL:
        if(console_get_line(p_cons_line) == ICT_TRUE)
        {
            console_printf("\r\n  => %s\r\n", p_cons_line->buf);
            
            ICT_STRCPY(p_cntx->file_url, p_cons_line->buf);

            result = ict_api_httpc_download_request(p_cntx->file_url, p_cntx->file_name, http_download_finished_callback);
            httpc_download_request_result_print(result);

            p_cntx->waiting_cnt = 0;
            p_cntx->sm_state = HTTP_DN_SM_FILE_DN_RESULT;
        }
        break;

    case HTTP_DN_SM_FILE_DN_RESULT:
        if(p_cntx->file_dn_rst == ICT_TRUE)
        {
            display_file_list(p_cntx->path);
            console_printf("\r\n File(%s) Download Success!\r\n", p_cntx->file_url);
            p_cntx->sm_state = HTTP_DN_SM_END;
        }
        else
        {
            p_cntx->waiting_cnt++; 
            if(p_cntx->waiting_cnt > 3000)
            {
                p_cntx->sm_state = HTTP_DN_SM_INIT;
                console_printf("\r\n@ File(%s) Download Failed!\r\n", p_cntx->file_url);
            }
        }
        
        break;
        
    case HTTP_DN_SM_END:
        //...
        break;
        
    default:
        break;
    }
}


static void http_download_task(void *arg)
{
    arg = arg;
    static UINT32 cnt = 0;
    INT32 result;
    ICT_ST_HTTP_DN_CNTX_T  *p_cntx;

    p_cntx = &http_dn_cntx;
#if USE_CONSOLE_PORT    
    p_cntx->sm_state = HTTP_DN_SM_INIT;
#endif
    printf("\n");
    printf("==============================================\n");
    printf("=         HTTP DOWNLOAD task started.        =\n");
    printf("==============================================\n");

    while(1)
    {
#if USE_CONSOLE_PORT
        http_download_proc(p_cntx);
#else
        if(p_cntx->associated == ICT_TRUE)
        {
            if(cnt == 100)
            {
                ICT_STRCPY(p_cntx->file_name, "test.crt"); 
                p_cntx->file_size = ict_api_fs_read_file_size(p_cntx->file_name);
                printf("\n");
                printf("T: File(%s) size(%d)\n", p_cntx->file_name, p_cntx->file_size);
                
                if (p_cntx->file_size)
                {
                    printf("T: Remove File(%s)\n", p_cntx->file_name);
                    ict_api_fs_remove(p_cntx->file_name);
                    
                    p_cntx->file_size = ict_api_fs_read_file_size(p_cntx->file_name);
                    printf("T: File(%s) size(%d)\n", p_cntx->file_name, p_cntx->file_size);
                }
                printf("\n");
            }
            else if(cnt == 1000)
            {
                ICT_STRCPY(p_cntx->path, "/");    
                
                display_file_list(p_cntx->path);
                printf("\n");
            }
            else if(cnt == 2000)
            {
                ICT_STRCPY(p_cntx->file_url, "http://192.168.10.2/test.crt");
                
                /* File Download Request */
                result = ict_api_httpc_download_request(p_cntx->file_url, p_cntx->file_name, http_download_finished_callback);
                httpc_download_request_result_print(result);
                printf("\n");
            }
            else if(cnt == 3000)
            {
                display_file_list(p_cntx->path);
            }

            cnt++;
        }
#endif        
        ict_api_tn_task_sleep(1);     // 10 msec sleep
    }    
    
}

void user_start()
{
    ict_api_tn_task_sleep(10);

    /* The default baudrate of UART0 is 8000000. */
    /* The baudrate of UART0 can be changed to 115200 or 230400, ..., 8000000 */
    printf("=== Start baudrate of UART%d : %d ===\n", UART0, ict_api_uart_get_baudrate(UART0));
    //ict_api_uart_change_baudrate (UART0, 8000000, fMACWLEN(UART_WORD_LEN_8BITS));    
    printf("\n");
    printf("=== Current baudrate of UART%d : %d ===\n", UART0, ict_api_uart_get_baudrate(UART0));  
    printf("**********************************************\n");
    printf("*              USER started.                 *\n");
    printf("**********************************************\n");
    printf("-- http download\n\n");

#if USE_CONSOLE_PORT
    console_port_config();
#else
    wlan_config();    
#endif
    ict_cm_wlan_event_callback_register((void *)user_event_handler);

    /* create task */
    if (p_http_download_task == ICT_NULL)
    {
        INT32 result;
        
        p_http_download_task = ict_api_malloc(sizeof(TN_TCB));
        if (p_http_download_task == ICT_NULL)
        {
            printf("p_http_download_task malloc failed.\n");
            return;
        }
        
        ICT_MEMSET(p_http_download_task, 0x00, sizeof(*p_http_download_task));
        ICT_MEMSET(http_download_task_stack, 0x00, sizeof(http_download_task_stack));

        result = ict_api_tn_task_create(p_http_download_task, 
                                        "http_download", 
                                        http_download_task, 
                                        NULL, 
                                        &http_download_task_stack[HTTP_DOWNLOAD_TASK_STACK_SIZE-1], 
                                        HTTP_DOWNLOAD_TASK_STACK_SIZE, 
                                        HTTP_DOWNLOAD_TASK_PRI);
        
        printf("ict_api_tn_task_create result(%d)\n", result);
    }    

    return;
}


