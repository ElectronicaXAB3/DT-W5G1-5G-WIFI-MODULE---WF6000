/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: user_main.c
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/


/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/
#include "ict_cm_globals.h"

/*
******************************************************************************
* 	LOCAL CONSTANTS
******************************************************************************
*/

#define GPIO_TASK_STACK_SIZE        (1024)
#define GPIO_TASK_PRI               (1)

/*
******************************************************************************
*	LOCAL DATA TYPES
******************************************************************************
*/

typedef enum
{
    INTR_FSM_IDLE,
    INTR_FSM_DEBOUNCE,
    INTR_FSM_LED_CTRL,
    INTR_FSM_END
}
INTR_BTN_FSM;

/*
******************************************************************************
*	GLOBAL VARIABLES
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL VARIABLES
******************************************************************************
*/

TN_TCB *p_gpio_task = ICT_NULL;
DWALIGN OS_STK gpio_task_stack[GPIO_TASK_STACK_SIZE] XDWALIGN;

UINT8 led_port = GPIO_23; // GPIO_10 // UART1_RXD
UINT8 ext_intr_port = GPIO_24; // GPIO_11 // UART1_TXD

static volatile UINT32 ext_intr_flag = 0;

static UINT32 btn_bnc_cnt = 0; /* bounce counter */
static INTR_BTN_FSM intr_fsm = INTR_FSM_IDLE;

/*
******************************************************************************
*	LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/


/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/

void gpio_output_init(UINT8 gpio)
{
    ict_api_sys_gpio_set_pad(gpio, 1);          /* 1: GPIO Enable, 0: GPIO Disable          */
    ict_api_sys_gpio_set_direction(gpio, 1);    /* 1: Output Mode, 0: Input Mode            */
    ict_api_sys_gpio_set_output(gpio, 1);
}

void gpio_ext_intr_init(UINT8 gpio)
{
    ict_api_sys_gpio_set_pad(gpio, 1);          /* 1: GPIO Enable, 0: GPIO Disable          */
    ict_api_sys_gpio_set_direction(gpio, 0);    /* 1: Output Mode, 0: Input Mode            */
    ict_api_sys_gpio_set_sensitivity(gpio, 1);  /* 1: Level Interrupt, 0: Edge Interrupt    */
    ict_api_sys_gpio_set_ipolarity(gpio, 0);    /* 1: High Polarity, 0: Low Polarity        */
}

void gpio_ext_intr_handler(void)
{
    /* Can not use printf function */
    
    ext_intr_flag = 1;
}

void gpio_intr_btn_proc (void)
{
    UINT32  curstate = 0;
    UINT16  out_val = 0;

    curstate = ict_api_sys_gpio_get_input(ext_intr_port);

    switch(intr_fsm)
    {
        case INTR_FSM_IDLE:
            if((ext_intr_flag == 1) && (curstate == 0))
            {
                printf("T: INTR_FSM_IDLE : Interrupt has happend!\n");
                intr_fsm = INTR_FSM_DEBOUNCE;
                btn_bnc_cnt = 10; // about 100ms
            }
            else
            {
                ext_intr_flag = 0;
            }
            break;
            
        case INTR_FSM_DEBOUNCE:
            if(btn_bnc_cnt)
            {
                btn_bnc_cnt--;
            }
            else
            {
                printf("T: INTR_FSM_DEBOUNCE : Debounce finish!\n");
                intr_fsm = INTR_FSM_LED_CTRL;
            }
            break;

        case INTR_FSM_LED_CTRL:
            out_val = (UINT16)ict_api_sys_gpio_get_output(led_port);
            ict_api_sys_gpio_set_output(led_port, ((~out_val) & 0x0001));
            printf("I: INTR_FSM_LED_CTRL : GPIO_%d Output Value => (%d)\n", led_port, ((~out_val) & 0x0001));

            intr_fsm = INTR_FSM_END;
            break;

        case INTR_FSM_END:
            ext_intr_flag = 0;
            intr_fsm = INTR_FSM_IDLE;            
            printf("T: INTR_FSM_END\n");
            break;
            
        default:
            break;
    }
}

static void gpio_task(void *arg)
{
    UINT16  out_val = 0;
    
    arg = arg;

    printf("\n");
    printf("==============================================\n");
    printf("=           gpio task started.               =\n");
    printf("==============================================\n");

    while(1)
    {
        ict_api_os_time_delay(1); // 10ms 
        gpio_intr_btn_proc();
    }
}

void user_start()
{
    ict_api_tn_task_sleep(10);

    /* The default baudrate of UART0 is 8000000. */
    /* The baudrate of UART0 can be changed to 115200 or 230400, ..., 8000000 */
//    ict_api_uart_change_baudrate (UART0, 8000000, fMACWLEN(UART_WORD_LEN_8BITS));
    printf("\n");
    printf("=== Current baudrate of UART%d : %d ===\n", UART0, ict_api_uart_get_baudrate(UART0));      
    printf("**********************************************\n");
    printf("*              USER started.                 *\n");
    printf("**********************************************\n");
    printf("-- gpio ext interrupt\n\n");

    gpio_output_init(led_port);
    gpio_ext_intr_init(ext_intr_port);

    ict_api_sys_gpio_set_istatus(0xFFFFFFFF); 
    ict_api_sys_gpio_enable(ext_intr_port, gpio_ext_intr_handler);

    /* create task */
    if (p_gpio_task == ICT_NULL)
    {
        INT32 result;

        p_gpio_task = ict_api_malloc(sizeof(TN_TCB));
        if (p_gpio_task == ICT_NULL)
        {
            printf("p_gpio_task malloc failed.\n");
            return;
        }
        
        ICT_MEMSET(p_gpio_task, 0x00, sizeof(*p_gpio_task));
        ICT_MEMSET(gpio_task_stack, 0x00, sizeof(gpio_task_stack));
        
        result = ict_api_tn_task_create(p_gpio_task, 
                                        "gpio",
                                        gpio_task, 
                                        NULL, 
                                        &gpio_task_stack[GPIO_TASK_STACK_SIZE-1], 
                                        GPIO_TASK_STACK_SIZE, 
                                        GPIO_TASK_PRI);
    }
    
    return;
}


