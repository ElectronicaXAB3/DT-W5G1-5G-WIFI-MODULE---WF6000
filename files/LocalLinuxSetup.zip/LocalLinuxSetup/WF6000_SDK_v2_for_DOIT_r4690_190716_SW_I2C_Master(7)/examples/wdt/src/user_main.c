/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: user_main.c
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/


/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/
#include "ict_cm_globals.h"

/*
******************************************************************************
* 	LOCAL CONSTANTS
******************************************************************************
*/

#define WDT_TASK_STACK_SIZE    256
#define WDT_TASK_PRI           1

typedef enum
{
    ICT_WDT_BARK_RESET = 0x0,
    ICT_WDT_BARK_INTERRUPT = 0x1
} wdt_bark_type_t;
/*
******************************************************************************
*	LOCAL DATA TYPES
******************************************************************************
*/

/*
******************************************************************************
*	GLOBAL VARIABLES
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL VARIABLES
******************************************************************************
*/

TN_TCB *p_wdt_task = ICT_NULL;
DWALIGN OS_STK wdt_task_stack[WDT_TASK_STACK_SIZE] XDWALIGN;

/*
******************************************************************************
*	LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/


/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/

static void wdt_task(void *arg)
{
    arg = arg;
    static int num;
    UINT32 timeout_ms = 5000;

    printf("\n");
    printf("==============================================\n");
    printf("=          watchdog task started.            =\n");
    printf("==============================================\n");

    /* watchdog init & start */
    ict_api_wdt_init(timeout_ms, ICT_WDT_BARK_RESET);
    ict_api_wdt_start();

    while(1)
    {
        printf("[%s] num(%d)\n", __func__, num);
        
        /* If want to test WDT reset */
        if (0)
        {
            /* after (10 + timeout_ms) secs, WDT reset!! */ 
            if (num < 10)
            {
                ict_api_wdt_refresh();
            }
        }
        /* no test */
        else
        {
            ict_api_wdt_refresh();
        }
        
        num++;
        ict_api_tn_task_sleep(100);     // 1000 msec sleep
    }    
    
}

void user_start()
{
    ict_api_tn_task_sleep(10);

    /* The default baudrate of UART0 is 8000000. */
    /* The baudrate of UART0 can be changed to 115200 or 230400, ..., 8000000 */
//    ict_api_uart_change_baudrate (UART0, 8000000, fMACWLEN(UART_WORD_LEN_8BITS));
    
    printf("\n");
    printf("=== Current baudrate of UART%d : %d ===\n", UART0, ict_api_uart_get_baudrate(UART0));  
    printf("**********************************************\n");
    printf("*              USER started.                 *\n");
    printf("**********************************************\n");
    printf("-- watchdog\n\n");

    /* check if system was reset caused by WDT */
    if (ict_api_wdt_reset_check() == ICT_TRUE)
    {
        printf("E: Reset by Watchdog Timer!!\n");
    }

    /* create task */
    if (p_wdt_task == ICT_NULL)
    {
        INT32 result;
        
        p_wdt_task = ict_api_malloc(sizeof(TN_TCB));
        if (p_wdt_task == ICT_NULL)
        {
            printf("p_wdt_task malloc failed.\n");
            return;
        }
        
        ICT_MEMSET(p_wdt_task, 0x00, sizeof(*p_wdt_task));
        ICT_MEMSET(wdt_task_stack, 0x00, sizeof(wdt_task_stack));

        result = ict_api_tn_task_create(p_wdt_task, "wdt", wdt_task, NULL, &wdt_task_stack[WDT_TASK_STACK_SIZE-1], WDT_TASK_STACK_SIZE, WDT_TASK_PRI);
        printf("ict_api_tn_task_create result(%d)\n", result);
    }    
    
    return;
}


